# Multi-Agent Coordination Rules

**Purpose**: Govern how multiple AI agents coordinate when working on the same project simultaneously.

---

## Rule COORD-01: Agent Isolation

Each agent session MUST operate in its own git worktree or dedicated branch.
No two agents may modify the same file simultaneously.

**Rule**: Before starting any file modification, the agent MUST:

1. Check if a `.aidlc-lock/<filename>.lock` file exists for the target file
2. If a lock exists, STOP and report the conflict to the user
3. If no lock exists, create the lock file before modifying
4. Remove the lock file after completing the modification

**Verification**:

- [ ] Agent is operating on a dedicated branch (not directly on `main`/`master`)
- [ ] No lock files exist for files this agent intends to modify
- [ ] Lock files are created before modification and removed after

---

## Rule COORD-02: Escalation Policy

If an agent fails CI checks twice consecutively, it MUST stop autonomous execution.

**Rule**: The agent MUST:

1. Document the failure details in `aidlc-docs/escalations/<timestamp>-escalation.md`
2. Include: failure type, CI output, files modified, attempted fixes
3. Create a human review request (comment on PR or create issue)
4. STOP all autonomous execution until a human resolves the escalation

**Escalation document format**:

```markdown
## Escalation: <short description>
**Timestamp**: <ISO 8601>
**Agent Session**: <session identifier>
**Failure Count**: 2
**CI Failures**: <paste CI output>
**Files Modified**: <list>
**Attempted Fixes**: <describe what was tried>
**Human Action Required**: <specific ask>
```

**Verification**:

- [ ] Escalation document created in `aidlc-docs/escalations/`
- [ ] Human review request created
- [ ] Agent has stopped autonomous execution

---

## Rule COORD-03: Conflict Resolution

When two agents produce conflicting changes to the same artifact, a human MUST resolve the conflict.

**Rule**: The agent MUST NOT auto-merge conflicting changes. Instead:

1. Preserve both versions with clear labels (`<!-- AGENT-A -->` / `<!-- AGENT-B -->`)
2. Log the conflict in `aidlc-docs/escalations/conflicts.md`
3. Pause and request human resolution before proceeding

**Verification**:

- [ ] Conflicting changes are clearly labeled, not silently merged
- [ ] Conflict logged in `aidlc-docs/escalations/conflicts.md`
- [ ] Human resolution obtained before proceeding

---

## Rule COORD-04: Shared State Consistency

All agents working on the same project MUST read `aidlc-docs/aidlc-state.md` before starting
any phase to avoid duplicating completed work.

**Rule**:

1. At session start, read `aidlc-docs/aidlc-state.md` to determine current workflow state
2. Do NOT re-execute stages already marked complete unless explicitly requested
3. After completing any stage, update `aidlc-state.md` immediately

**Verification**:

- [ ] `aidlc-state.md` read at session start
- [ ] No duplicate stage execution
- [ ] `aidlc-state.md` updated after each stage completion
