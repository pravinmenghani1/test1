# Multi-Agent Coordination — Opt-In

**Extension**: Multi-Agent Coordination (COORD rules)

**Question**: Will multiple AI agents or sessions work on this project simultaneously?

```
A) Yes — multiple agents or sessions will work in parallel (ENABLE multi-agent coordination rules)
B) No — only a single agent session at a time (SKIP multi-agent coordination rules)
```

[Answer]:

---

**If A selected**: Rules COORD-01 through COORD-04 are enforced. Agents must use branch
isolation, follow the escalation policy after 2 consecutive CI failures, resolve conflicts
via human review, and synchronize state via `aidlc-docs/aidlc-state.md`.

**If B selected**: Multi-agent coordination rules are skipped for this workflow.
