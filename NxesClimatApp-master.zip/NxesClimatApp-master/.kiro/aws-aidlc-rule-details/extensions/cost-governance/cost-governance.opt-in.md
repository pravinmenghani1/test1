# Cost & Token Budget Governance — Opt-In

**Extension**: Cost & Token Budget Governance (COST rules)

**Question**: Do you want to enforce token budget limits and cost tracking for this workflow?

```
A) Yes — enforce token budgets, model-tier selection, and cost logging (ENABLE cost governance)
B) No — no cost constraints for this workflow (SKIP cost governance)
```

[Answer]:

---

**If A selected**: Rules COST-01 through COST-04 are enforced. The agent will select models
by task complexity, minimize context window usage, log token usage per phase, flag budget
overruns for human review, and produce a cost summary at workflow end.

**If B selected**: Cost governance rules are skipped for this workflow.
