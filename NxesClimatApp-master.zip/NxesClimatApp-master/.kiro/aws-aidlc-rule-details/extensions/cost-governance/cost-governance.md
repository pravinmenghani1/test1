# Cost & Token Budget Governance Rules

**Purpose**: Prevent runaway API costs and enforce efficient model usage across AI-DLC phases.

---

## Rule COST-01: Model Selection by Task Complexity

The agent MUST select the appropriate model tier based on task complexity.

**Rule**:

| Task Type | Model Tier | Examples |
| --------- | ---------- | -------- |
| Routine | Lightweight / open-weight | Formatting, simple refactors, boilerplate generation |
| Standard | Mid-tier | Requirements analysis, unit test generation, documentation |
| Complex | Frontier | Architecture decisions, security review, cross-repo reasoning |

The agent MUST log the model tier used for each phase in `aidlc-docs/metrics/cost-log.md`.

**Verification**:

- [ ] Model tier matches task complexity
- [ ] Model tier logged per phase in `aidlc-docs/metrics/cost-log.md`

---

## Rule COST-02: Context Window Efficiency

The agent MUST minimize context window usage by preferring targeted references over full-file inclusion.

**Rule**:

1. Use function signatures and type definitions before including full file contents
2. Use AST-level references (e.g., `ClassName.methodName`) before falling back to full-text
3. Load rule detail files on-demand (only when the phase requires them)
4. Unload large artifacts from context after the phase that produced them completes

**Verification**:

- [ ] Full file contents not included when a signature or excerpt suffices
- [ ] Rule detail files loaded only for the active phase
- [ ] Context does not carry forward large artifacts from completed phases

---

## Rule COST-03: Phase Token Budget

Each AI-DLC phase has a recommended token budget. The agent MUST log actual usage and
flag overruns for human review.

**Recommended budgets** (adjust based on project size):

| Phase | Recommended Budget |
| ----- | ------------------ |
| Workspace Detection | 2K tokens |
| Reverse Engineering | 20K tokens |
| Requirements Analysis | 8K tokens |
| User Stories | 6K tokens |
| Workflow Planning | 4K tokens |
| Application Design | 8K tokens |
| Units Generation | 4K tokens |
| Functional Design (per unit) | 6K tokens |
| NFR Requirements (per unit) | 4K tokens |
| NFR Design (per unit) | 4K tokens |
| Infrastructure Design (per unit) | 4K tokens |
| Code Generation (per unit) | 20K tokens |
| Build and Test | 6K tokens |

**Rule**: If a phase exceeds 2× its recommended budget, the agent MUST:

1. Pause and log the overrun in `aidlc-docs/metrics/cost-log.md`
2. Explain the reason for the overrun to the user
3. Ask the user whether to continue or scope-reduce before proceeding

**Verification**:

- [ ] Token usage logged per phase
- [ ] Overruns (>2× budget) flagged and user consulted before continuing

---

## Rule COST-04: Cost-Per-Feature Tracking

The agent MUST record cumulative token usage at workflow completion.

**Rule**: At the end of each AI-DLC workflow, append a summary to `aidlc-docs/metrics/cost-log.md`:

```markdown
## Cost Summary — <workflow name> — <ISO date>
| Phase | Model Tier | Approx. Tokens |
| ----- | ---------- | -------------- |
| ...   | ...        | ...            |
| **Total** | | **<sum>** |
```

**Verification**:

- [ ] Cost summary appended to `aidlc-docs/metrics/cost-log.md` at workflow end
