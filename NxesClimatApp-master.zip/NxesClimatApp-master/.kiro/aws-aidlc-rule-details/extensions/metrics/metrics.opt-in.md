# Metrics & Observability — Opt-In

**Extension**: Metrics & Observability (METRICS rules)

**Question**: Do you want AI-DLC to track phase durations, human interventions, and workflow outcomes?

```
A) Yes — enable phase timing, intervention logging, and outcome tracking (ENABLE metrics)
B) No — skip metrics collection for this workflow (SKIP metrics)
```

[Answer]:

---

**If A selected**: Rules METRICS-01 through METRICS-03 are enforced.
**If B selected**: Metrics extension is skipped.
