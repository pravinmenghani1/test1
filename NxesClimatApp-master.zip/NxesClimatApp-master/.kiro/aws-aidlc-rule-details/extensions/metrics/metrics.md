# Metrics & Observability Rules

**Purpose**: Track AI-DLC workflow performance to enable continuous improvement.

---

## Rule METRICS-01: Phase Duration Tracking

The agent MUST log start and end timestamps for each AI-DLC phase.

**Rule**: Append to `aidlc-docs/metrics/phase-durations.md` at phase start and end:

```markdown
| Phase | Start | End | Duration |
| ----- | ----- | --- | -------- |
| Workspace Detection | <ISO> | <ISO> | <mins> |
```

**Verification**:

- [ ] Start timestamp logged when phase begins
- [ ] End timestamp logged when phase completes or is skipped
- [ ] `aidlc-docs/metrics/phase-durations.md` exists and is current

---

## Rule METRICS-02: Human Intervention Logging

Every human override, correction, or rejection MUST be logged.

**Rule**: Append to `aidlc-docs/metrics/interventions.md`:

```markdown
## Intervention — <ISO timestamp>
**Phase**: <phase name>
**Type**: Override / Correction / Rejection / Scope Change
**Reason**: "<user's stated reason>"
**Time to Resolve**: <estimated minutes>
```

**Verification**:

- [ ] Every "Request Changes" response logged as an intervention
- [ ] Every rejected artifact logged with reason
- [ ] `aidlc-docs/metrics/interventions.md` exists

---

## Rule METRICS-03: Workflow Outcome Summary

At workflow completion, the agent MUST write a summary to `aidlc-docs/metrics/outcome.md`.

**Rule**: Include:

- Phases executed vs. skipped
- Total interventions count
- Total elapsed time (sum of phase durations)
- Extensions enabled

```markdown
## Workflow Outcome — <ISO date>
**Phases Executed**: <list>
**Phases Skipped**: <list>
**Extensions Enabled**: <list>
**Total Interventions**: <count>
**Total Duration**: <mins>
```

**Verification**:

- [ ] `aidlc-docs/metrics/outcome.md` written at workflow end
- [ ] All executed and skipped phases listed
