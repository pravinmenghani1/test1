# Compliance & Audit Trail — Opt-In

**Extension**: Compliance & Audit Trail (AUDIT rules)

**Question**: Does this project require compliance logging (regulated industries, AI Act, NIST AI RMF)?

```
A) Yes — enforce structured audit trail, IP attribution, and data residency rules (ENABLE compliance)
B) No — standard audit.md logging is sufficient (SKIP compliance extension)
```

[Answer]:

---

**If A selected**: Rules AUDIT-01 through AUDIT-03 are enforced.
**If B selected**: Compliance extension is skipped.
