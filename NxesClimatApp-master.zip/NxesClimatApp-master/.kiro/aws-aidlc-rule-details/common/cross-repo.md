# Cross-Repository Coordination

**Purpose**: Guide agents when a change spans multiple repositories (polyrepo or monorepo sub-packages).

---

## When Cross-Repo Rules Apply

These rules apply when:

- A shared library, API contract, or schema is being modified
- The change requires coordinated updates across two or more repositories
- A breaking change in one repo affects consumers in other repos

---

## Rule XREPO-01: Dependency Impact Analysis

Before modifying a shared interface, the agent MUST identify all consuming repositories
and assess breaking change impact.

**Steps**:

1. Search for consumers of the interface (grep, dependency graph, or package registry)
2. List all affected repos in `aidlc-docs/inception/cross-repo-impact.md`
3. Classify each change as **non-breaking**, **additive**, or **breaking**
4. For breaking changes, define a migration path before proceeding

**Verification**:

- [ ] Consumer repos identified and listed
- [ ] Each change classified (non-breaking / additive / breaking)
- [ ] Migration path documented for any breaking change

---

## Rule XREPO-02: API Versioning

When a shared API or contract changes in a breaking way, the agent MUST apply versioning.

**Rule**:

- Increment the major version (semver) for breaking changes
- Maintain the previous version for at least one release cycle
- Document the deprecation timeline in the API's changelog

**Verification**:

- [ ] Major version incremented for breaking changes
- [ ] Previous version still functional and documented as deprecated
- [ ] Deprecation timeline stated

---

## Rule XREPO-03: Coordinated PR Sequencing

When multiple repos need simultaneous updates, the agent MUST propose a safe merge order.

**Rule**:

1. Identify the dependency direction (which repo depends on which)
2. Propose merge order: dependency first, then consumers
3. Document the sequence in `aidlc-docs/inception/cross-repo-impact.md`
4. Flag any circular dependencies for human resolution

**Verification**:

- [ ] Merge order documented
- [ ] No circular dependencies (or flagged for human resolution)
- [ ] Each PR references the coordinated change set

---

## Cross-Repo Impact Document Format

Create `aidlc-docs/inception/cross-repo-impact.md` when cross-repo changes are detected:

```markdown
## Cross-Repo Impact Analysis
**Changed Interface**: <name>
**Change Type**: non-breaking / additive / breaking

### Affected Repositories
| Repo | Impact | Action Required | PR Link |
| ---- | ------ | --------------- | ------- |
| ...  | ...    | ...             | ...     |

### Merge Order
1. <repo-name> — reason
2. <repo-name> — reason

### Migration Path (if breaking)
<describe steps consumers must take>
```
