# Rollback & Recovery

**Purpose**: Define how to safely undo or recover from a failed or partial AI-DLC workflow cycle.

---

## When to Rollback

Initiate rollback when:

- A phase produced artifacts that were rejected and cannot be corrected
- `aidlc-docs/` is in an inconsistent state (e.g., partial phase completion)
- The user explicitly requests "undo" or "start over"
- A Construction phase produced code that breaks the build and cannot be fixed in 2 attempts

---

## Rollback Procedure

### Step 1 — Identify Rollback Scope

Read `aidlc-docs/aidlc-state.md` to determine which phases completed successfully.
Rollback only the phases that need to be undone; preserve earlier approved phases.

### Step 2 — Revert Code Changes (if any)

If code was generated, revert using git:

```bash
# Revert to the commit before AI-DLC code generation started
git revert <commit-range> --no-commit
# Review the revert, then commit
git commit -m "chore: rollback AI-DLC code generation for <unit-name>"
```

Do NOT use `git reset --hard` without explicit user confirmation — it is destructive.

### Step 3 — Archive (Do Not Delete) aidlc-docs Artifacts

Move rejected artifacts to `aidlc-docs/rollback/<ISO-date>/` rather than deleting them.
This preserves the audit trail.

```
aidlc-docs/
└── rollback/
    └── 2025-05-16T10:00:00Z/
        ├── construction/          # moved from aidlc-docs/construction/
        └── rollback-reason.md     # why rollback was initiated
```

### Step 4 — Update aidlc-state.md

Reset the affected phases to `NOT_STARTED` in `aidlc-docs/aidlc-state.md` and log the rollback event.

### Step 5 — Resume

After rollback, the user may resume from the last approved phase. The agent MUST re-read
`aidlc-docs/aidlc-state.md` before resuming to avoid re-executing completed phases.

---

## Partial Phase Recovery

If a phase was interrupted mid-execution (e.g., session timeout):

1. Read `aidlc-docs/aidlc-state.md` — look for phases marked `IN_PROGRESS`
2. Read the plan file for that phase (e.g., `aidlc-docs/inception/plans/`) to find the last completed checkbox
3. Resume from the next unchecked step — do NOT restart the phase from scratch
4. If the plan file is missing or corrupted, restart only that phase after confirming with the user

---

## aidlc-docs Corruption Recovery

If `aidlc-docs/` is corrupted or missing:

1. Check git history: `git log --oneline -- aidlc-docs/`
2. Restore from the last known-good commit: `git checkout <commit> -- aidlc-docs/`
3. Inform the user of what was restored and what was lost
4. Resume from the last approved phase
