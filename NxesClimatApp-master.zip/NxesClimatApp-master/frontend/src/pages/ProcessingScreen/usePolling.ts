import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { pollJobStatus } from '@/services/analysis'
import { storage } from '@/utils/storage'
import type { AnalysisResult } from '@/types'

const POLL_INTERVAL_MS = 5000
const TIMEOUT_MS = 120000

const STEP_LABELS = [
  'Checking MRV feasibility',
  'Evaluating financial logic',
  'Assessing risks',
  'Validating additionality',
]

export function usePolling() {
  const navigate = useNavigate()
  const [completedSteps, setCompletedSteps] = useState<string[]>([])
  const [timedOut, setTimedOut] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    const sessionId = storage.getSessionId()
    if (!sessionId) { navigate('/try'); return }

    // Timeout after 2 minutes
    timeoutRef.current = setTimeout(() => {
      setTimedOut(true)
    }, TIMEOUT_MS)

    intervalRef.current = setInterval(async () => {
      try {
        const status = await pollJobStatus(sessionId)
        if (status.progress) setCompletedSteps(status.progress)

        if (status.status === 'complete' && status.result) {
          cleanup()
          navigate('/result', { state: { result: status.result } })
        } else if (status.status === 'failed') {
          cleanup()
          setError(status.error ?? 'Analysis failed. Please try again.')
        }
      } catch {
        // transient network error — keep polling
      }
    }, POLL_INTERVAL_MS)

    return cleanup
  }, [navigate])

  function cleanup() {
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
  }

  const progress = Math.round((completedSteps.length / STEP_LABELS.length) * 100)

  return { completedSteps, progress, timedOut, error, STEP_LABELS }
}
