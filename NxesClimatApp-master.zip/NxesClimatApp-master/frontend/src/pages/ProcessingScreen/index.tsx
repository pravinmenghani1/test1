import { CheckCircle, Circle } from 'lucide-react'
import { usePolling } from './usePolling'

/** Screen 3 — Processing / Loading (US-03.1, US-03.2) */
export function ProcessingScreen() {
  const { completedSteps, progress, timedOut, error, STEP_LABELS } = usePolling()

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Analyzing your project...</h1>
        <p className="text-gray-500 mb-8">This usually takes less than 2 minutes.</p>

        {/* Animated steps */}
        <div className="space-y-3 mb-8 text-left" role="list" aria-label="Analysis progress">
          {STEP_LABELS.map((step, i) => {
            const done = completedSteps.includes(step)
            const active = !done && completedSteps.length === i
            return (
              <div key={step} className="flex items-center gap-3" role="listitem">
                {done
                  ? <CheckCircle className="text-decision-go flex-shrink-0" size={20} aria-label="Complete" />
                  : <Circle className={`flex-shrink-0 ${active ? 'text-brand-blue animate-pulse' : 'text-gray-300'}`} size={20} aria-label="Pending" />
                }
                <span className={`text-sm ${done ? 'text-gray-800 font-medium' : active ? 'text-brand-blue' : 'text-gray-400'}`}>
                  {step}
                </span>
              </div>
            )
          })}
        </div>

        {/* Progress bar */}
        <div
          className="w-full bg-gray-200 rounded-full h-2 mb-4"
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Overall analysis progress"
        >
          <div
            className="bg-brand-blue h-2 rounded-full transition-all duration-700"
            style={{ width: `${progress}%` }}
          />
        </div>

        {timedOut && (
          <p className="text-sm text-amber-600 mt-2">Still working — almost there...</p>
        )}
        {error && (
          <p className="text-sm text-red-600 mt-2">{error}</p>
        )}
      </div>
    </div>
  )
}
