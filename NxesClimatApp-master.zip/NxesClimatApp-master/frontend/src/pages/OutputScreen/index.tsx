import { useLocation, useNavigate } from 'react-router-dom'
import { Download } from 'lucide-react'
import { DecisionBadge } from '@/components/DecisionBadge'
import { ScoreBar } from '@/components/ScoreBar'
import { downloadPilotPdf } from '@/services/analysis'
import { storage } from '@/utils/storage'
import type { AnalysisResult } from '@/types'

/** Screen 4 — Decision Output / "Aha Moment" (US-04.1, US-04.2, US-04.3, US-04.4) */
export function OutputScreen() {
  const location = useLocation()
  const navigate = useNavigate()
  const result = location.state?.result as AnalysisResult | undefined

  if (!result) {
    navigate('/try')
    return null
  }

  const nextStep =
    result.decision === 'GO'
      ? 'Your project shows strong viability. Create an account to access the full report and begin the carbon credit process.'
      : result.decision === 'REVISE'
      ? 'Your project needs refinement in key areas. Create an account to access detailed recommendations.'
      : 'Your project faces significant challenges. Create an account to explore a detailed breakdown and alternative approaches.'

  async function handleDownloadPdf() {
    const sessionId = storage.getSessionId()
    if (sessionId) await downloadPilotPdf(sessionId)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-lg w-full bg-white rounded-2xl shadow-lg p-8">

        {/* Decision card */}
        <div className="text-center mb-6">
          <p className="text-xs text-gray-500 uppercase tracking-wide mb-3">Your Decision</p>
          <DecisionBadge decision={result.decision} size="lg" />
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-4 mb-6 text-center">
          <div data-testid="output-score">
            <p className="text-3xl font-bold text-gray-900">{result.score}</p>
            <p className="text-xs text-gray-500">Score</p>
          </div>
          <div data-testid="output-risk-level">
            <p className="text-xl font-semibold text-gray-700">{result.risk_level}</p>
            <p className="text-xs text-gray-500">Risk Level</p>
          </div>
          <div>
            <p className="text-xl font-semibold text-gray-700">{result.readiness}%</p>
            <p className="text-xs text-gray-500">Readiness</p>
          </div>
        </div>

        <ScoreBar value={result.score} label="Overall Score" />

        {/* Key issues */}
        <div className="mt-6" data-testid="output-key-issues-list">
          <p className="text-sm font-semibold text-gray-700 mb-2">Key Issues</p>
          <ul className="space-y-2">
            {result.key_issues.map((issue, i) => (
              <li key={i} className="text-sm text-gray-600 flex gap-2">
                <span className="text-brand-green mt-0.5 flex-shrink-0">•</span>
                {issue}
              </li>
            ))}
          </ul>
        </div>

        {/* Next step */}
        <div className="mt-6 bg-gray-50 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Next Step</p>
          <p className="text-sm text-gray-700">{nextStep}</p>
        </div>

        {/* Actions */}
        <div className="mt-6 space-y-3">
          <button
            onClick={handleDownloadPdf}
            className="w-full flex items-center justify-center gap-2 border border-gray-300 text-gray-700 py-2.5 rounded-xl text-sm hover:border-brand-green hover:text-brand-green transition-colors"
            data-testid="output-download-pdf-button"
          >
            <Download size={16} />
            Download PDF Summary
          </button>
          <button
            onClick={() => navigate('/signup')}
            className="w-full bg-brand-green text-white py-3 rounded-xl font-semibold hover:bg-brand-green-light transition-colors"
            data-testid="output-signup-cta-button"
          >
            Create account to unlock full report
          </button>
        </div>
      </div>
    </div>
  )
}
