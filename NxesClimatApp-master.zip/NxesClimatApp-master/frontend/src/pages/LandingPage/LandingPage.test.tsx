import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, it, expect, vi } from 'vitest'
import { LandingPage } from './index'

const mockNavigate = vi.fn()
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom')
  return { ...actual, useNavigate: () => mockNavigate }
})

function renderLanding() {
  return render(<MemoryRouter><LandingPage /></MemoryRouter>)
}

describe('LandingPage', () => {
  it('renders hero title', () => {
    renderLanding()
    expect(screen.getByText(/Validate climate projects/i)).toBeInTheDocument()
  })

  it('navigates to /try on CTA click', () => {
    renderLanding()
    fireEvent.click(screen.getByTestId('landing-try-button'))
    expect(mockNavigate).toHaveBeenCalledWith('/try')
  })

  it('shows example modal on "See example" click', () => {
    renderLanding()
    fireEvent.click(screen.getByTestId('landing-see-example-button'))
    expect(screen.getByRole('dialog')).toBeInTheDocument()
  })

  it('closes example modal', () => {
    renderLanding()
    fireEvent.click(screen.getByTestId('landing-see-example-button'))
    fireEvent.click(screen.getByTestId('example-modal-close'))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })
})
