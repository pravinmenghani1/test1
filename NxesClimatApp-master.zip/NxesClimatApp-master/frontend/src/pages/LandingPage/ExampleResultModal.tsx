import { X } from 'lucide-react'
import { DecisionBadge } from '@/components/DecisionBadge'
import { ScoreBar } from '@/components/ScoreBar'

const SAMPLE = {
  decision: 'REVISE' as const,
  score: 58,
  risk_level: 'Medium',
  key_issues: [
    'Revenue model needs clarification',
    'MRV framework requires additional documentation',
    'High dependency on external funding',
  ],
}

export function ExampleResultModal({ onClose }: { onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Example analysis result"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          aria-label="Close example"
          data-testid="example-modal-close"
        >
          <X size={20} />
        </button>

        <p className="text-xs text-gray-500 uppercase tracking-wide mb-3">Example result</p>
        <div className="flex items-center gap-4 mb-4">
          <DecisionBadge decision={SAMPLE.decision} size="lg" />
          <div>
            <p className="text-2xl font-bold text-gray-800">{SAMPLE.score}</p>
            <p className="text-sm text-gray-500">Score</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-decision-revise">{SAMPLE.risk_level}</p>
            <p className="text-sm text-gray-500">Risk</p>
          </div>
        </div>

        <ScoreBar value={SAMPLE.score} label="Readiness" />

        <div className="mt-4">
          <p className="text-sm font-semibold text-gray-700 mb-2">Key Issues</p>
          <ul className="space-y-1">
            {SAMPLE.key_issues.map((issue, i) => (
              <li key={i} className="text-sm text-gray-600 flex gap-2">
                <span className="text-decision-revise mt-0.5">•</span>
                {issue}
              </li>
            ))}
          </ul>
        </div>

        <p className="mt-4 text-xs text-gray-400 text-center">
          This is a sample result. Submit your own project to get a real analysis.
        </p>
      </div>
    </div>
  )
}
