import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Zap, Shield, Leaf, BarChart3 } from 'lucide-react'
import { ExampleResultModal } from './ExampleResultModal'

const VALUES = [
  { icon: Zap, label: 'Faster decisions' },
  { icon: Shield, label: 'Lower risk' },
  { icon: Leaf, label: 'Better impact' },
  { icon: BarChart3, label: 'More transparency' },
]

/** Screen 1 — Landing Page (US-01.1, US-01.2, US-01.3) */
export function LandingPage() {
  const navigate = useNavigate()
  const [showExample, setShowExample] = useState(false)

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
        <span className="text-xl font-bold text-brand-green">NxES</span>
        <div className="flex items-center gap-6 text-sm text-gray-600">
          <a href="#how" className="hover:text-brand-green transition-colors">How it works</a>
          <a href="#cases" className="hover:text-brand-green transition-colors">Use cases</a>
          <button
            onClick={() => navigate('/login')}
            className="text-brand-blue hover:underline"
            data-testid="landing-login-link"
          >
            Login
          </button>
        </div>
      </nav>

      {/* Hero */}
      <main className="max-w-5xl mx-auto px-6 py-20 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-4">
          Validate climate projects<br />
          <span className="text-brand-green">before capital is deployed</span>
        </h1>
        <p className="text-lg text-gray-600 mb-10 max-w-xl mx-auto">
          Get a structured GO / NO-GO decision in minutes. No account required.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => navigate('/try')}
            className="bg-brand-green text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-brand-green-light transition-colors shadow-lg"
            data-testid="landing-try-button"
          >
            Try Decision Core (Pilot)
          </button>
          <button
            onClick={() => setShowExample(true)}
            className="border border-gray-300 text-gray-700 px-8 py-4 rounded-xl text-lg hover:border-brand-green hover:text-brand-green transition-colors"
            data-testid="landing-see-example-button"
          >
            See example →
          </button>
        </div>
      </main>

      {/* Value strip */}
      <section className="bg-gray-50 py-12">
        <div className="max-w-4xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {VALUES.map(({ icon: Icon, label }) => (
            <div key={label} className="flex flex-col items-center gap-2">
              <Icon className="text-brand-green" size={28} />
              <span className="text-sm font-medium text-gray-700">{label}</span>
            </div>
          ))}
        </div>
      </section>

      {showExample && <ExampleResultModal onClose={() => setShowExample(false)} />}
    </div>
  )
}
