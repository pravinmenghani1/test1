import { Upload } from 'lucide-react'
import { useInputForm } from './useInputForm'

/** Screen 2 — Input Form (US-02.1, US-02.2, US-02.3, US-02.4) */
export function InputForm() {
  const { form, errors, submitting, setField, handleFileChange, handleSubmit, PROJECT_TYPES, STAGES } = useInputForm()

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 bg-white rounded-2xl shadow-lg p-8">

        {/* Left: Input panel */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-6">Start your project validation</h1>
          <form onSubmit={handleSubmit} noValidate className="space-y-4">

            {/* Project Type */}
            <div>
              <label htmlFor="project_type" className="block text-sm font-medium text-gray-700 mb-1">
                Project Type <span className="text-red-500">*</span>
              </label>
              <select
                id="project_type"
                value={form.project_type}
                onChange={e => setField('project_type', e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-green"
                data-testid="input-form-project-type"
              >
                <option value="">Select project type</option>
                {PROJECT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
              {errors.project_type && <p className="text-red-500 text-xs mt-1">{errors.project_type}</p>}
            </div>

            {/* Location */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                Location (Country) <span className="text-red-500">*</span>
              </label>
              <input
                id="location"
                type="text"
                value={form.location}
                onChange={e => setField('location', e.target.value)}
                placeholder="e.g. Kenya"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-green"
                data-testid="input-form-location"
              />
              {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location}</p>}
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Short Description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="description"
                value={form.description}
                onChange={e => setField('description', e.target.value)}
                rows={3}
                maxLength={500}
                placeholder="Briefly describe your project..."
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-green resize-none"
                data-testid="input-form-description"
              />
              <p className="text-xs text-gray-400 text-right">{form.description.length}/500</p>
              {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
            </div>

            {/* Stage */}
            <div>
              <label htmlFor="stage" className="block text-sm font-medium text-gray-700 mb-1">
                Stage <span className="text-gray-400 text-xs">(optional)</span>
              </label>
              <select
                id="stage"
                value={form.stage}
                onChange={e => setField('stage', e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-green"
                data-testid="input-form-stage"
              >
                <option value="">Select stage</option>
                {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            {/* File upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Supporting Document <span className="text-gray-400 text-xs">(optional, max 5MB)</span>
              </label>
              <label
                className="flex items-center gap-2 border border-dashed border-gray-300 rounded-lg px-3 py-3 cursor-pointer hover:border-brand-green transition-colors"
                data-testid="input-form-file-upload"
              >
                <Upload size={16} className="text-gray-400" />
                <span className="text-sm text-gray-500">
                  {form.file ? form.file.name : 'Upload PDF, Excel, CSV, or Word'}
                </span>
                <input
                  type="file"
                  accept=".pdf,.xlsx,.xls,.csv,.doc,.docx"
                  className="hidden"
                  onChange={e => handleFileChange(e.target.files?.[0] ?? null)}
                />
              </label>
              {errors.file && <p className="text-red-500 text-xs mt-1">{errors.file}</p>}
            </div>

            {errors.submit && <p className="text-red-500 text-sm">{errors.submit}</p>}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-brand-green text-white py-3 rounded-xl font-semibold text-lg hover:bg-brand-green-light transition-colors disabled:opacity-60"
              data-testid="input-form-submit-button"
            >
              {submitting ? 'Submitting...' : 'Run Analysis'}
            </button>
          </form>
        </div>

        {/* Right: Explanation panel (US-02.4) */}
        <div className="bg-gray-50 rounded-xl p-6 flex flex-col justify-center">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">What happens next?</h2>
          <ol className="space-y-4">
            {[
              { n: 1, title: 'Analysis', desc: 'We analyse your project across 4 key dimensions' },
              { n: 2, title: 'Scoring', desc: 'Each dimension is scored and weighted into a composite result' },
              { n: 3, title: 'Decision', desc: 'You receive a clear GO / REVISE / NO-GO decision' },
            ].map(({ n, title, desc }) => (
              <li key={n} className="flex gap-3">
                <span className="w-7 h-7 rounded-full bg-brand-green text-white text-sm font-bold flex items-center justify-center flex-shrink-0">
                  {n}
                </span>
                <div>
                  <p className="font-medium text-gray-800">{title}</p>
                  <p className="text-sm text-gray-500">{desc}</p>
                </div>
              </li>
            ))}
          </ol>
          <p className="mt-6 text-xs text-gray-400">No account required. Results in under 2 minutes.</p>
        </div>
      </div>
    </div>
  )
}
