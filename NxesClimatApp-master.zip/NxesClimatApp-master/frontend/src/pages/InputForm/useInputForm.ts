import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { submitAnalysis } from '@/services/analysis'
import { storage } from '@/utils/storage'

const PROJECT_TYPES = [
  'Forestry/REDD+', 'Renewable Energy', 'Cookstoves',
  'Waste-to-Energy', 'Blue Carbon', 'Agriculture',
]
const STAGES = ['Idea', 'Pilot', 'Scaling']
const MAX_FILE_BYTES = 5 * 1024 * 1024 // 5MB
const ACCEPTED_TYPES = ['application/pdf', 'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/csv', 'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document']

interface FormState {
  project_type: string
  location: string
  description: string
  stage: string
  file: File | null
}

export function useInputForm() {
  const navigate = useNavigate()
  const [form, setForm] = useState<FormState>({
    project_type: '', location: '', description: '', stage: '', file: null,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)

  function setField(field: keyof FormState, value: string | File | null) {
    setForm(prev => ({ ...prev, [field]: value }))
    setErrors(prev => ({ ...prev, [field]: '' }))
  }

  function handleFileChange(file: File | null) {
    if (!file) { setField('file', null); return }
    if (file.size > MAX_FILE_BYTES) {
      setErrors(prev => ({ ...prev, file: 'File must be 5MB or smaller' }))
      return
    }
    if (!ACCEPTED_TYPES.includes(file.type)) {
      setErrors(prev => ({ ...prev, file: 'Accepted formats: PDF, Excel, CSV, Word' }))
      return
    }
    setField('file', file)
  }

  function validate(): boolean {
    const errs: Record<string, string> = {}
    if (!form.project_type) errs.project_type = 'Project type is required'
    if (!form.location.trim()) errs.location = 'Location is required'
    if (!form.description.trim()) errs.description = 'Description is required'
    if (form.description.length > 500) errs.description = 'Max 500 characters'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!validate()) return
    setSubmitting(true)
    try {
      let fileRef: string | undefined
      if (form.file) {
        fileRef = await readFileAsBase64(form.file)
        storage.setFileRef(fileRef.slice(0, 100)) // store metadata only
      }
      const { session_id } = await submitAnalysis({
        project_type: form.project_type,
        location: form.location,
        description: form.description,
        stage: form.stage || undefined,
        file_reference: fileRef ? `${form.file!.name}:${form.file!.size}` : undefined,
      })
      storage.setSessionId(session_id)
      navigate('/analyzing')
    } catch {
      setErrors({ submit: 'Something went wrong. Please try again.' })
    } finally {
      setSubmitting(false)
    }
  }

  return { form, errors, submitting, setField, handleFileChange, handleSubmit, PROJECT_TYPES, STAGES }
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}
