import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listProjects } from '@/services/projects'
import { DecisionBadge } from '@/components/DecisionBadge'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import type { Project } from '@/types'

/** Decision history (US-06.6) */
export function DecisionHistory() {
  const navigate = useNavigate()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    listProjects()
      .then(p => setProjects([...p].sort((a, b) => b.created_at.localeCompare(a.created_at))))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="p-8"><LoadingSpinner /></div>

  return (
    <div className="p-8">
      <h1 className="text-xl font-bold text-gray-900 mb-6">Decision History</h1>
      {projects.length === 0 ? (
        <p className="text-gray-500">No decisions yet.</p>
      ) : (
        <div className="space-y-3">
          {projects.map(p => (
            <button
              key={p.project_id}
              onClick={() => navigate(`/dashboard/projects/${p.project_id}`)}
              className="w-full text-left bg-white border border-gray-100 rounded-xl p-4 hover:border-brand-green transition-colors"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">{p.project_type} · {p.location}</p>
                  <p className="text-xs text-gray-400">{new Date(p.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-gray-700">{p.score}</span>
                  <DecisionBadge decision={p.decision} />
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
