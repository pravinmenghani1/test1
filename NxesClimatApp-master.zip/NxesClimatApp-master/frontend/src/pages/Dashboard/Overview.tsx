import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listProjects } from '@/services/projects'
import { DecisionBadge } from '@/components/DecisionBadge'
import { ScoreBar } from '@/components/ScoreBar'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import type { Project } from '@/types'

/** Dashboard Overview — first login experience (US-06.1) */
export function Overview() {
  const navigate = useNavigate()
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    listProjects()
      .then(projects => setProject(projects[0] ?? null))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="p-8"><LoadingSpinner label="Loading your project..." /></div>

  if (!project) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500 mb-4">No projects yet.</p>
        <button
          onClick={() => navigate('/try')}
          className="bg-brand-green text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-brand-green-light"
        >
          Run your first analysis
        </button>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-2xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Welcome back</h1>
      <p className="text-gray-500 mb-6">{project.project_type} · {project.location}</p>

      {/* Project status card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-gray-800">{project.project_type}</h2>
          <DecisionBadge decision={project.decision} />
        </div>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-2xl font-bold text-gray-900">{project.score}</p>
            <p className="text-xs text-gray-500">Score</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-gray-700">{project.risk_level}</p>
            <p className="text-xs text-gray-500">Risk Level</p>
          </div>
        </div>
        <ScoreBar value={project.readiness} label="Readiness" />
      </div>

      {/* Report links */}
      <div className="space-y-2">
        {[
          { label: 'Decision Report', href: `/dashboard/projects/${project.project_id}` },
          { label: 'Risk Analysis', href: `/dashboard/projects/${project.project_id}` },
          { label: 'MRV Summary', href: `/dashboard/projects/${project.project_id}` },
        ].map(({ label, href }) => (
          <button
            key={label}
            onClick={() => navigate(href)}
            className="w-full text-left px-4 py-3 bg-white border border-gray-100 rounded-xl text-sm text-brand-blue hover:border-brand-green transition-colors"
          >
            {label} →
          </button>
        ))}
      </div>
    </div>
  )
}
