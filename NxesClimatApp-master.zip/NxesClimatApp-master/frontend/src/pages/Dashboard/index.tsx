import { Outlet } from 'react-router-dom'
import { Sidebar } from './Sidebar'

/** Dashboard shell (US-06.4) */
export function Dashboard() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  )
}
