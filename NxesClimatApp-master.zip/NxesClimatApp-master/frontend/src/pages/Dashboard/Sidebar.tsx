import { NavLink } from 'react-router-dom'
import { LayoutDashboard, FolderOpen, Database, CheckSquare, FileText } from 'lucide-react'
import { storage } from '@/utils/storage'
import { useNavigate } from 'react-router-dom'

const NAV = [
  { to: '/dashboard', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/dashboard/projects', label: 'Projects', icon: FolderOpen, end: false },
  { to: '/dashboard/data', label: 'Data', icon: Database, end: false },
  { to: '/dashboard/decisions', label: 'Decisions', icon: CheckSquare, end: false },
  { to: '/dashboard/reports', label: 'Reports', icon: FileText, end: false },
]

export function Sidebar() {
  const navigate = useNavigate()

  function handleLogout() {
    storage.clearAll()
    navigate('/login')
  }

  return (
    <aside className="w-56 bg-white border-r border-gray-100 flex flex-col min-h-screen">
      <div className="px-6 py-5 border-b border-gray-100">
        <span className="text-lg font-bold text-brand-green">NxES</span>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Dashboard navigation">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                isActive
                  ? 'bg-brand-green text-white font-medium'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`
            }
          >
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-gray-100">
        <button
          onClick={handleLogout}
          className="w-full text-left px-3 py-2 text-sm text-gray-500 hover:text-red-600 rounded-lg transition-colors"
        >
          Log out
        </button>
      </div>
    </aside>
  )
}
