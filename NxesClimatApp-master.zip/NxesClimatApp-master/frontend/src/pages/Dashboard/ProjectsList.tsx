import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listProjects } from '@/services/projects'
import { DecisionBadge } from '@/components/DecisionBadge'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import type { Project } from '@/types'

/** Projects list (US-06.5) */
export function ProjectsList() {
  const navigate = useNavigate()
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    listProjects().then(setProjects).finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="p-8"><LoadingSpinner /></div>

  if (projects.length === 0) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500 mb-4">No projects yet.</p>
        <button
          onClick={() => navigate('/try')}
          className="bg-brand-green text-white px-6 py-2 rounded-lg text-sm font-medium"
        >
          Start a new analysis
        </button>
      </div>
    )
  }

  return (
    <div className="p-8">
      <h1 className="text-xl font-bold text-gray-900 mb-6">Projects</h1>
      <div className="space-y-3">
        {projects.map(p => (
          <button
            key={p.project_id}
            onClick={() => navigate(`/dashboard/projects/${p.project_id}`)}
            className="w-full text-left bg-white border border-gray-100 rounded-xl p-4 hover:border-brand-green transition-colors shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">{p.project_type}</p>
                <p className="text-sm text-gray-500">{p.location} · Score: {p.score}</p>
              </div>
              <DecisionBadge decision={p.decision} />
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
