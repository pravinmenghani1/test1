import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Download } from 'lucide-react'
import { getFullReport, downloadFullPdf } from '@/services/projects'
import { DecisionBadge } from '@/components/DecisionBadge'
import { ScoreBar } from '@/components/ScoreBar'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import type { FullReport } from '@/types'

/** Full report view (US-06.2, US-06.3) */
export function FullReportView() {
  const { id } = useParams<{ id: string }>()
  const [report, setReport] = useState<FullReport | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!id) return
    getFullReport(id)
      .then(setReport)
      .catch(() => setError('Could not load report.'))
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <div className="p-8"><LoadingSpinner /></div>
  if (error || !report) return <div className="p-8 text-red-600">{error || 'Report not found.'}</div>

  return (
    <div className="p-8 max-w-2xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Full Decision Report</h1>
          <p className="text-sm text-gray-500">Score: {report.score} · {report.risk_level} risk</p>
        </div>
        <DecisionBadge decision={report.decision} />
      </div>

      <ScoreBar value={report.score} label="Overall Score" />

      {/* Module breakdown */}
      <div className="mt-8 space-y-6">
        <h2 className="font-semibold text-gray-800">Module Breakdown</h2>
        {Object.entries(report.modules).map(([name, detail]) => (
          <div key={name} className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="font-medium text-gray-800 uppercase text-sm">{name}</p>
              <span className="text-sm font-bold text-gray-700">{detail.score}/100</span>
            </div>
            {detail.benchmark_score !== undefined && (
              <p className="text-xs text-gray-400 mb-2">Benchmark: {detail.benchmark_score}/100</p>
            )}
            <ScoreBar value={detail.score} />
            <ul className="mt-3 space-y-1">
              {detail.recommendations.map((r, i) => (
                <li key={i} className="text-xs text-gray-600 flex gap-1">
                  <span className="text-brand-green">→</span> {r}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Benchmark summary */}
      <div className="mt-6 bg-blue-50 rounded-xl p-4">
        <p className="text-sm font-semibold text-brand-blue mb-1">Benchmark Comparison</p>
        <p className="text-sm text-gray-700">{report.benchmark_summary}</p>
      </div>

      {/* Download */}
      <button
        onClick={() => id && downloadFullPdf(id)}
        className="mt-6 w-full flex items-center justify-center gap-2 border border-gray-300 text-gray-700 py-2.5 rounded-xl text-sm hover:border-brand-green hover:text-brand-green transition-colors"
      >
        <Download size={16} />
        Download Full Report PDF
      </button>
    </div>
  )
}
