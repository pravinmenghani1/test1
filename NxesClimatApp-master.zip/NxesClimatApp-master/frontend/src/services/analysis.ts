import api from './api'
import type { AnalysisResult, JobStatusResponse } from '@/types'

export interface ProjectInput {
  project_type: string
  location: string
  description: string
  stage?: string
  file_reference?: string
}

export async function submitAnalysis(input: ProjectInput): Promise<{ session_id: string }> {
  const { data } = await api.post('/api/v1/analyze', input)
  return data
}

export async function pollJobStatus(sessionId: string): Promise<JobStatusResponse> {
  const { data } = await api.get(`/api/v1/analyze/${sessionId}`)
  return data
}

export async function downloadPilotPdf(sessionId: string): Promise<void> {
  const response = await api.get(`/api/v1/analyze/${sessionId}/pdf`, {
    responseType: 'blob',
  })
  const url = URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `nxes-pilot-${sessionId.slice(0, 8)}.pdf`
  a.click()
  URL.revokeObjectURL(url)
}
