import api from './api'
import type { AuthResponse } from '@/types'

export async function signup(
  email: string,
  password: string,
  sessionId?: string | null
): Promise<AuthResponse> {
  const { data } = await api.post('/api/v1/auth/signup', {
    email,
    password,
    session_id: sessionId ?? undefined,
  })
  return data
}

export async function login(email: string, password: string): Promise<AuthResponse> {
  const { data } = await api.post('/api/v1/auth/login', { email, password })
  return data
}
