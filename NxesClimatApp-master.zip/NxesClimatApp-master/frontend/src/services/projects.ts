import api from './api'
import type { FullReport, Project } from '@/types'

export async function listProjects(): Promise<Project[]> {
  const { data } = await api.get('/api/v1/projects')
  return data.projects
}

export async function getProject(projectId: string): Promise<Project> {
  const { data } = await api.get(`/api/v1/projects/${projectId}`)
  return data
}

export async function getFullReport(projectId: string): Promise<FullReport> {
  const { data } = await api.get(`/api/v1/projects/${projectId}/report`)
  return data
}

export async function downloadFullPdf(projectId: string): Promise<void> {
  const response = await api.get(`/api/v1/projects/${projectId}/pdf`, {
    responseType: 'blob',
  })
  const url = URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `nxes-report-${projectId.slice(0, 8)}.pdf`
  a.click()
  URL.revokeObjectURL(url)
}
