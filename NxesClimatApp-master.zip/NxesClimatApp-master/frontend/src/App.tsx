import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { LandingPage } from '@/pages/LandingPage'
import { InputForm } from '@/pages/InputForm'
import { ProcessingScreen } from '@/pages/ProcessingScreen'
import { OutputScreen } from '@/pages/OutputScreen'
import { SignupScreen } from '@/pages/SignupScreen'
import { LoginScreen } from '@/pages/LoginScreen'
import { Dashboard } from '@/pages/Dashboard'
import { Overview } from '@/pages/Dashboard/Overview'
import { ProjectsList } from '@/pages/Dashboard/ProjectsList'
import { FullReportView } from '@/pages/Dashboard/FullReportView'
import { DecisionHistory } from '@/pages/Dashboard/DecisionHistory'
import { ProtectedRoute } from '@/components/ProtectedRoute'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/try" element={<InputForm />} />
        <Route path="/analyzing" element={<ProcessingScreen />} />
        <Route path="/result" element={<OutputScreen />} />
        <Route path="/signup" element={<SignupScreen />} />
        <Route path="/login" element={<LoginScreen />} />

        {/* Protected dashboard routes */}
        <Route
          path="/dashboard"
          element={<ProtectedRoute><Dashboard /></ProtectedRoute>}
        >
          <Route index element={<Overview />} />
          <Route path="projects" element={<ProjectsList />} />
          <Route path="projects/:id" element={<FullReportView />} />
          <Route path="decisions" element={<DecisionHistory />} />
          <Route path="data" element={<div className="p-8 text-gray-500">Data view coming soon.</div>} />
          <Route path="reports" element={<Navigate to="/dashboard" replace />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
