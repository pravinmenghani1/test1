/** localStorage utility — centralised key names and helpers */

const KEYS = {
  SESSION_ID: 'nxes_session_id',
  TOKEN: 'nxes_token',
  USER_ID: 'nxes_user_id',
  FILE_REF: 'nxes_file_ref',
} as const

export const storage = {
  getSessionId: () => localStorage.getItem(KEYS.SESSION_ID),
  setSessionId: (id: string) => localStorage.setItem(KEYS.SESSION_ID, id),
  clearSessionId: () => localStorage.removeItem(KEYS.SESSION_ID),

  getToken: () => localStorage.getItem(KEYS.TOKEN),
  setToken: (token: string) => localStorage.setItem(KEYS.TOKEN, token),
  clearToken: () => localStorage.removeItem(KEYS.TOKEN),

  getUserId: () => localStorage.getItem(KEYS.USER_ID),
  setUserId: (id: string) => localStorage.setItem(KEYS.USER_ID, id),

  getFileRef: () => localStorage.getItem(KEYS.FILE_REF),
  setFileRef: (ref: string) => localStorage.setItem(KEYS.FILE_REF, ref),
  clearFileRef: () => localStorage.removeItem(KEYS.FILE_REF),

  clearSession: () => {
    localStorage.removeItem(KEYS.SESSION_ID)
    localStorage.removeItem(KEYS.FILE_REF)
  },

  clearAll: () => {
    Object.values(KEYS).forEach(k => localStorage.removeItem(k))
  },

  isTokenValid: (): boolean => {
    const token = localStorage.getItem(KEYS.TOKEN)
    if (!token) return false
    try {
      const payload = JSON.parse(atob(token.split('.')[1]))
      return payload.exp * 1000 > Date.now()
    } catch {
      return false
    }
  },
}
