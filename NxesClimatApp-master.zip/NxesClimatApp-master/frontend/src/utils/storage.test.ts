import { describe, it, expect, beforeEach } from 'vitest'
import { storage } from './storage'

beforeEach(() => localStorage.clear())

describe('storage', () => {
  it('sets and gets session id', () => {
    storage.setSessionId('abc-123')
    expect(storage.getSessionId()).toBe('abc-123')
  })

  it('clears session data', () => {
    storage.setSessionId('abc')
    storage.setFileRef('file')
    storage.clearSession()
    expect(storage.getSessionId()).toBeNull()
    expect(storage.getFileRef()).toBeNull()
  })

  it('returns false for missing token', () => {
    expect(storage.isTokenValid()).toBe(false)
  })

  it('returns false for expired token', () => {
    // JWT with exp in the past
    const payload = btoa(JSON.stringify({ exp: Math.floor(Date.now() / 1000) - 3600 }))
    storage.setToken(`header.${payload}.sig`)
    expect(storage.isTokenValid()).toBe(false)
  })
})
