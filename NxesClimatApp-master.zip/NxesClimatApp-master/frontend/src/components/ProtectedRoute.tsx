import { Navigate } from 'react-router-dom'
import { storage } from '@/utils/storage'

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  if (!storage.isTokenValid()) {
    return <Navigate to="/login" replace />
  }
  return <>{children}</>
}
