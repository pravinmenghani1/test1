import type { Decision } from '@/types'

interface Props {
  decision: Decision
  size?: 'sm' | 'lg'
}

const CONFIG: Record<Decision, { bg: string; text: string; label: string }> = {
  GO: { bg: 'bg-decision-go-bg', text: 'text-decision-go', label: 'GO' },
  REVISE: { bg: 'bg-decision-revise-bg', text: 'text-decision-revise', label: 'REVISE' },
  'NO-GO': { bg: 'bg-decision-nogo-bg', text: 'text-decision-nogo', label: 'NO-GO' },
}

/** Colour-coded decision badge — always includes text label for WCAG 2.1 AA compliance */
export function DecisionBadge({ decision, size = 'sm' }: Props) {
  const { bg, text, label } = CONFIG[decision]
  const sizeClass = size === 'lg'
    ? 'text-4xl font-bold px-8 py-4 rounded-2xl'
    : 'text-sm font-semibold px-3 py-1 rounded-full'

  return (
    <span
      className={`inline-block ${bg} ${text} ${sizeClass}`}
      aria-label={`Decision: ${label}`}
      data-testid="decision-badge"
    >
      {label}
    </span>
  )
}
