import { render, screen } from '@testing-library/react'
import { describe, it, expect } from 'vitest'
import { DecisionBadge } from './DecisionBadge'

describe('DecisionBadge', () => {
  it('renders GO with text label', () => {
    render(<DecisionBadge decision="GO" />)
    expect(screen.getByText('GO')).toBeInTheDocument()
  })

  it('renders REVISE with text label', () => {
    render(<DecisionBadge decision="REVISE" />)
    expect(screen.getByText('REVISE')).toBeInTheDocument()
  })

  it('renders NO-GO with text label', () => {
    render(<DecisionBadge decision="NO-GO" />)
    expect(screen.getByText('NO-GO')).toBeInTheDocument()
  })

  it('has aria-label for accessibility', () => {
    render(<DecisionBadge decision="GO" />)
    expect(screen.getByLabelText('Decision: GO')).toBeInTheDocument()
  })
})
