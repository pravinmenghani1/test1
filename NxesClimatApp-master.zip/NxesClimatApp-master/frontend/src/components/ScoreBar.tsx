interface Props {
  value: number   // 0-100
  label?: string
}

export function ScoreBar({ value, label }: Props) {
  const clamped = Math.max(0, Math.min(100, value))
  const color = clamped > 70 ? 'bg-decision-go' : clamped >= 40 ? 'bg-decision-revise' : 'bg-decision-nogo'

  return (
    <div className="w-full">
      {label && <span className="text-sm text-gray-600 mb-1 block">{label}</span>}
      <div
        className="w-full bg-gray-200 rounded-full h-3"
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label ?? 'Score'}
      >
        <div
          className={`${color} h-3 rounded-full transition-all duration-500`}
          style={{ width: `${clamped}%` }}
        />
      </div>
      <span className="text-xs text-gray-500 mt-1 block">{clamped}/100</span>
    </div>
  )
}
