export function LoadingSpinner({ label = 'Loading...' }: { label?: string }) {
  return (
    <div className="flex items-center gap-2" role="status" aria-label={label}>
      <div className="w-5 h-5 border-2 border-brand-blue border-t-transparent rounded-full animate-spin" />
      <span className="text-sm text-gray-600">{label}</span>
    </div>
  )
}
