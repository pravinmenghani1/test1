export type Decision = 'GO' | 'REVISE' | 'NO-GO'
export type RiskLevel = 'Low' | 'Medium' | 'High'
export type ProjectStage = 'Idea' | 'Pilot' | 'Scaling'

export interface ModuleScores {
  mrv: number
  financial: number
  risk: number
  additionality: number
}

export interface AnalysisResult {
  session_id: string
  decision: Decision
  score: number
  risk_level: RiskLevel
  readiness: number
  key_issues: string[]
  module_scores: ModuleScores
}

export interface JobStatusResponse {
  session_id: string
  status: 'queued' | 'processing' | 'complete' | 'failed'
  progress?: string[]
  result?: AnalysisResult
  error?: string
}

export interface Project {
  project_id: string
  project_type: string
  location: string
  description: string
  stage?: string
  decision: Decision
  score: number
  risk_level: RiskLevel
  readiness: number
  key_issues: string[]
  module_scores: ModuleScores
  created_at: string
}

export interface ModuleDetail {
  score: number
  issues: string[]
  recommendations: string[]
  benchmark_score?: number
}

export interface FullReport {
  project_id: string
  decision: Decision
  score: number
  risk_level: RiskLevel
  readiness: number
  key_issues: string[]
  modules: Record<string, ModuleDetail>
  benchmark_summary: string
}

export interface AuthResponse {
  token: string
  user_id: string
}
