/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Climate-tech palette
        brand: {
          green: '#1B5E20',
          'green-light': '#2E7D32',
          blue: '#0D47A1',
          'blue-light': '#1565C0',
          teal: '#00695C',
        },
        decision: {
          go: '#2E7D32',
          'go-bg': '#E8F5E9',
          revise: '#F57F17',
          'revise-bg': '#FFF8E1',
          nogo: '#C62828',
          'nogo-bg': '#FFEBEE',
        },
      },
    },
  },
  plugins: [],
}
