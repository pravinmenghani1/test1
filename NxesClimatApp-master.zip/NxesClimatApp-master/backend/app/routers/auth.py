"""Auth Router — signup and login."""
from fastapi import APIRouter, status

from app.models.requests import LoginRequest, SignupRequest
from app.models.responses import AuthResponse
from app.repositories.project_repository import ProjectRepository
from app.repositories.user_repository import UserRepository
from app.services.auth_service import AuthService

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


def _get_service() -> AuthService:
    return AuthService(UserRepository(), ProjectRepository())


@router.post("/signup", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def signup(request: SignupRequest) -> AuthResponse:
    """Create account. Optionally transfers anonymous pilot session to new account."""
    return await _get_service().signup(request)


@router.post("/login", response_model=AuthResponse)
async def login(request: LoginRequest) -> AuthResponse:
    """Login with email and password. Returns JWT."""
    return await _get_service().login(request)
