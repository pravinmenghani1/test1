"""Projects Router — project management and reports (JWT required)."""
from fastapi import APIRouter, Depends, status
from fastapi.responses import Response

from app.models.responses import FullReport, Project, ProjectListResponse
from app.repositories.project_repository import ProjectRepository
from app.services.auth_service import get_current_user
from app.services.pdf_service import generate_full_pdf
from app.services.project_service import ProjectService

router = APIRouter(prefix="/api/v1/projects", tags=["projects"])


def _get_service() -> ProjectService:
    return ProjectService(ProjectRepository())


@router.get("", response_model=ProjectListResponse)
async def list_projects(
    current_user: dict = Depends(get_current_user),
) -> ProjectListResponse:
    """List all projects for the authenticated user."""
    return await _get_service().get_projects(current_user["sub"])


@router.get("/{project_id}", response_model=Project)
async def get_project(
    project_id: str,
    current_user: dict = Depends(get_current_user),
) -> Project:
    """Get a single project (ownership enforced)."""
    return await _get_service().get_project(current_user["sub"], project_id)


@router.get("/{project_id}/report", response_model=FullReport)
async def get_full_report(
    project_id: str,
    current_user: dict = Depends(get_current_user),
) -> FullReport:
    """Get full decision report with module breakdowns and benchmarks."""
    return await _get_service().get_full_report(current_user["sub"], project_id)


@router.get("/{project_id}/pdf")
async def download_full_pdf(
    project_id: str,
    current_user: dict = Depends(get_current_user),
) -> Response:
    """Download full report as PDF."""
    report = await _get_service().get_full_report(current_user["sub"], project_id)
    pdf_bytes = generate_full_pdf(report)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=nxes-report-{project_id[:8]}.pdf"},
    )
