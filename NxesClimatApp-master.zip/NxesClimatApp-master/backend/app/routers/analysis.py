"""
Analysis Router — submit analysis jobs and poll results.
Implements US-07.3 (structured API response).
"""
from fastapi import APIRouter, BackgroundTasks, HTTPException, status
from fastapi.responses import Response

from app.models.requests import ProjectInput
from app.models.responses import AnalysisJobResponse, JobStatusResponse
from app.repositories.project_repository import ProjectRepository
from app.services.analysis_service import AnalysisService
from app.services.pdf_service import generate_pilot_pdf

router = APIRouter(prefix="/api/v1/analyze", tags=["analysis"])


def _get_service() -> AnalysisService:
    repo = ProjectRepository()
    return AnalysisService(repo)


@router.post("", response_model=AnalysisJobResponse, status_code=status.HTTP_202_ACCEPTED)
async def submit_analysis(
    project_input: ProjectInput,
    background_tasks: BackgroundTasks,
) -> AnalysisJobResponse:
    """
    Submit a project for analysis. Returns session_id immediately.
    Analysis runs as a background task.
    """
    service = _get_service()
    session_id = await service.submit_job(project_input)
    background_tasks.add_task(service.run_analysis, session_id, project_input)
    return AnalysisJobResponse(session_id=session_id, status="queued")


@router.get("/{session_id}", response_model=JobStatusResponse)
async def get_analysis_status(session_id: str) -> JobStatusResponse:
    """
    Poll analysis job status. Returns result when complete.
    """
    repo = ProjectRepository()
    job = await repo.get_job_status(session_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")

    response = JobStatusResponse(
        session_id=session_id,
        status=job["status"],
        progress=job.get("progress"),
        error=job.get("error_message"),
    )

    if job["status"] == "complete":
        session = await repo.get_anonymous_session(session_id)
        if session:
            from app.models.responses import AnalysisResult, ModuleScores
            r = session["analysis_result"]
            ms = r.get("module_scores", {})
            response.result = AnalysisResult(
                session_id=session_id,
                decision=r["decision"],
                score=r["score"],
                risk_level=r["risk_level"],
                readiness=r["readiness"],
                key_issues=r["key_issues"],
                module_scores=ModuleScores(
                    mrv=ms.get("mrv", 0),
                    financial=ms.get("financial", 0),
                    risk=ms.get("risk", 0),
                    additionality=ms.get("additionality", 0),
                ),
            )

    return response


@router.get("/{session_id}/pdf")
async def download_pilot_pdf(session_id: str) -> Response:
    """Download pilot summary PDF (no auth required)."""
    repo = ProjectRepository()
    session = await repo.get_anonymous_session(session_id)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")

    from app.models.responses import AnalysisResult, ModuleScores
    r = session["analysis_result"]
    ms = r.get("module_scores", {})
    result = AnalysisResult(
        session_id=session_id,
        decision=r["decision"],
        score=r["score"],
        risk_level=r["risk_level"],
        readiness=r["readiness"],
        key_issues=r["key_issues"],
        module_scores=ModuleScores(
            mrv=ms.get("mrv", 0),
            financial=ms.get("financial", 0),
            risk=ms.get("risk", 0),
            additionality=ms.get("additionality", 0),
        ),
    )

    pdf_bytes = generate_pilot_pdf(result)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=nxes-pilot-{session_id[:8]}.pdf"},
    )
