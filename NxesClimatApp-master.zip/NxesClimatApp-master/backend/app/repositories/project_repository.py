"""
ProjectRepository — DynamoDB access for sessions, jobs, and projects.
"""
import json
import time
import uuid
from datetime import datetime, timezone
from typing import List, Optional

from boto3.dynamodb.conditions import Key

from app.core.config import config
from app.core.dynamodb import get_dynamodb
from app.models.responses import AnalysisResult, Project


class ProjectRepository:

    @property
    def sessions_table(self):
        return get_dynamodb().Table(config.DYNAMODB_TABLE_SESSIONS)

    @property
    def projects_table(self):
        return get_dynamodb().Table(config.DYNAMODB_TABLE_PROJECTS)

    # ── Analysis Jobs ─────────────────────────────────────────────────────────

    async def create_analysis_job(self, session_id: str) -> None:
        ttl = int(time.time()) + 86400  # 24 hours
        self.sessions_table.put_item(Item={
            "PK": f"JOB#{session_id}",
            "session_id": session_id,
            "status": "queued",
            "progress": [],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "ttl": ttl,
        })

    async def update_job_status(
        self, session_id: str, status: str,
        progress: Optional[List[str]] = None,
        error: Optional[str] = None
    ) -> None:
        update_expr = "SET #s = :s"
        expr_names = {"#s": "status"}
        expr_values = {":s": status}

        if progress is not None:
            update_expr += ", progress = :p"
            expr_values[":p"] = progress

        if error is not None:
            update_expr += ", error_message = :e"
            expr_values[":e"] = error

        self.sessions_table.update_item(
            Key={"PK": f"JOB#{session_id}"},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
        )

    async def update_job_progress(self, session_id: str, step: str) -> None:
        self.sessions_table.update_item(
            Key={"PK": f"JOB#{session_id}"},
            UpdateExpression="SET progress = list_append(if_not_exists(progress, :empty), :step)",
            ExpressionAttributeValues={":step": [step], ":empty": []},
        )

    async def get_job_status(self, session_id: str) -> Optional[dict]:
        response = self.sessions_table.get_item(Key={"PK": f"JOB#{session_id}"})
        return response.get("Item")

    # ── Anonymous Sessions ────────────────────────────────────────────────────

    async def save_analysis_result(
        self, session_id: str, result: AnalysisResult, project_input
    ) -> None:
        ttl = int(time.time()) + 86400
        self.sessions_table.put_item(Item={
            "PK": f"SESSION#{session_id}",
            "session_id": session_id,
            "analysis_result": json.loads(result.model_dump_json()),
            "project_input": {
                "project_type": project_input.project_type,
                "location": project_input.location,
                "description": project_input.description,
                "stage": project_input.stage,
                "file_reference": project_input.file_reference,
            },
            "created_at": datetime.now(timezone.utc).isoformat(),
            "ttl": ttl,
        })

    async def get_anonymous_session(self, session_id: str) -> Optional[dict]:
        response = self.sessions_table.get_item(Key={"PK": f"SESSION#{session_id}"})
        return response.get("Item")

    # ── Projects ──────────────────────────────────────────────────────────────

    async def create_project_from_session(self, user_id: str, session: dict) -> str:
        project_id = str(uuid.uuid4())
        result = session["analysis_result"]
        project_input = session.get("project_input", {})

        self.projects_table.put_item(Item={
            "PK": f"USER#{user_id}",
            "SK": f"PROJECT#{project_id}",
            "project_id": project_id,
            "user_id": user_id,
            "project_type": project_input.get("project_type", ""),
            "location": project_input.get("location", ""),
            "description": project_input.get("description", ""),
            "stage": project_input.get("stage"),
            "file_reference": project_input.get("file_reference"),
            "decision": result["decision"],
            "score": result["score"],
            "risk_level": result["risk_level"],
            "readiness": result["readiness"],
            "key_issues": result["key_issues"],
            "module_scores": result["module_scores"],
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        return project_id

    async def get_projects_by_user(self, user_id: str) -> List[dict]:
        response = self.projects_table.query(
            KeyConditionExpression=Key("PK").eq(f"USER#{user_id}") & Key("SK").begins_with("PROJECT#"),
        )
        return response.get("Items", [])

    async def get_project_by_id(self, project_id: str) -> Optional[dict]:
        response = self.projects_table.query(
            IndexName=config.DYNAMODB_PROJECTS_GSI,
            KeyConditionExpression=Key("project_id").eq(project_id),
        )
        items = response.get("Items", [])
        return items[0] if items else None
