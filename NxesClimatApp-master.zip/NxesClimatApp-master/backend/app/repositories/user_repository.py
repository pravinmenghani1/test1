"""
UserRepository — DynamoDB access for user accounts.
"""
from datetime import datetime, timezone
from typing import Optional

from app.core.config import config
from app.core.dynamodb import get_dynamodb


class UserRepository:

    @property
    def users_table(self):
        return get_dynamodb().Table(config.DYNAMODB_TABLE_USERS)

    async def create_user(self, user_id: str, email: str, hashed_password: str) -> None:
        self.users_table.put_item(Item={
            "PK": f"USER#{email}",
            "user_id": user_id,
            "email": email,
            "hashed_password": hashed_password,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

    async def get_user_by_email(self, email: str) -> Optional[dict]:
        response = self.users_table.get_item(Key={"PK": f"USER#{email}"})
        return response.get("Item")
