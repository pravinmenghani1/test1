"""
JWT utilities — token creation, verification, and Secrets Manager cold-start cache.
"""
import json
from datetime import datetime, timedelta, timezone
from typing import Optional

import boto3
from jose import JWTError, jwt

from app.core.config import config

# Cold-start cache — fetched once per Lambda invocation lifecycle
_jwt_secret: Optional[str] = None


def get_jwt_secret() -> str:
    """Retrieve JWT secret. Uses Secrets Manager in production, env var in local dev."""
    global _jwt_secret
    if _jwt_secret is not None:
        return _jwt_secret

    if config.USE_LOCAL_JWT_SECRET:
        _jwt_secret = config.JWT_SECRET_KEY
        return _jwt_secret

    # Fetch from Secrets Manager (production)
    client = boto3.client("secretsmanager", region_name=config.AWS_REGION)
    response = client.get_secret_value(SecretId=config.SECRETS_MANAGER_JWT_SECRET_ARN)
    secret = json.loads(response["SecretString"])
    _jwt_secret = secret["JWT_SECRET_KEY"]
    return _jwt_secret


def create_token(user_id: str, email: str) -> str:
    """Create a signed JWT token."""
    expire = datetime.now(timezone.utc) + timedelta(hours=config.JWT_EXPIRY_HOURS)
    payload = {
        "sub": user_id,
        "email": email,
        "exp": expire,
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=config.JWT_ALGORITHM)


def verify_token(token: str) -> dict:
    """Verify and decode a JWT token. Raises JWTError on failure."""
    return jwt.decode(token, get_jwt_secret(), algorithms=[config.JWT_ALGORITHM])
