"""
Configuration — reads all environment variables.
Single source of truth for app configuration.
"""
import os


class Config:
    # DynamoDB
    DYNAMODB_TABLE_SESSIONS: str = os.environ.get("DYNAMODB_TABLE_SESSIONS", "nxes-sessions")
    DYNAMODB_TABLE_USERS: str = os.environ.get("DYNAMODB_TABLE_USERS", "nxes-users")
    DYNAMODB_TABLE_PROJECTS: str = os.environ.get("DYNAMODB_TABLE_PROJECTS", "nxes-projects")
    DYNAMODB_PROJECTS_GSI: str = os.environ.get("DYNAMODB_PROJECTS_GSI", "project_id-index")
    AWS_REGION: str = os.environ.get("AWS_REGION", "us-east-1")
    DYNAMODB_ENDPOINT_URL: str = os.environ.get("DYNAMODB_ENDPOINT_URL", "")

    # JWT
    JWT_ALGORITHM: str = os.environ.get("JWT_ALGORITHM", "HS256")
    JWT_EXPIRY_HOURS: int = int(os.environ.get("JWT_EXPIRY_HOURS", "24"))
    SECRETS_MANAGER_JWT_SECRET_ARN: str = os.environ.get("SECRETS_MANAGER_JWT_SECRET_ARN", "")
    # For local dev only — set USE_LOCAL_JWT_SECRET=true and JWT_SECRET_KEY
    USE_LOCAL_JWT_SECRET: bool = os.environ.get("USE_LOCAL_JWT_SECRET", "false").lower() == "true"
    JWT_SECRET_KEY: str = os.environ.get("JWT_SECRET_KEY", "")

    # Scoring weights
    MRV_WEIGHT: float = float(os.environ.get("MRV_WEIGHT", "0.30"))
    FINANCIAL_WEIGHT: float = float(os.environ.get("FINANCIAL_WEIGHT", "0.25"))
    RISK_WEIGHT: float = float(os.environ.get("RISK_WEIGHT", "0.25"))
    ADDITIONALITY_WEIGHT: float = float(os.environ.get("ADDITIONALITY_WEIGHT", "0.20"))


config = Config()
