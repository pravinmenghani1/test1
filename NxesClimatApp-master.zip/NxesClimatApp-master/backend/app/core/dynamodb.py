"""
DynamoDB client singleton.
Shared across all repositories to avoid creating multiple connections.
"""
import boto3
from app.core.config import config

_dynamodb_resource = None


def get_dynamodb():
    """Return the shared DynamoDB resource (lazy singleton)."""
    global _dynamodb_resource
    if _dynamodb_resource is None:
        kwargs = {"region_name": config.AWS_REGION}
        if config.DYNAMODB_ENDPOINT_URL:
            kwargs["endpoint_url"] = config.DYNAMODB_ENDPOINT_URL
        _dynamodb_resource = boto3.resource("dynamodb", **kwargs)
    return _dynamodb_resource
