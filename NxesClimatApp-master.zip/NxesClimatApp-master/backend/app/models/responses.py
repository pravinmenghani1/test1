"""Pydantic response models."""
from typing import Dict, List, Optional
from pydantic import BaseModel


class ModuleScores(BaseModel):
    mrv: int
    financial: int
    risk: int
    additionality: int


class AnalysisResult(BaseModel):
    session_id: str
    decision: str       # GO / REVISE / NO-GO
    score: int          # 0-100
    risk_level: str     # Low / Medium / High
    readiness: int      # 0-100
    key_issues: List[str]
    module_scores: ModuleScores


class AnalysisJobResponse(BaseModel):
    session_id: str
    status: str         # queued


class JobStatusResponse(BaseModel):
    session_id: str
    status: str         # queued / processing / complete / failed
    progress: Optional[List[str]] = None
    result: Optional[AnalysisResult] = None
    error: Optional[str] = None


class AuthResponse(BaseModel):
    token: str
    user_id: str


class Project(BaseModel):
    project_id: str
    project_type: str
    location: str
    description: str
    stage: Optional[str] = None
    decision: str
    score: int
    risk_level: str
    readiness: int
    key_issues: List[str]
    module_scores: ModuleScores
    created_at: str


class ProjectListResponse(BaseModel):
    projects: List[Project]


class ModuleDetail(BaseModel):
    score: int
    issues: List[str]
    recommendations: List[str]
    benchmark_score: Optional[int] = None


class FullReport(BaseModel):
    project_id: str
    decision: str
    score: int
    risk_level: str
    readiness: int
    key_issues: List[str]
    modules: Dict[str, ModuleDetail]
    benchmark_summary: str
