"""Pydantic request models."""
from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator


class ProjectInput(BaseModel):
    project_type: str
    location: str
    description: str
    stage: Optional[str] = None
    file_reference: Optional[str] = None

    @field_validator("description")
    @classmethod
    def description_max_length(cls, v: str) -> str:
        if len(v) > 500:
            raise ValueError("Description must be 500 characters or fewer")
        return v

    @field_validator("project_type")
    @classmethod
    def valid_project_type(cls, v: str) -> str:
        valid = {
            "Forestry/REDD+", "Renewable Energy", "Cookstoves",
            "Waste-to-Energy", "Blue Carbon", "Agriculture"
        }
        if v not in valid:
            raise ValueError(f"project_type must be one of: {', '.join(sorted(valid))}")
        return v

    @field_validator("stage")
    @classmethod
    def valid_stage(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in {"Idea", "Pilot", "Scaling"}:
            raise ValueError("stage must be Idea, Pilot, or Scaling")
        return v


class SignupRequest(BaseModel):
    email: EmailStr
    password: str
    session_id: Optional[str] = None

    @field_validator("password")
    @classmethod
    def password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
