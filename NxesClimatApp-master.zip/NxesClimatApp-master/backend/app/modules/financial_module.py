"""
Financial Logic Module — simplified pilot scoring.
Pure function: same inputs always produce same outputs.
"""
from dataclasses import dataclass
from typing import List

_BASE_SCORES = {
    "Renewable Energy": 70,
    "Forestry/REDD+": 65,
    "Waste-to-Energy": 65,
    "Cookstoves": 60,
    "Blue Carbon": 55,
    "Agriculture": 50,
}

_STAGE_ADJUSTMENTS = {
    "Scaling": 20,
    "Pilot": 0,
    "Idea": -15,
}


@dataclass
class ModuleScore:
    score: int
    issues: List[str]
    recommendations: List[str]


def score(project_type: str, stage: str | None) -> ModuleScore:
    """
    Calculate financial viability score.

    Args:
        project_type: One of the 6 supported project types
        stage: Idea / Pilot / Scaling (optional)

    Returns:
        ModuleScore with 0-100 score, issues, and recommendations
    """
    base = _BASE_SCORES.get(project_type, 50)
    adjustment = _STAGE_ADJUSTMENTS.get(stage or "Pilot", 0)
    final = max(0, min(100, base + adjustment))

    issues: List[str] = []
    recommendations: List[str] = []

    if final >= 70:
        issues.append("Financial structure appears viable for carbon market participation")
        recommendations.append("Develop detailed financial model with carbon price sensitivity analysis")
    elif final >= 50:
        issues.append("Revenue model needs further development")
        recommendations.append("Clarify carbon credit pricing assumptions and offtake agreements")
    else:
        issues.append("Financial viability is unclear at current project stage")
        recommendations.append("Conduct feasibility study before seeking carbon market validation")

    if stage == "Idea":
        issues.append("Project is at idea stage — financial projections are speculative")

    return ModuleScore(score=final, issues=issues, recommendations=recommendations)
