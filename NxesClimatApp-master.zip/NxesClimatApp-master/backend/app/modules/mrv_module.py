"""
MRV Validation Module — simplified pilot scoring.
Pure function: same inputs always produce same outputs.
"""
from dataclasses import dataclass
from typing import List

# Regions mapped to risk tiers for MRV context
_HIGH_MRV_REGIONS = {
    "Norway", "Sweden", "Germany", "United Kingdom", "France",
    "United States", "Canada", "Australia", "Japan", "New Zealand",
}
_LOW_MRV_REGIONS = {
    "Somalia", "South Sudan", "Central African Republic", "Yemen",
    "Libya", "Syria", "Afghanistan", "Haiti",
}

_BASE_SCORES = {
    "Forestry/REDD+": 60,
    "Renewable Energy": 75,
    "Cookstoves": 55,
    "Waste-to-Energy": 65,
    "Blue Carbon": 50,
    "Agriculture": 45,
}


@dataclass
class ModuleScore:
    score: int
    issues: List[str]
    recommendations: List[str]


def score(project_type: str, location: str) -> ModuleScore:
    """
    Calculate MRV feasibility score.

    Args:
        project_type: One of the 6 supported project types
        location: Country name

    Returns:
        ModuleScore with 0-100 score, issues, and recommendations
    """
    base = _BASE_SCORES.get(project_type, 40)

    # Location adjustment
    if location in _HIGH_MRV_REGIONS:
        base = min(100, base + 10)
    elif location in _LOW_MRV_REGIONS:
        base = max(0, base - 15)

    issues: List[str] = []
    recommendations: List[str] = []

    if base >= 70:
        issues.append(f"Strong MRV framework available for {project_type} projects")
        recommendations.append("Proceed with standard MRV protocol selection")
    elif base >= 50:
        issues.append(f"MRV methodology for {project_type} requires additional documentation")
        recommendations.append("Engage an accredited MRV auditor early in project development")
    else:
        issues.append(f"MRV framework for {project_type} in {location} is underdeveloped")
        recommendations.append("Consider partnering with an established MRV body before proceeding")

    return ModuleScore(score=base, issues=issues, recommendations=recommendations)
