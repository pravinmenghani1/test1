"""
Additionality Module — simplified pilot scoring.
Pure function: same inputs always produce same outputs.
"""
from dataclasses import dataclass
from typing import List

_BASE_SCORES = {
    "Cookstoves": 75,
    "Forestry/REDD+": 70,
    "Waste-to-Energy": 65,
    "Blue Carbon": 60,
    "Renewable Energy": 55,
    "Agriculture": 50,
}


@dataclass
class ModuleScore:
    score: int
    additionality_status: str  # Yes / Uncertain / No
    issues: List[str]
    recommendations: List[str]


def score(project_type: str) -> ModuleScore:
    """
    Calculate additionality score.

    Args:
        project_type: One of the 6 supported project types

    Returns:
        ModuleScore with 0-100 score, additionality_status, issues, recommendations
    """
    base = _BASE_SCORES.get(project_type, 50)

    if base >= 70:
        status = "Yes"
    elif base >= 50:
        status = "Uncertain"
    else:
        status = "No"

    issues: List[str] = []
    recommendations: List[str] = []

    if status == "Yes":
        issues.append(f"Clear additionality case for {project_type} projects")
        recommendations.append("Document counterfactual scenario in project design document")
    elif status == "Uncertain":
        issues.append(f"Additionality for {project_type} requires stronger justification")
        recommendations.append("Conduct barrier analysis and common practice assessment")
    else:
        issues.append(f"Additionality is difficult to demonstrate for {project_type}")
        recommendations.append("Consult a carbon standard body before proceeding")

    return ModuleScore(
        score=base,
        additionality_status=status,
        issues=issues,
        recommendations=recommendations,
    )
