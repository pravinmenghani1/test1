"""
Risk Scoring Module — simplified pilot scoring.
Pure function: same inputs always produce same outputs.
"""
from dataclasses import dataclass
from typing import List

_HIGH_RISK_COUNTRIES = {
    "Somalia", "South Sudan", "Central African Republic", "Yemen",
    "Libya", "Syria", "Afghanistan", "Haiti", "Myanmar", "Sudan",
    "Democratic Republic of the Congo", "Mali", "Burkina Faso",
}

_LOW_RISK_COUNTRIES = {
    "Norway", "Sweden", "Denmark", "Finland", "Switzerland",
    "Germany", "Netherlands", "New Zealand", "Canada", "Australia",
    "United Kingdom", "Japan", "Singapore", "Austria",
}

_STAGE_ADJUSTMENTS = {
    "Scaling": 10,
    "Pilot": 0,
    "Idea": -10,
}


@dataclass
class ModuleScore:
    score: int
    risk_level: str
    issues: List[str]
    recommendations: List[str]


def score(location: str, stage: str | None) -> ModuleScore:
    """
    Calculate risk score and risk level.

    Args:
        location: Country name
        stage: Idea / Pilot / Scaling (optional)

    Returns:
        ModuleScore with 0-100 score, risk_level (Low/Medium/High), issues, recommendations
    """
    if location in _HIGH_RISK_COUNTRIES:
        base = 30
    elif location in _LOW_RISK_COUNTRIES:
        base = 80
    else:
        base = 55  # Medium risk default

    adjustment = _STAGE_ADJUSTMENTS.get(stage or "Pilot", 0)
    final = max(0, min(100, base + adjustment))

    # Derive risk level from final score
    if final > 70:
        risk_level = "Low"
    elif final >= 40:
        risk_level = "Medium"
    else:
        risk_level = "High"

    issues: List[str] = []
    recommendations: List[str] = []

    if risk_level == "Low":
        issues.append(f"Low political and regulatory risk in {location}")
        recommendations.append("Standard risk monitoring is sufficient")
    elif risk_level == "Medium":
        issues.append(f"Moderate regulatory risk in {location} — monitoring required")
        recommendations.append("Establish local partnerships to mitigate regulatory risk")
    else:
        issues.append(f"High political instability risk in {location}")
        recommendations.append("Consider risk insurance and phased investment approach")

    return ModuleScore(
        score=final,
        risk_level=risk_level,
        issues=issues,
        recommendations=recommendations,
    )
