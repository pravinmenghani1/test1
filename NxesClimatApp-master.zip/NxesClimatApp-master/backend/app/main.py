"""
NxES Decision Core — FastAPI application entry point.
Mangum wraps this for AWS Lambda deployment.
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from mangum import Mangum

from app.routers import analysis, auth, projects

app = FastAPI(
    title="NxES Decision Core API",
    description="Climate project validation API — GO / REVISE / NO-GO decisions",
    version="1.0.0",
)

# CORS — allow all origins in development; restrict to Amplify URL in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

# Routers
app.include_router(analysis.router)
app.include_router(auth.router)
app.include_router(projects.router)


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all — never expose stack traces to clients."""
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again."},
    )


# AWS Lambda handler (Mangum adapter)
handler = Mangum(app, lifespan="off")
