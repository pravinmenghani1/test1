"""
AnalysisService — orchestrates the 4 scoring modules and computes the composite score.
Implements US-07.1, US-07.2, US-07.3.
"""
import uuid
from datetime import datetime, timezone
from typing import List

from app.core.config import config
from app.models.requests import ProjectInput
from app.models.responses import AnalysisResult, ModuleScores
from app.modules import mrv_module, financial_module, risk_module, additionality_module
from app.repositories.project_repository import ProjectRepository


class AnalysisService:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    async def submit_job(self, project_input: ProjectInput) -> str:
        """
        Create an analysis job and return the session_id.
        The actual analysis runs as a background task.
        """
        session_id = str(uuid.uuid4())
        await self.repo.create_analysis_job(session_id)
        return session_id

    async def run_analysis(self, session_id: str, project_input: ProjectInput) -> None:
        """
        Execute the full analysis pipeline. Called as a background task.
        Updates job progress in DynamoDB as each module completes.
        """
        try:
            await self.repo.update_job_status(session_id, "processing", progress=[])

            # Step 1: MRV
            mrv = mrv_module.score(project_input.project_type, project_input.location)
            await self.repo.update_job_progress(session_id, "Checking MRV feasibility")

            # Step 2: Financial
            fin = financial_module.score(project_input.project_type, project_input.stage)
            await self.repo.update_job_progress(session_id, "Evaluating financial logic")

            # Step 3: Risk
            risk = risk_module.score(project_input.location, project_input.stage)
            await self.repo.update_job_progress(session_id, "Assessing risks")

            # Step 4: Additionality
            add = additionality_module.score(project_input.project_type)
            await self.repo.update_job_progress(session_id, "Validating additionality")

            # Compute composite score (US-07.1)
            composite = self._compute_score(mrv.score, fin.score, risk.score, add.score)

            # Apply decision thresholds (US-07.2)
            decision = self._apply_decision(composite)

            # Derive risk level from risk module
            risk_level = risk.risk_level

            # Generate key issues
            key_issues = self._generate_key_issues(
                decision, mrv, fin, risk, add
            )

            module_scores = ModuleScores(
                mrv=mrv.score,
                financial=fin.score,
                risk=risk.score,
                additionality=add.score,
            )

            result = AnalysisResult(
                session_id=session_id,
                decision=decision,
                score=composite,
                risk_level=risk_level,
                readiness=composite,  # readiness mirrors composite score
                key_issues=key_issues,
                module_scores=module_scores,
            )

            # Persist result (US-07.3)
            await self.repo.save_analysis_result(session_id, result, project_input)
            await self.repo.update_job_status(session_id, "complete")

        except Exception as e:
            await self.repo.update_job_status(session_id, "failed", error=str(e))
            raise

    def _compute_score(self, mrv: int, financial: int, risk: int, additionality: int) -> int:
        """
        Weighted average composite score. (US-07.1)
        Score = (MRV × 0.30) + (Financial × 0.25) + (Risk × 0.25) + (Additionality × 0.20)
        """
        composite = (
            mrv * config.MRV_WEIGHT
            + financial * config.FINANCIAL_WEIGHT
            + risk * config.RISK_WEIGHT
            + additionality * config.ADDITIONALITY_WEIGHT
        )
        return round(composite)

    def _apply_decision(self, score: int) -> str:
        """
        Apply decision thresholds. (US-07.2)
        >70 = GO, 40-70 = REVISE, <40 = NO-GO
        Boundary: exactly 70 → REVISE, exactly 40 → REVISE
        """
        if score > 70:
            return "GO"
        elif score >= 40:
            return "REVISE"
        else:
            return "NO-GO"

    def _generate_key_issues(self, decision: str, mrv, fin, risk, add) -> List[str]:
        """
        Generate 3-5 plain-English key issues from module outputs.
        For GO: frame as strengths. For REVISE/NO-GO: frame as gaps.
        Prioritise lowest-scoring modules first.
        """
        modules = [
            ("mrv", mrv.score, mrv.issues),
            ("financial", fin.score, fin.issues),
            ("risk", risk.score, risk.issues),
            ("additionality", add.score, add.issues),
        ]

        if decision == "GO":
            # Sort by score descending — highlight strengths
            modules.sort(key=lambda x: x[1], reverse=True)
        else:
            # Sort by score ascending — highlight weakest areas first
            modules.sort(key=lambda x: x[1])

        issues: List[str] = []
        for _, _, module_issues in modules:
            for issue in module_issues:
                if issue not in issues:
                    issues.append(issue)
                if len(issues) >= 5:
                    break
            if len(issues) >= 5:
                break

        return issues[:5] if len(issues) >= 3 else issues + ["Further analysis required"] * (3 - len(issues))
