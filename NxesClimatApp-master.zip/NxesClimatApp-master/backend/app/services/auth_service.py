"""
AuthService — signup, login, JWT issuance, and session transfer.
"""
import uuid
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from passlib.context import CryptContext

from app.core.jwt_utils import create_token, verify_token
from app.models.requests import LoginRequest, SignupRequest
from app.models.responses import AuthResponse
from app.repositories.project_repository import ProjectRepository
from app.repositories.user_repository import UserRepository

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto", bcrypt__rounds=12)
security = HTTPBearer()


class AuthService:
    def __init__(self, user_repo: UserRepository, project_repo: ProjectRepository):
        self.user_repo = user_repo
        self.project_repo = project_repo

    async def signup(self, request: SignupRequest) -> AuthResponse:
        # Check email not already registered
        existing = await self.user_repo.get_user_by_email(str(request.email))
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with this email already exists",
            )

        user_id = str(uuid.uuid4())
        hashed = pwd_context.hash(request.password)
        await self.user_repo.create_user(user_id, str(request.email), hashed)

        # Transfer anonymous session if session_id provided
        if request.session_id:
            session = await self.project_repo.get_anonymous_session(request.session_id)
            if session:
                await self.project_repo.create_project_from_session(user_id, session)
            # If session not found (expired TTL), proceed silently

        token = create_token(user_id, str(request.email))
        return AuthResponse(token=token, user_id=user_id)

    async def login(self, request: LoginRequest) -> AuthResponse:
        user = await self.user_repo.get_user_by_email(str(request.email))
        # Generic error — no email enumeration (BR-AUTH-04)
        if not user or not pwd_context.verify(request.password, user["hashed_password"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
            )
        token = create_token(user["user_id"], user["email"])
        return AuthResponse(token=token, user_id=user["user_id"])


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> dict:
    """FastAPI dependency — validates JWT and returns user claims."""
    try:
        claims = verify_token(credentials.credentials)
        return claims
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
