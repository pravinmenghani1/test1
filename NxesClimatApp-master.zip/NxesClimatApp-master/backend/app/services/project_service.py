"""
ProjectService — project retrieval and full report assembly.
"""
from typing import Dict, List

from fastapi import HTTPException, status

from app.models.responses import FullReport, ModuleDetail, Project, ProjectListResponse
from app.repositories.project_repository import ProjectRepository


# Benchmark data — simplified pilot values (average scores by project type)
_BENCHMARKS: Dict[str, Dict[str, int]] = {
    "Forestry/REDD+":   {"mrv": 62, "financial": 64, "risk": 58, "additionality": 70},
    "Renewable Energy": {"mrv": 74, "financial": 68, "risk": 60, "additionality": 55},
    "Cookstoves":       {"mrv": 56, "financial": 59, "risk": 55, "additionality": 74},
    "Waste-to-Energy":  {"mrv": 64, "financial": 63, "risk": 57, "additionality": 64},
    "Blue Carbon":      {"mrv": 51, "financial": 54, "risk": 56, "additionality": 60},
    "Agriculture":      {"mrv": 46, "financial": 50, "risk": 54, "additionality": 50},
}

_RECOMMENDATIONS: Dict[str, List[str]] = {
    "mrv": [
        "Select an accredited MRV standard (Verra VCS, Gold Standard, or equivalent)",
        "Engage a third-party auditor for baseline assessment",
    ],
    "financial": [
        "Develop a 10-year financial model with carbon price sensitivity analysis",
        "Identify offtake partners or carbon credit buyers early",
    ],
    "risk": [
        "Establish local partnerships to mitigate political and regulatory risk",
        "Consider political risk insurance for high-risk locations",
    ],
    "additionality": [
        "Document the counterfactual scenario in the project design document",
        "Conduct a common practice assessment for your project type and region",
    ],
}


class ProjectService:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    async def get_projects(self, user_id: str) -> ProjectListResponse:
        items = await self.repo.get_projects_by_user(user_id)
        projects = [self._item_to_project(item) for item in items]
        return ProjectListResponse(projects=projects)

    async def get_project(self, user_id: str, project_id: str) -> Project:
        item = await self.repo.get_project_by_id(project_id)
        if not item:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        if item.get("user_id") != user_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
        return self._item_to_project(item)

    async def get_full_report(self, user_id: str, project_id: str) -> FullReport:
        item = await self.repo.get_project_by_id(project_id)
        if not item:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
        if item.get("user_id") != user_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

        module_scores = item.get("module_scores", {})
        project_type = item.get("project_type", "")
        benchmarks = _BENCHMARKS.get(project_type, {})

        modules = {}
        for module_name in ["mrv", "financial", "risk", "additionality"]:
            mod_score = int(module_scores.get(module_name, 0))
            bench = benchmarks.get(module_name)
            modules[module_name] = ModuleDetail(
                score=mod_score,
                issues=[f"{module_name.upper()} score: {mod_score}/100"],
                recommendations=_RECOMMENDATIONS.get(module_name, []),
                benchmark_score=bench,
            )

        score = int(item.get("score", 0))
        avg_benchmark = round(sum(benchmarks.values()) / len(benchmarks)) if benchmarks else None
        if avg_benchmark:
            diff = score - avg_benchmark
            direction = "above" if diff >= 0 else "below"
            benchmark_summary = (
                f"Your project scored {abs(diff)} points {direction} the average "
                f"for {project_type} projects in our database."
            )
        else:
            benchmark_summary = "Benchmark data not available for this project type."

        return FullReport(
            project_id=project_id,
            decision=item.get("decision", ""),
            score=score,
            risk_level=item.get("risk_level", ""),
            readiness=int(item.get("readiness", 0)),
            key_issues=item.get("key_issues", []),
            modules=modules,
            benchmark_summary=benchmark_summary,
        )

    def _item_to_project(self, item: dict) -> Project:
        from app.models.responses import ModuleScores
        ms = item.get("module_scores", {})
        return Project(
            project_id=item["project_id"],
            project_type=item.get("project_type", ""),
            location=item.get("location", ""),
            description=item.get("description", ""),
            stage=item.get("stage"),
            decision=item.get("decision", ""),
            score=int(item.get("score", 0)),
            risk_level=item.get("risk_level", ""),
            readiness=int(item.get("readiness", 0)),
            key_issues=item.get("key_issues", []),
            module_scores=ModuleScores(
                mrv=int(ms.get("mrv", 0)),
                financial=int(ms.get("financial", 0)),
                risk=int(ms.get("risk", 0)),
                additionality=int(ms.get("additionality", 0)),
            ),
            created_at=item.get("created_at", ""),
        )
