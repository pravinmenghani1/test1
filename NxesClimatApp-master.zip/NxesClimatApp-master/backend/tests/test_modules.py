"""
Unit tests for the 4 scoring modules.
Tests US-07.1 (weighted scoring) and US-07.2 (decision thresholds).
"""
import pytest
from app.modules import mrv_module, financial_module, risk_module, additionality_module
from app.services.analysis_service import AnalysisService


# ── MRV Module ────────────────────────────────────────────────────────────────

def test_mrv_renewable_energy_scores_high():
    result = mrv_module.score("Renewable Energy", "Germany")
    assert result.score >= 70

def test_mrv_agriculture_scores_lower():
    result = mrv_module.score("Agriculture", "Kenya")
    assert result.score < 60

def test_mrv_returns_issues():
    result = mrv_module.score("Blue Carbon", "Indonesia")
    assert len(result.issues) > 0

def test_mrv_high_risk_location_reduces_score():
    score_stable = mrv_module.score("Forestry/REDD+", "Norway").score
    score_unstable = mrv_module.score("Forestry/REDD+", "Somalia").score
    assert score_stable > score_unstable


# ── Financial Module ──────────────────────────────────────────────────────────

def test_financial_scaling_stage_bonus():
    score_scaling = financial_module.score("Renewable Energy", "Scaling").score
    score_idea = financial_module.score("Renewable Energy", "Idea").score
    assert score_scaling > score_idea

def test_financial_score_capped_at_100():
    result = financial_module.score("Renewable Energy", "Scaling")
    assert result.score <= 100

def test_financial_score_floored_at_0():
    result = financial_module.score("Agriculture", "Idea")
    assert result.score >= 0

def test_financial_none_stage_uses_pilot_default():
    result_none = financial_module.score("Cookstoves", None)
    result_pilot = financial_module.score("Cookstoves", "Pilot")
    assert result_none.score == result_pilot.score


# ── Risk Module ───────────────────────────────────────────────────────────────

def test_risk_high_risk_country():
    result = risk_module.score("Somalia", "Pilot")
    assert result.risk_level == "High"
    assert result.score < 40

def test_risk_low_risk_country():
    result = risk_module.score("Norway", "Pilot")
    assert result.risk_level == "Low"
    assert result.score > 70

def test_risk_scaling_improves_score():
    score_idea = risk_module.score("Kenya", "Idea").score
    score_scaling = risk_module.score("Kenya", "Scaling").score
    assert score_scaling > score_idea


# ── Additionality Module ──────────────────────────────────────────────────────

def test_additionality_cookstoves_highest():
    result = risk_module.score("Norway", "Pilot")
    cookstoves = additionality_module.score("Cookstoves")
    assert cookstoves.score >= 70

def test_additionality_agriculture_lowest():
    result = additionality_module.score("Agriculture")
    assert result.score <= 55

def test_additionality_returns_status():
    result = additionality_module.score("Forestry/REDD+")
    assert result.additionality_status in {"Yes", "Uncertain", "No"}


# ── Scoring Engine (US-07.1, US-07.2) ────────────────────────────────────────

class MockRepo:
    async def create_analysis_job(self, session_id): pass
    async def update_job_status(self, *args, **kwargs): pass
    async def update_job_progress(self, *args, **kwargs): pass
    async def save_analysis_result(self, *args, **kwargs): pass


def make_service():
    return AnalysisService(MockRepo())


def test_compute_score_weighted_average():
    service = make_service()
    # MRV=80, Fin=60, Risk=70, Add=50
    # Expected: 80*0.30 + 60*0.25 + 70*0.25 + 50*0.20 = 24+15+17.5+10 = 66.5 → 67
    result = service._compute_score(80, 60, 70, 50)
    assert result == 67


def test_decision_go():
    service = make_service()
    assert service._apply_decision(71) == "GO"
    assert service._apply_decision(100) == "GO"


def test_decision_revise():
    service = make_service()
    assert service._apply_decision(70) == "REVISE"  # boundary
    assert service._apply_decision(40) == "REVISE"  # boundary
    assert service._apply_decision(55) == "REVISE"


def test_decision_no_go():
    service = make_service()
    assert service._apply_decision(39) == "NO-GO"
    assert service._apply_decision(0) == "NO-GO"
