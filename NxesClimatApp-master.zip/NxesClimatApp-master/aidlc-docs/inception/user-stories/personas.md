# User Personas
# NxES Decision Core Pilot App

---

## Persona 1: Alex — The Anonymous Pilot User

**Role**: Climate project developer / early-stage founder  
**Auth State**: Not logged in

**Background**:
Alex is developing a climate project (e.g., a waste-to-energy initiative in East Africa). They've heard about carbon credits but don't know if their project qualifies. They're time-poor, skeptical of complex tools, and need a fast, credible signal before investing more effort.

**Goals**:
- Quickly validate whether their project idea is viable for carbon markets
- Understand the key risks and gaps without reading 50-page frameworks
- Get a clear, actionable answer in minutes

**Frustrations**:
- Long registration forms before seeing any value
- Jargon-heavy outputs that require expert interpretation
- Tools that ask for too much data upfront

**Behaviour**:
- Arrives via landing page (organic search, referral, or LinkedIn)
- Will abandon if asked to register before seeing a result
- Motivated by the "aha moment" — the GO/REVISE/NO-GO decision
- Converts to registered user if the result feels credible and useful

**Stories mapped to**: EP-01 (Landing), EP-02 (Input), EP-03 (Processing), EP-04 (Output), EP-05 (Conversion)

---

## Persona 2: Jordan — The Registered CC User

**Role**: Climate project developer (post-signup) / project manager  
**Auth State**: Logged in

**Background**:
Jordan ran the pilot, saw a REVISE result, and created an account to access the full report. They now use the CC platform to track their project's progress, access detailed module breakdowns, and work toward a GO decision.

**Goals**:
- Access the full analysis report with module-level detail
- Track project readiness over time
- Download reports to share with partners or investors
- Understand benchmark comparisons against similar projects

**Frustrations**:
- Losing their pilot analysis data after signing up
- Dashboards that are cluttered or hard to navigate
- Reports that don't give clear next steps

**Behaviour**:
- Logs in regularly to check project status
- Downloads PDF reports to share externally
- May run multiple projects over time

**Stories mapped to**: EP-05 (Conversion), EP-06 (Dashboard)

---

## Persona 3: Morgan — The Investor / Reviewer

**Role**: Impact investor, carbon market analyst, or project reviewer  
**Auth State**: Logged in (shared access or own account)

**Background**:
Morgan evaluates early-stage climate projects for investment or partnership. They need a fast, structured way to assess project viability without doing full due diligence upfront. They use the Decision Core output as a first-pass filter.

**Goals**:
- Quickly assess GO/REVISE/NO-GO status of a project
- Review risk level and key issues at a glance
- Access benchmark comparisons to contextualise the score
- Share or export the decision report

**Frustrations**:
- Unstructured project pitches with no standardised data
- Having to request information from developers manually
- Lack of transparency in how decisions are made

**Behaviour**:
- May receive a shared link to a project's decision output
- Focuses on the score, risk level, and key issues
- Downloads the decision report for internal review

**Stories mapped to**: EP-04 (Output), EP-06 (Dashboard — reports)
