# Execution Plan
# NxES Decision Core Pilot App

**Created**: 2026-05-21  
**Status**: Awaiting Approval

---

## Detailed Analysis Summary

### Change Impact Assessment

| Impact Area | Present | Description |
|---|---|---|
| User-facing changes | Yes | All 6 screens are new user-facing interfaces |
| Structural changes | Yes | New multi-layer architecture: React SPA + FastAPI + DynamoDB + AWS |
| Data model changes | Yes | New schemas: User, AnonymousSession, Project, AnalysisResult |
| API changes | Yes | New REST API: /analyze, /auth, /projects, /reports |
| NFR impact | Yes | Async job processing, JWT auth, WCAG 2.1 AA, configurable scoring weights |

### Risk Assessment

| Attribute | Value |
|---|---|
| Risk Level | Medium |
| Rollback Complexity | Moderate (greenfield — no existing system to break) |
| Testing Complexity | Moderate (async job pattern, data transfer flow, PDF generation) |
| Key Risk Areas | Async polling reliability, pilot-to-CC data transfer, PDF generation on AWS |

---

## Workflow Visualization

```
INCEPTION PHASE
+---------------------------+
| Workspace Detection  DONE |
| Requirements Analysis DONE|
| User Stories         DONE |
| Workflow Planning    NOW  |
| Application Design EXECUTE|
| Units Generation   EXECUTE|
+---------------------------+
           |
           v
CONSTRUCTION PHASE (per unit)
+---------------------------+
| Functional Design  EXECUTE|
| NFR Requirements   EXECUTE|
| NFR Design         EXECUTE|
| Infrastructure     EXECUTE|
| Code Generation    EXECUTE|
+---------------------------+
           |
           v
+---------------------------+
| Build and Test     EXECUTE|
+---------------------------+
           |
           v
OPERATIONS PHASE
+---------------------------+
| Operations     PLACEHOLDER|
+---------------------------+
```

---

## Phases to Execute

### INCEPTION PHASE

- [x] Workspace Detection — COMPLETED
- [x] Requirements Analysis — COMPLETED
- [x] User Stories — COMPLETED
- [x] Workflow Planning — IN PROGRESS (this document)
- [ ] Application Design — **EXECUTE**
  - Rationale: New system with multiple new components (React SPA, FastAPI services, DynamoDB tables, async job processor). Component boundaries, service interfaces, and data models need definition before code generation.
- [ ] Units Generation — **EXECUTE**
  - Rationale: System naturally decomposes into 3 parallel units of work that can be developed independently: (1) Frontend React App, (2) Backend API + Decision Engine, (3) AWS Infrastructure. Units Generation will define these boundaries and sequencing.

### CONSTRUCTION PHASE (per unit)

- [ ] Functional Design — **EXECUTE** (per unit)
  - Rationale: New data models (User, Project, AnalysisResult, AnonymousSession), new business logic (scoring engine, data transfer flow), and new API contracts need detailed design before code.
- [ ] NFR Requirements — **EXECUTE** (per unit)
  - Rationale: Async job processing pattern, JWT authentication, WCAG 2.1 AA compliance, configurable scoring weights, and DynamoDB TTL all require NFR specification.
- [ ] NFR Design — **EXECUTE** (per unit)
  - Rationale: NFR patterns (async polling, JWT middleware, accessibility patterns, environment-based config) need to be incorporated into the design before code generation.
- [ ] Infrastructure Design — **EXECUTE** (per unit)
  - Rationale: AWS services need explicit mapping: Amplify (frontend), API Gateway + Lambda or ECS (backend), DynamoDB (database), IAM roles, HTTPS/SSL. Infrastructure-as-code (CDK or SAM) needs specification.
- [ ] Code Generation — **EXECUTE** (per unit, ALWAYS)
  - Rationale: Implementation of all 3 units.
- [ ] Build and Test — **EXECUTE** (ALWAYS)
  - Rationale: Build instructions, unit tests, integration tests for the full pilot-to-dashboard flow.

### OPERATIONS PHASE

- [ ] Operations — PLACEHOLDER
  - Rationale: Future deployment and monitoring workflows not in scope for this build.

---

## Proposed Units of Work

| Unit | Name | Contents |
|---|---|---|
| Unit 1 | Frontend React App | Landing page, Input form, Processing screen, Output screen, Signup screen, Dashboard (all 6 screens) |
| Unit 2 | Backend API + Decision Engine | FastAPI app, 4 analysis modules, scoring engine, async job processor, auth endpoints, project endpoints, PDF generation |
| Unit 3 | AWS Infrastructure | DynamoDB tables, API Gateway, Lambda/ECS deployment, Amplify config, IAM roles, environment config |

**Recommended sequence**: Unit 3 (infra) → Unit 2 (backend) → Unit 1 (frontend)  
**Rationale**: Infrastructure must exist before backend can be deployed; backend API contracts must be defined before frontend integration.

---

## Success Criteria

- Primary Goal: Working pilot app — user can go from landing page to GO/REVISE/NO-GO decision without login, then sign up and access CC dashboard
- Key Deliverables: React frontend, FastAPI backend, DynamoDB schema, AWS deployment config, PDF generation, JWT auth
- Quality Gates: All 21 user stories have passing acceptance criteria; async job completes within 2 minutes; WCAG 2.1 AA on public screens
