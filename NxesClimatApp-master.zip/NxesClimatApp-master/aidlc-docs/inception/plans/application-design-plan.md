# Application Design Plan
# NxES Decision Core Pilot App

**Status**: EXECUTING

## Design Checklist

- [x] Step 1: Analyze requirements and user stories
- [x] Step 2: Identify components and boundaries
- [x] Step 3: Generate components.md
- [x] Step 4: Generate component-methods.md
- [x] Step 5: Generate services.md
- [x] Step 6: Generate component-dependency.md
- [x] Step 7: Generate application-design.md (consolidated)

## Design Decisions (derived from requirements — no questions needed)

- Frontend: React SPA with React Router (client-side routing, no SSR needed for pilot scale)
- Backend: FastAPI with async endpoints; background jobs via asyncio or Celery
- Component pattern: Feature-based folder structure on frontend; layered architecture on backend (router → service → module)
- Service layer: AnalysisService orchestrates the 4 scoring modules; AuthService handles JWT; ProjectService handles DynamoDB CRUD
- Communication: REST (HTTP/JSON) between frontend and backend; polling for async job status
- Data flow: Anonymous session ID in localStorage → passed on signup → backend links records in DynamoDB
