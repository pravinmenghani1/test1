# Requirements Verification Questions
# NxES Decision Core Pilot App

Please answer each question by filling in the letter choice after the `[Answer]:` tag.
If none of the options match, choose the last option (Other) and describe your preference.
Let me know when you're done.

---

## SECTION 1: Technical Stack & Architecture

## Question 1
What is your preferred frontend technology for the pilot app?

A) React (with TypeScript)
B) Next.js (React-based, SSR/SSG support)
C) Vue.js
D) Plain HTML/CSS/JavaScript (no framework)
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Question 2
What is your preferred backend technology for the Decision Core API?

A) Node.js with Express or Fastify
B) Python with FastAPI or Django
C) Java with Spring Boot
D) .NET / C#
E) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 3
Where will this app be hosted/deployed?

A) AWS (e.g., Amplify, EC2, Lambda, ECS)
B) Vercel / Netlify (frontend) + cloud backend
C) Azure
D) Self-hosted / on-premises
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Question 4
What database should be used for temporary project storage (pilot mode) and the full CC platform?

A) PostgreSQL (relational)
B) MongoDB (NoSQL document)
C) DynamoDB (AWS managed NoSQL)
D) SQLite for pilot, PostgreSQL for full platform
E) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## SECTION 2: Decision Core Engine Logic

## Question 5
The spec references "existing CC logic" (MRV validation, financial logic, risk scoring, additionality). Does this logic already exist as code somewhere, or does it need to be built from scratch for this pilot?

A) It exists — I will provide the existing code/API endpoints to integrate
B) It exists partially — some modules exist, others need to be built
C) It does not exist yet — build simplified versions from scratch for the pilot
D) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## Question 6
How should the scoring algorithm work for the pilot? The spec defines GO (>70), REVISE (40-70), NO-GO (<40). How should the score be calculated from the 5 input fields?

A) Simple weighted average across the 4 modules (MRV, Financial, Risk, Additionality)
B) Rule-based scoring: each field maps to a fixed score contribution
C) AI/ML model inference (e.g., a trained model or LLM call)
D) I will provide the exact scoring logic/formula
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Question 7
What project types should be available in the "Project Type" dropdown?

A) Standard carbon project types: Forestry/REDD+, Renewable Energy, Cookstoves, Waste-to-Energy, Blue Carbon, Agriculture
B) A broader list — I will provide the full list
C) Keep it generic for now (3-5 placeholder types)
D) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## SECTION 3: Authentication & User Management

## Question 8
What authentication method should be used for the account creation / CC platform login?

A) Email + password only
B) Email + password + Google OAuth
C) Email + password + Google + LinkedIn OAuth
D) Magic link (passwordless email)
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Question 9
Should the pilot app store temporary project data (before signup) in:

A) Browser localStorage / sessionStorage only (no server-side temp storage)
B) Server-side with a temporary session token (expires after X hours)
C) Both: localStorage as primary, server-side as backup
D) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## SECTION 4: File Upload

## Question 10
The spec mentions optional file upload. What file types should be accepted?

A) PDF only
B) PDF and Excel/CSV
C) PDF, Excel/CSV, and Word documents
D) No file upload needed for the pilot MVP
E) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## Question 11
What should happen with uploaded files in the pilot?

A) Parse and extract data to pre-fill form fields
B) Store the file and reference it in the analysis output
C) Ignore file content — just acknowledge upload and proceed with form fields only
D) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## SECTION 5: Output & Reporting

## Question 12
After the GO/REVISE/NO-GO result, should the output screen include:

A) Decision + Score + Risk Level + 3-5 Key Issues (as per spec) — no PDF
B) Decision + Score + Risk Level + 3-5 Key Issues + downloadable PDF summary
C) Decision + Score + Risk Level + 3-5 Key Issues + shareable link
D) All of the above (PDF + shareable link)
E) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 13
The "full report" is unlocked after signup. What should the full report contain beyond the pilot output?

A) Detailed breakdown per module (MRV, Financial, Risk, Additionality) with recommendations
B) Everything in A + benchmark comparisons against similar projects
C) Everything in A + action plan / next steps roadmap
D) I will define the full report content separately — just build the gate/prompt for now
E) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## SECTION 6: CC Platform Dashboard

## Question 14
For the CC platform dashboard (Screen 6), what is the scope for this build?

A) Build a fully functional dashboard with project management, reports, and data views
B) Build a minimal dashboard shell: welcome screen + saved project card + report links only
C) The CC dashboard already exists — just build the handoff/redirect from pilot to existing platform
D) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## SECTION 7: Design & Branding

## Question 15
What is the design/branding direction for the app?

A) Use existing NxES brand guidelines (please share colors, fonts, logo)
B) Clean, professional climate-tech aesthetic (greens, blues, white — I'll approve mockups)
C) Minimal and functional — design is secondary to functionality for now
D) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 16
Should the app support multiple languages?

A) English only for now
B) English + French
C) English + Spanish
D) English + Arabic
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## SECTION 8: Non-Functional Requirements

## Question 17
What are the expected performance targets for the analysis engine?

A) Result delivered within 5 seconds (fast, synchronous API call)
B) Result delivered within 30 seconds (async processing with loading animation)
C) Result delivered within 2 minutes (background job with email notification)
D) No specific target — best effort
E) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## Question 18
What is the expected initial user load for the pilot?

A) Very small — internal testing only (< 50 users)
B) Small — limited beta (50–500 users)
C) Medium — public launch (500–5,000 users)
D) Large — marketing campaign expected (5,000+ users)
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## SECTION 9: Extensions

## Question 19 — Security Extension
Should security extension rules be enforced for this project?

A) Yes — enforce all SECURITY rules as blocking constraints (recommended for production-grade applications)
B) No — skip all SECURITY rules (suitable for PoCs, prototypes, and experimental projects)
C) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 20 — Compliance & Audit Trail Extension
Does this project require compliance logging (regulated industries, AI Act, NIST AI RMF)?

A) Yes — enforce structured audit trail, IP attribution, and data residency rules (ENABLE compliance)
B) No — standard audit.md logging is sufficient (SKIP compliance extension)
C) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 21 — Cost & Token Budget Governance Extension
Do you want to enforce token budget limits and cost tracking for this workflow?

A) Yes — enforce token budgets, model-tier selection, and cost logging (ENABLE cost governance)
B) No — no cost constraints for this workflow (SKIP cost governance)
C) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 22 — Metrics & Observability Extension
Do you want AI-DLC to track phase durations, human interventions, and workflow outcomes?

A) Yes — enable phase timing, intervention logging, and outcome tracking (ENABLE metrics)
B) No — skip metrics collection for this workflow (SKIP metrics)
C) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Question 23 — Multi-Agent Coordination Extension
Will multiple AI agents or sessions work on this project simultaneously?

A) Yes — multiple agents or sessions will work in parallel (ENABLE multi-agent coordination rules)
B) No — only a single agent session at a time (SKIP multi-agent coordination rules)
C) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Question 24 — Property-Based Testing Extension
Should property-based testing (PBT) rules be enforced for this project?

A) Yes — enforce all PBT rules as blocking constraints (recommended for projects with business logic, data transformations, or stateful components)
B) Partial — enforce PBT rules only for pure functions and serialization round-trips
C) No — skip all PBT rules (suitable for simple CRUD or UI-only projects)
D) Other (please describe after [Answer]: tag below)

[Answer]: C
