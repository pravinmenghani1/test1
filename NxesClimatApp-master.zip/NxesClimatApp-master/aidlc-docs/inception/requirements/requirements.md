# Requirements Document
# NxES Decision Core Pilot App

**Version**: 1.0  
**Date**: 2026-05-18  
**Status**: Draft — Awaiting Approval

---

## 1. Intent Analysis Summary

| Attribute | Value |
|---|---|
| **User Request** | Build a standalone pilot app that validates climate projects using Decision Core logic, produces GO/REVISE/NO-GO decisions, and converts users to the full CC platform |
| **Request Type** | New Project (Greenfield) |
| **Scope Estimate** | System-wide — 6 screens, frontend + backend API + database + auth + file handling |
| **Complexity Estimate** | Complex — multi-layer architecture, scoring engine, auth flow, dashboard, AWS deployment |

---

## 2. System Architecture Overview

The app is structured as 6 layers:

```
Layer 1: Public Landing Page (no login)
Layer 2: Pilot Input Form (no login required)
Layer 3: Decision Core Engine (backend API)
Layer 4: Decision Output Screen (GO / REVISE / NO-GO)
Layer 5: Conversion / Sign-Up Screen
Layer 6: CC Platform Dashboard (post-login)
```

**Critical Flow (non-negotiable)**:
Landing → Try (no login) → Input → Analysis → Decision → Signup → Dashboard

---

## 3. Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React (TypeScript) |
| Backend API | Python with FastAPI |
| Hosting | AWS (Amplify for frontend, Lambda/ECS for backend) |
| Database | DynamoDB (AWS managed NoSQL) |
| Auth | Email + Password (JWT-based) |
| File Storage (pilot) | Browser localStorage as base64 (small files only, session-scoped) |
| File Types Accepted | PDF, Excel/CSV, Word documents |

---

## 4. Functional Requirements

### FR-01: Landing Page (Screen 1)

- **FR-01.1** Display hero section with title: "Validate climate projects before capital is deployed"
- **FR-01.2** Display subtitle explaining the GO/NO-GO decision in minutes
- **FR-01.3** Display primary CTA button: "Try Decision Core (Pilot)" — no login required
- **FR-01.4** Display secondary CTA: "See example" (shows a sample result)
- **FR-01.5** Display NxES logo and navigation menu (How it works, Use cases, Login)
- **FR-01.6** Display value strip with 4 icons: Faster decisions, Lower risk, Better impact, More transparency
- **FR-01.7** Value must be communicated within 10 seconds of page load
- **FR-01.8** Use climate-tech aesthetic: greens, blues, white (professional, clean)

### FR-02: Input Form (Screen 2 — Pilot Mode, No Login)

- **FR-02.1** Display input panel with maximum 5 fields:
  1. Project Type (dropdown): Forestry/REDD+, Renewable Energy, Cookstoves, Waste-to-Energy, Blue Carbon, Agriculture
  2. Location (country dropdown)
  3. Short Description (text area, max 500 characters)
  4. Stage (dropdown): Idea, Pilot, Scaling
  5. Optional: Upload file (PDF, Excel/CSV, Word — stored as base64 in localStorage)
- **FR-02.2** Display explanation panel: "What happens next?" with 3 steps (Analysis → Scoring → Decision)
- **FR-02.3** Display "Run Analysis" CTA button (primary action)
- **FR-02.4** No login or account required to access this screen
- **FR-02.5** Form validation: Project Type, Location, and Description are required; Stage and file upload are optional
- **FR-02.6** Uploaded files stored as base64 in browser localStorage (session-scoped, lost on tab close)
- **FR-02.7** File size limit: 5MB maximum (localStorage constraint)

### FR-03: Processing / Loading Screen (Screen 3)

- **FR-03.1** Display animated progress steps:
  - Checking MRV feasibility
  - Evaluating financial logic
  - Assessing risks
  - Validating additionality
- **FR-03.2** Display progress bar
- **FR-03.3** Title: "Analyzing your project..."
- **FR-03.4** Processing is a background job — result delivered within 2 minutes
- **FR-03.5** Screen must build trust and communicate intelligence during wait

### FR-04: Decision Output Screen (Screen 4 — "Aha Moment")

- **FR-04.1** Display large decision card with color-coded result:
  - GO → green
  - REVISE → yellow/amber
  - NO-GO → red
- **FR-04.2** Display score (0–100)
- **FR-04.3** Display risk level: Low / Medium / High
- **FR-04.4** Display readiness indicator (visual bar or dots)
- **FR-04.5** Display 3–5 key issues/insights as bullet points
- **FR-04.6** Display "Next step" suggestion text
- **FR-04.7** Display CTA: "Create account to unlock full report"
- **FR-04.8** Display downloadable PDF summary of the pilot result
- **FR-04.9** Decision must be understandable within 5 seconds — no jargon
- **FR-04.10** Decision logic (non-negotiable):
  - Score > 70 → GO
  - Score 40–70 → REVISE
  - Score < 40 → NO-GO

### FR-05: Sign-Up / Conversion Screen (Screen 5)

- **FR-05.1** Display minimal sign-up form: Email + Password
- **FR-05.2** Display message: "Your analysis is saved. Create account to continue."
- **FR-05.3** On successful signup, transfer pilot project data from localStorage to DynamoDB under the new user account
- **FR-05.4** Redirect user to CC Dashboard (Screen 6) with project pre-loaded
- **FR-05.5** Auth method: Email + Password (JWT tokens)
- **FR-05.6** No social login required for MVP

### FR-06: CC Platform Dashboard (Screen 6)

- **FR-06.1** Display left sidebar navigation: Overview, Projects, Data, Decisions, Reports
- **FR-06.2** Display welcome message with user name and project name
- **FR-06.3** Display project status card: Decision (GO/REVISE/NO-GO), Score, Risk Level
- **FR-06.4** Display progress bar for project readiness
- **FR-06.5** Display report links:
  - Decision Report (PDF download)
  - Risk Analysis
  - MRV Summary
- **FR-06.6** Full report content (unlocked post-signup):
  - Detailed breakdown per module: MRV, Financial, Risk, Additionality with recommendations
  - Benchmark comparisons against similar projects
- **FR-06.7** Full project management: create, view, edit projects
- **FR-06.8** Data views and decision history

### FR-07: Decision Core Engine (Backend API)

- **FR-07.1** Expose a simplified REST API endpoint: `POST /api/v1/analyze`
- **FR-07.2** Accept inputs: project_type, location, description, stage, file_reference (optional)
- **FR-07.3** Run 4 simplified analysis modules built from scratch:

| Module | Pilot Logic |
|---|---|
| MRV Validation | Simplified validation based on project type + location |
| Financial Logic | Basic viability check based on project type + stage |
| Risk Scoring | High/Medium/Low based on location + stage combination |
| Additionality | Yes/No/Uncertain based on project type |

- **FR-07.4** Calculate composite score using weighted average across 4 modules:
  - MRV: 30% weight
  - Financial: 25% weight
  - Risk: 25% weight
  - Additionality: 20% weight
- **FR-07.5** Apply decision logic: >70 = GO, 40–70 = REVISE, <40 = NO-GO
- **FR-07.6** Return: decision, score, risk_level, readiness, key_issues (array of 3–5 strings)
- **FR-07.7** Processing is asynchronous — job queued, result polled or pushed via WebSocket/SSE
- **FR-07.8** Do NOT expose full CC complexity — wrap into simplified API layer only
- **FR-07.9** Store analysis result in DynamoDB with a temporary anonymous session ID

### FR-08: Data Flow — Pilot to CC Transfer

- **FR-08.1** Pilot project data stored temporarily in DynamoDB with anonymous session ID (TTL: 24 hours)
- **FR-08.2** On user signup, link anonymous session data to new user account in DynamoDB
- **FR-08.3** Project persists in CC platform after account creation
- **FR-08.4** File reference (base64 metadata) transferred with project record

---

## 5. Non-Functional Requirements

### NFR-01: Performance
- **NFR-01.1** Analysis result delivered within 2 minutes (background job)
- **NFR-01.2** Landing page load time < 2 seconds
- **NFR-01.3** Input form submission response (job acknowledgement) < 1 second

### NFR-02: Scalability
- **NFR-02.1** Initial target: internal testing only (<50 concurrent users)
- **NFR-02.2** Architecture must be horizontally scalable on AWS for future growth

### NFR-03: Usability
- **NFR-03.1** User must reach first result within 2–3 minutes of landing
- **NFR-03.2** No login required before seeing the decision result
- **NFR-03.3** Output must be self-explanatory — no user manual needed
- **NFR-03.4** Progressive disclosure — do not show all data layers at once
- **NFR-03.5** Single core action: everything leads to "Run Decision Core"

### NFR-04: Security (Basic — PoC/Prototype level, security extension not enforced)
- **NFR-04.1** JWT-based authentication for CC platform access
- **NFR-04.2** HTTPS enforced on all endpoints
- **NFR-04.3** No sensitive data stored in localStorage beyond session scope
- **NFR-04.4** DynamoDB TTL on anonymous session records (24 hours)

### NFR-05: Reliability
- **NFR-05.1** AWS-hosted infrastructure with standard availability
- **NFR-05.2** Graceful error handling — user sees friendly error messages, not stack traces

### NFR-06: Maintainability
- **NFR-06.1** Scoring weights configurable without code changes (environment variables or config file)
- **NFR-06.2** Module logic separated into distinct Python modules for future replacement with real CC logic

### NFR-07: Accessibility
- **NFR-07.1** WCAG 2.1 AA compliance for all public-facing screens
- **NFR-07.2** Color-coded decisions (GO/REVISE/NO-GO) must also use text labels (not color alone)

### NFR-08: Internationalisation
- **NFR-08.1** English only for MVP

---

## 6. Multi-Agent Coordination (COORD rules — ENABLED)

Per Q23 answer (multi-agent enabled), the following rules apply to all agent sessions:

- **COORD-01**: Each agent operates on a dedicated branch; file locks via `.aidlc-lock/`
- **COORD-02**: After 2 consecutive CI failures, agent stops and creates escalation document
- **COORD-03**: Conflicting changes labeled and logged — no auto-merge
- **COORD-04**: All agents read `aidlc-state.md` at session start before any work

---

## 7. Success Metrics

| Metric | Target |
|---|---|
| % users who run analysis | > 60% of landing page visitors |
| % users who sign up after result | > 20% of users who see the decision |
| Time to first result | < 3 minutes |
| Drop-off rate on input form | < 30% |

---

## 8. Out of Scope (What NOT to Build)

- Full CC interface or complex dashboards beyond Screen 6 spec
- Social login (Google, LinkedIn)
- Multi-language support
- AI/ML model for scoring (rule-based weighted average only)
- Real-time file parsing / pre-fill from uploaded documents
- Email notifications for background job completion
- Admin panel or user management UI

---

## 9. Screens Summary

| Screen | Name | Login Required |
|---|---|---|
| 1 | Landing Page | No |
| 2 | Input Form (Pilot Mode) | No |
| 3 | Processing / Loading | No |
| 4 | Decision Output | No |
| 5 | Sign-Up / Conversion | No (creates account) |
| 6 | CC Dashboard | Yes |

---

## 10. Extension Configuration

| Extension | Enabled | Decision |
|---|---|---|
| Security Baseline | No | PoC/prototype — basic security only |
| Compliance & Audit Trail | No | Standard audit.md logging sufficient |
| Cost & Token Budget Governance | No | No cost constraints |
| Metrics & Observability | No | Not required |
| Multi-Agent Coordination | Yes | Multiple agent sessions expected |
| Property-Based Testing | No | Simple CRUD + UI project |
