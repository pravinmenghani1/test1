# Units of Work
# NxES Decision Core Pilot App

**Total Units**: 3  
**Development Sequence**: Unit 3 → Unit 2 → Unit 1

---

## Unit 1: Frontend React App

**Type**: Single deployable unit (React SPA)  
**Deployment Target**: AWS Amplify  
**Development Order**: 3rd (depends on Unit 2 API contracts)

### Scope
All user-facing screens and client-side logic:
- Screen 1: LandingPage + ExampleResultModal
- Screen 2: InputForm (with file upload to localStorage)
- Screen 3: ProcessingScreen + PollingService
- Screen 4: OutputScreen (decision display + PDF download)
- Screen 5: SignupScreen + LoginScreen + ProjectTransferService
- Screen 6: Dashboard + ProjectsList + FullReportView

### Components Included
C-FE-01, C-FE-02, C-FE-03, C-FE-04, C-FE-05, C-FE-06, C-FE-07, C-FE-08, C-FE-09, C-FE-10  
SVC-05 (ProjectTransferService), SVC-06 (PollingService)

### Code Organisation
```
frontend/
  src/
    pages/          # One folder per screen (LandingPage, InputForm, etc.)
    components/     # Shared UI components (DecisionCard, ProgressBar, etc.)
    services/       # API clients, PollingService, ProjectTransferService
    hooks/          # Custom React hooks
    types/          # TypeScript interfaces and types
    utils/          # Helpers (base64 encoding, localStorage utils)
    App.tsx         # Router setup
    main.tsx        # Entry point
  public/
  package.json
  tsconfig.json
  vite.config.ts    # or CRA config
```

### Key Dependencies
- React 18 + TypeScript
- React Router v6
- Axios (HTTP client)
- jsPDF or react-pdf (PDF generation)
- Tailwind CSS or styled-components (styling)

### Entry/Exit Criteria
- **Entry**: Unit 2 API contracts finalised (endpoint URLs, request/response schemas)
- **Exit**: All 6 screens render correctly; pilot flow works end-to-end against Unit 2 API; WCAG 2.1 AA verified on public screens

---

## Unit 2: Backend API + Decision Engine

**Type**: Single deployable unit (FastAPI application)  
**Deployment Target**: AWS Lambda (via Mangum adapter) or ECS Fargate  
**Development Order**: 2nd (depends on Unit 3 DynamoDB tables and IAM roles)

### Scope
All backend logic:
- Analysis API: job submission, async processing, status polling
- Decision Core Engine: 4 scoring modules + weighted average + decision thresholds
- Auth API: signup, login, JWT issuance
- Project API: project listing, detail, full report
- PDF generation service
- DynamoDB data access layer

### Components Included
C-BE-01 through C-BE-13  
SVC-01 (AnalysisService), SVC-02 (AuthService), SVC-03 (ProjectService), SVC-04 (PDFService)

### Code Organisation
```
backend/
  app/
    routers/        # AnalysisRouter, AuthRouter, ProjectRouter
    services/       # AnalysisService, AuthService, ProjectService, PDFService
    modules/        # MRVModule, FinancialModule, RiskModule, AdditionalityModule
    repositories/   # ProjectRepository, UserRepository
    models/         # Pydantic request/response models
    core/           # Config, JWT middleware, DynamoDB client
    main.py         # FastAPI app entry point
  tests/
  requirements.txt
  Dockerfile        # or SAM template.yaml for Lambda
```

### Key Dependencies
- FastAPI + Uvicorn
- Mangum (Lambda adapter, if Lambda deployment)
- boto3 (DynamoDB)
- python-jose (JWT)
- passlib + bcrypt (password hashing)
- reportlab or weasyprint (PDF generation)
- pytest + httpx (testing)

### Configuration (environment variables)
```
DYNAMODB_TABLE_PROJECTS=nxes-projects
DYNAMODB_TABLE_USERS=nxes-users
DYNAMODB_TABLE_SESSIONS=nxes-sessions
JWT_SECRET_KEY=<secret>
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=24
MRV_WEIGHT=0.30
FINANCIAL_WEIGHT=0.25
RISK_WEIGHT=0.25
ADDITIONALITY_WEIGHT=0.20
AWS_REGION=us-east-1
```

### Entry/Exit Criteria
- **Entry**: Unit 3 DynamoDB tables created; IAM execution role available
- **Exit**: All API endpoints return correct responses; scoring engine produces correct GO/REVISE/NO-GO for test inputs; anonymous session transfer works correctly

---

## Unit 3: AWS Infrastructure

**Type**: Infrastructure-as-Code  
**Deployment Target**: AWS (CDK or SAM)  
**Development Order**: 1st (no dependencies — must be provisioned before other units)

### Scope
All AWS resource definitions:
- DynamoDB tables (Users, Projects, AnonymousSessions with TTL)
- API Gateway (HTTP API)
- Lambda function or ECS task definition
- AWS Amplify app configuration
- IAM roles and policies
- Environment configuration

### Components Included
C-INF-01 (Amplify), C-INF-02 (API Gateway), C-INF-03 (Lambda/ECS), C-INF-04 (DynamoDB), C-INF-05 (IAM)

### Code Organisation
```
infrastructure/
  lib/
    dynamodb-stack.ts     # DynamoDB tables
    api-stack.ts          # API Gateway + Lambda/ECS
    amplify-stack.ts      # Frontend hosting
    iam-stack.ts          # Roles and policies
  bin/
    app.ts                # CDK app entry point
  cdk.json
  package.json
```

### Entry/Exit Criteria
- **Entry**: AWS account and credentials configured
- **Exit**: All AWS resources provisioned; DynamoDB tables accessible; API Gateway endpoint URL available for Unit 2 deployment; Amplify app URL available for Unit 1 deployment

---

## Summary Table

| Attribute | Unit 1: Frontend | Unit 2: Backend | Unit 3: Infrastructure |
|---|---|---|---|
| Language | TypeScript | Python | TypeScript (CDK) |
| Framework | React 18 | FastAPI | AWS CDK v2 |
| Deploy target | AWS Amplify | Lambda / ECS | AWS CloudFormation |
| Dev order | 3rd | 2nd | 1st |
| Stories | EP-01 to EP-06 | EP-07 + API layer | N/A (infra) |
| Blocking dependency | Unit 2 API contracts | Unit 3 tables + IAM | None |
