# Unit of Work — Story Map
# NxES Decision Core Pilot App

All 21 user stories assigned to units. Infrastructure unit has no user stories (it is a technical enabler).

---

## Unit 1: Frontend React App

| Story ID | Story Title | Epic | Screen |
|---|---|---|---|
| US-01.1 | View Landing Page | EP-01 | Screen 1 |
| US-01.2 | See Example Result | EP-01 | Screen 1 |
| US-01.3 | Navigate to Login | EP-01 | Screen 1 |
| US-02.1 | Submit Project for Analysis | EP-02 | Screen 2 |
| US-02.2 | Select Project Type | EP-02 | Screen 2 |
| US-02.3 | Upload Supporting File | EP-02 | Screen 2 |
| US-02.4 | View "What Happens Next" | EP-02 | Screen 2 |
| US-03.1 | View Analysis Progress | EP-03 | Screen 3 |
| US-03.2 | Wait for Background Job | EP-03 | Screen 3 |
| US-04.1 | View Decision Result | EP-04 | Screen 4 |
| US-04.2 | Read Key Issues | EP-04 | Screen 4 |
| US-04.3 | Download Pilot PDF Summary | EP-04 | Screen 4 |
| US-04.4 | See Conversion CTA | EP-04 | Screen 4 |
| US-05.1 | Create Account from Result Screen | EP-05 | Screen 5 |
| US-05.2 | Transfer Pilot Data to CC Account | EP-05 | Screen 5 |
| US-05.3 | Sign In to Existing Account | EP-05 | Screen 5 |
| US-06.1 | First Login Experience | EP-06 | Screen 6 |
| US-06.2 | View Full Decision Report | EP-06 | Screen 6 |
| US-06.3 | Download Full Report as PDF | EP-06 | Screen 6 |
| US-06.4 | Navigate Dashboard Sections | EP-06 | Screen 6 |
| US-06.5 | View All Projects | EP-06 | Screen 6 |
| US-06.6 | View Decision History | EP-06 | Screen 6 |

**Total: 22 stories** (all EP-01 through EP-06)

---

## Unit 2: Backend API + Decision Engine

| Story ID | Story Title | Epic | Layer |
|---|---|---|---|
| US-07.1 | Calculate Composite Score | EP-07 | AnalysisService |
| US-07.2 | Apply Decision Thresholds | EP-07 | AnalysisService |
| US-07.3 | Return Structured Analysis Response | EP-07 | AnalysisRouter |

**Total: 3 stories** (EP-07 — technical stories)

**Note**: Unit 2 also implements the server-side of all API endpoints consumed by Unit 1. The Unit 1 stories implicitly require Unit 2 API implementations. The EP-07 stories capture the engine-specific acceptance criteria.

---

## Unit 3: AWS Infrastructure

| Story ID | Story Title | Notes |
|---|---|---|
| — | No user stories | Infrastructure is a technical enabler; no user-facing stories |

**Total: 0 user stories**  
**Deliverables**: DynamoDB tables, API Gateway, Lambda/ECS, Amplify, IAM roles

---

## Story Coverage Verification

| Epic | Stories | Assigned To | Coverage |
|---|---|---|---|
| EP-01 Landing Page | 3 | Unit 1 | 100% |
| EP-02 Input Form | 4 | Unit 1 | 100% |
| EP-03 Processing | 2 | Unit 1 | 100% |
| EP-04 Decision Output | 4 | Unit 1 | 100% |
| EP-05 Conversion Flow | 3 | Unit 1 | 100% |
| EP-06 CC Dashboard | 6 | Unit 1 | 100% |
| EP-07 Decision Engine | 3 | Unit 2 | 100% |
| **Total** | **25** | | **100%** |

---

## Construction Phase Execution Order

Based on unit dependencies, the per-unit construction loop executes in this order:

```
CONSTRUCTION PHASE

[Unit 3: Infrastructure]
  Functional Design  → EXECUTE (DynamoDB schema, IAM policy design)
  NFR Requirements   → EXECUTE (availability, TTL, IAM least-privilege)
  NFR Design         → EXECUTE (DynamoDB capacity mode, backup config)
  Infrastructure Design → EXECUTE (CDK stack definitions)
  Code Generation    → EXECUTE (CDK TypeScript code)

[Unit 2: Backend API + Decision Engine]
  Functional Design  → EXECUTE (scoring rules, API contracts, data models)
  NFR Requirements   → EXECUTE (async job pattern, JWT, PDF generation)
  NFR Design         → EXECUTE (FastAPI middleware, async patterns)
  Infrastructure Design → EXECUTE (Lambda packaging, ECS task def)
  Code Generation    → EXECUTE (FastAPI Python code)

[Unit 1: Frontend React App]
  Functional Design  → EXECUTE (component state, routing, form logic)
  NFR Requirements   → EXECUTE (WCAG 2.1 AA, polling timeout, localStorage limits)
  NFR Design         → EXECUTE (accessibility patterns, error boundaries)
  Infrastructure Design → EXECUTE (Amplify build config, env vars)
  Code Generation    → EXECUTE (React TypeScript code)

[Build and Test — all units]
```
