# Services
# NxES Decision Core Pilot App

Services are the orchestration layer — they coordinate components and enforce business rules.

---

## SVC-01: AnalysisService

**Layer**: Backend — Core Business Logic  
**Orchestrates**: MRVModule, FinancialModule, RiskModule, AdditionalityModule, ProjectRepository

**Responsibilities**:
- Accept raw project input from AnalysisRouter
- Fan out to all 4 scoring modules (can run in parallel via asyncio)
- Aggregate module scores into composite weighted score
- Apply decision thresholds to produce GO/REVISE/NO-GO
- Select 3–5 key issues from module outputs (prioritise lowest-scoring modules)
- Persist AnalysisResult to DynamoDB with anonymous session ID and 24h TTL
- Return structured AnalysisResult to router

**Interaction pattern**: Synchronous orchestration within an async FastAPI background task

---

## SVC-02: AuthService

**Layer**: Backend — Authentication  
**Orchestrates**: UserRepository, JWT library (python-jose)

**Responsibilities**:
- On signup: validate email uniqueness, hash password (bcrypt), create user record, link anonymous session ID to user, issue JWT
- On login: fetch user by email, verify password hash, issue JWT
- Token verification middleware: validate JWT on protected routes, inject user claims into request context

**Interaction pattern**: Called by AuthRouter; JWT middleware applied as FastAPI dependency

---

## SVC-03: ProjectService

**Layer**: Backend — Project Management  
**Orchestrates**: ProjectRepository, PDFService

**Responsibilities**:
- Retrieve projects for authenticated user (enforces ownership — user can only see their own projects)
- Retrieve full report data: combines AnalysisResult with module detail and benchmark data
- Delegate PDF generation to PDFService

**Interaction pattern**: Called by ProjectRouter with authenticated user context from JWT middleware

---

## SVC-04: PDFService

**Layer**: Backend — Report Generation  
**Orchestrates**: PDF library (reportlab or weasyprint)

**Responsibilities**:
- Generate pilot PDF: 1-page summary with decision, score, risk, key issues, next step
- Generate full report PDF: multi-page with module breakdowns, benchmark comparisons, recommendations
- Return PDF as bytes (streamed as HTTP response) or write to temp storage

**Interaction pattern**: Called by ProjectService and directly by AnalysisRouter (for pilot PDF)

---

## SVC-05: ProjectTransferService (Frontend)

**Layer**: Frontend — Session Handoff  
**Orchestrates**: localStorage, AuthAPI

**Responsibilities**:
- On signup success: read anonymous session ID from localStorage
- Pass session ID to AuthAPI signup endpoint
- Clear anonymous session data from localStorage after successful transfer
- Confirm project is visible in Dashboard before clearing

**Interaction pattern**: Called by SignupScreen component after successful account creation

---

## SVC-06: PollingService (Frontend)

**Layer**: Frontend — Async Job Monitoring  
**Orchestrates**: AnalysisAPI, ProcessingScreen state

**Responsibilities**:
- Poll `GET /api/v1/analyze/{session_id}` every 5 seconds
- Update ProcessingScreen animation state based on job progress
- Resolve with AnalysisResult when job status = complete
- Reject with timeout error after 120 seconds (2 minutes)

**Interaction pattern**: Called by ProcessingScreen; uses setInterval with cleanup on unmount

---

## Service Interaction Summary

```
User submits form
      |
      v
[InputForm] --> POST /api/v1/analyze --> [AnalysisRouter]
                                               |
                                         [AnalysisService]
                                         /    |    |    \
                                   [MRV] [Fin] [Risk] [Add]
                                         \    |    |    /
                                          [score + decision]
                                               |
                                         [ProjectRepository] --> DynamoDB (TTL 24h)
                                               |
                                    returns session_id + job_id
                                               |
[ProcessingScreen] polls GET /analyze/{id} <--+
      |
      v (job complete)
[OutputScreen] renders result
      |
      v (user clicks signup)
[SignupScreen] --> POST /api/v1/auth/signup (with session_id)
                        |
                  [AuthService] creates user, links session
                        |
                  [ProjectRepository] transfers record to user
                        |
                  returns JWT
                        |
[Dashboard] loads with project pre-populated
```
