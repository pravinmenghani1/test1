# Unit of Work Dependencies
# NxES Decision Core Pilot App

---

## Dependency Matrix

| Unit | Depends On | Dependency Type | Blocking? |
|---|---|---|---|
| Unit 1: Frontend | Unit 2 API contracts (endpoint URLs + schemas) | Interface contract | Yes — frontend cannot be built without knowing API shape |
| Unit 1: Frontend | Unit 3 Amplify config (deploy URL) | Deployment | Yes — for final deployment; development can use localhost |
| Unit 2: Backend | Unit 3 DynamoDB tables (table names + ARNs) | Infrastructure | Yes — backend cannot connect to DB without tables |
| Unit 2: Backend | Unit 3 IAM execution role | Infrastructure | Yes — Lambda/ECS needs permissions to access DynamoDB |
| Unit 3: Infrastructure | None | — | No dependencies |

---

## Development Sequence

```
Unit 3: Infrastructure
  |
  | Provides: DynamoDB table names, IAM role ARN, API Gateway URL
  v
Unit 2: Backend API + Decision Engine
  |
  | Provides: API endpoint URLs, request/response schemas
  v
Unit 1: Frontend React App
```

---

## Parallel Development Opportunities

While strict deployment order is Unit 3 → Unit 2 → Unit 1, development can be parallelised:

| Parallel Track | What Can Start Immediately |
|---|---|
| Track A | Unit 3: Infrastructure (CDK stacks) |
| Track B | Unit 2: Backend logic (modules, services, repositories) — using local DynamoDB or mocks |
| Track C | Unit 1: Frontend screens — using mock API responses (MSW or hardcoded fixtures) |

**Coordination points** (where tracks must sync):
1. After Unit 3 complete → Unit 2 connects to real DynamoDB, runs integration tests
2. After Unit 2 API contracts finalised → Unit 1 switches from mocks to real API calls
3. After all units deployed → end-to-end integration test of full pilot flow

---

## Shared Contracts (must be agreed before parallel development)

### API Contract (Unit 2 → Unit 1)
Agreed in Application Design. Key schemas:

```json
POST /api/v1/analyze
Request:  { "project_type": string, "location": string, "description": string, "stage": string?, "file_reference": string? }
Response: { "session_id": string, "status": "queued" }

GET /api/v1/analyze/{session_id}
Response: { "status": "processing"|"complete"|"failed", "result": AnalysisResult? }

POST /api/v1/auth/signup
Request:  { "email": string, "password": string, "session_id": string? }
Response: { "token": string, "user_id": string }

POST /api/v1/auth/login
Request:  { "email": string, "password": string }
Response: { "token": string, "user_id": string }

GET /api/v1/projects
Response: { "projects": Project[] }

GET /api/v1/projects/{id}/report
Response: FullReport
```

### DynamoDB Table Names (Unit 3 → Unit 2)
Passed via environment variables — no code coupling.

### Environment Variables (Unit 3 → Unit 2 → Unit 1)
```
# Unit 2 needs from Unit 3:
DYNAMODB_TABLE_PROJECTS, DYNAMODB_TABLE_USERS, DYNAMODB_TABLE_SESSIONS, AWS_REGION

# Unit 1 needs from Unit 2:
VITE_API_BASE_URL (the API Gateway endpoint URL)
```

---

## Risk: Async Job Pattern

The async analysis job (Unit 2) and the polling mechanism (Unit 1) are tightly coupled by the job status contract. Both units must agree on:
- Status values: `queued`, `processing`, `complete`, `failed`
- Progress field: optional array of completed steps for animation
- Timeout behaviour: what the API returns after 2 minutes

This contract must be finalised before Unit 1 ProcessingScreen development begins.
