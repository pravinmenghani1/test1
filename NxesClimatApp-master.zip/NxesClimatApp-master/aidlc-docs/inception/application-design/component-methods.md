# Component Methods
# NxES Decision Core Pilot App

Note: Detailed business rules and logic are defined in Functional Design (CONSTRUCTION phase). This document captures method signatures and high-level purpose only.

---

## FRONTEND METHODS

### C-FE-02: InputForm

| Method | Signature | Purpose |
|---|---|---|
| handleFileUpload | (file: File) => void | Reads file, encodes as base64, stores in localStorage |
| validateForm | (formData: ProjectInput) => ValidationResult | Checks required fields before submission |
| handleSubmit | (formData: ProjectInput) => Promise\<void\> | Submits to AnalysisAPI, stores session ID, navigates to ProcessingScreen |

### C-FE-03: ProcessingScreen

| Method | Signature | Purpose |
|---|---|---|
| pollJobStatus | (sessionId: string) => Promise\<JobStatus\> | Polls GET /analyze/{sessionId} every 5 seconds |
| handleJobComplete | (result: AnalysisResult) => void | Navigates to OutputScreen with result |
| handleJobTimeout | () => void | Shows timeout message after 2 minutes |

### C-FE-04: OutputScreen

| Method | Signature | Purpose |
|---|---|---|
| renderDecisionCard | (decision: Decision, score: number) => JSX.Element | Renders colour-coded GO/REVISE/NO-GO card |
| handleDownloadPDF | () => Promise\<void\> | Calls PDFService, triggers browser download |
| handleConversionCTA | () => void | Navigates to SignupScreen, passes session ID |

### C-FE-05: SignupScreen

| Method | Signature | Purpose |
|---|---|---|
| handleSignup | (email: string, password: string) => Promise\<void\> | Calls AuthAPI signup, passes anonymous session ID for data transfer |
| handleSignupSuccess | (jwt: string) => void | Stores JWT, navigates to Dashboard |

### C-FE-06: LoginScreen

| Method | Signature | Purpose |
|---|---|---|
| handleLogin | (email: string, password: string) => Promise\<void\> | Calls AuthAPI login, stores JWT on success |

### C-FE-07: Dashboard

| Method | Signature | Purpose |
|---|---|---|
| checkAuth | () => boolean | Verifies JWT in localStorage; redirects to Login if missing/expired |
| loadUserProjects | () => Promise\<Project[]\> | Fetches projects from ProjectAPI |

### C-FE-08: ProjectsList

| Method | Signature | Purpose |
|---|---|---|
| fetchProjects | () => Promise\<Project[]\> | Calls GET /projects with JWT |
| handleProjectClick | (projectId: string) => void | Navigates to FullReportView for selected project |

### C-FE-09: FullReportView

| Method | Signature | Purpose |
|---|---|---|
| fetchFullReport | (projectId: string) => Promise\<FullReport\> | Calls GET /projects/{id}/report with JWT |
| handleDownloadFullPDF | (projectId: string) => Promise\<void\> | Calls PDFService for full report PDF |

---

## BACKEND METHODS

### C-BE-02: AnalysisService

| Method | Signature | Purpose |
|---|---|---|
| run_analysis | (input: ProjectInput) -> AnalysisResult | Orchestrates all 4 modules, computes score, applies thresholds, persists result |
| compute_score | (module_scores: ModuleScores) -> int | Applies weighted average formula |
| apply_decision | (score: int) -> Decision | Maps score to GO/REVISE/NO-GO |
| generate_key_issues | (module_scores: ModuleScores) -> list[str] | Selects 3–5 most significant issues from module outputs |

### C-BE-03: MRVModule

| Method | Signature | Purpose |
|---|---|---|
| score | (project_type: str, location: str) -> ModuleScore | Returns 0–100 score and list of issues |

### C-BE-04: FinancialModule

| Method | Signature | Purpose |
|---|---|---|
| score | (project_type: str, stage: str) -> ModuleScore | Returns 0–100 score and list of issues |

### C-BE-05: RiskModule

| Method | Signature | Purpose |
|---|---|---|
| score | (location: str, stage: str) -> ModuleScore | Returns 0–100 score, risk_level, and list of issues |

### C-BE-06: AdditionalityModule

| Method | Signature | Purpose |
|---|---|---|
| score | (project_type: str) -> ModuleScore | Returns 0–100 score, additionality_status, and list of issues |

### C-BE-08: AuthService

| Method | Signature | Purpose |
|---|---|---|
| signup | (email: str, password: str, session_id: str) -> AuthResult | Creates user, hashes password, links anonymous session, issues JWT |
| login | (email: str, password: str) -> AuthResult | Validates credentials, issues JWT |
| verify_token | (token: str) -> UserClaims | Validates JWT, returns user claims |

### C-BE-10: ProjectService

| Method | Signature | Purpose |
|---|---|---|
| get_projects | (user_id: str) -> list[Project] | Returns all projects for user |
| get_project | (user_id: str, project_id: str) -> Project | Returns single project (enforces ownership) |
| get_full_report | (user_id: str, project_id: str) -> FullReport | Returns full report with module breakdowns and benchmarks |

### C-BE-11: PDFService

| Method | Signature | Purpose |
|---|---|---|
| generate_pilot_pdf | (result: AnalysisResult) -> bytes | Generates pilot summary PDF |
| generate_full_pdf | (report: FullReport) -> bytes | Generates full report PDF |

### C-BE-12: ProjectRepository

| Method | Signature | Purpose |
|---|---|---|
| save_anonymous_session | (session_id: str, result: AnalysisResult) -> None | Saves result with 24h TTL |
| link_session_to_user | (session_id: str, user_id: str) -> None | Transfers anonymous record to user account |
| get_projects_by_user | (user_id: str) -> list[Project] | Queries DynamoDB by user_id |
| get_project | (project_id: str) -> Project | Fetches single project record |

### C-BE-13: UserRepository

| Method | Signature | Purpose |
|---|---|---|
| create_user | (email: str, hashed_password: str) -> User | Creates user record in DynamoDB |
| get_user_by_email | (email: str) -> User \| None | Fetches user for login validation |

---

## DATA TYPES

```typescript
// Frontend types
type Decision = 'GO' | 'REVISE' | 'NO-GO'
type RiskLevel = 'Low' | 'Medium' | 'High'
type ProjectStage = 'Idea' | 'Pilot' | 'Scaling'

interface ProjectInput {
  project_type: string
  location: string
  description: string
  stage?: ProjectStage
  file_reference?: string  // base64 metadata
}

interface AnalysisResult {
  session_id: string
  decision: Decision
  score: number           // 0-100
  risk_level: RiskLevel
  readiness: number       // 0-100
  key_issues: string[]    // 3-5 items
}

interface FullReport extends AnalysisResult {
  modules: {
    mrv: ModuleDetail
    financial: ModuleDetail
    risk: ModuleDetail
    additionality: ModuleDetail
  }
  benchmarks: BenchmarkData
}
```

```python
# Backend types
from dataclasses import dataclass
from typing import Literal

Decision = Literal['GO', 'REVISE', 'NO-GO']
RiskLevel = Literal['Low', 'Medium', 'High']

@dataclass
class ModuleScore:
    score: int          # 0-100
    issues: list[str]
    metadata: dict      # module-specific fields (risk_level, additionality_status, etc.)

@dataclass
class ModuleScores:
    mrv: ModuleScore
    financial: ModuleScore
    risk: ModuleScore
    additionality: ModuleScore

@dataclass
class AnalysisResult:
    session_id: str
    decision: Decision
    score: int
    risk_level: RiskLevel
    readiness: int
    key_issues: list[str]
```
