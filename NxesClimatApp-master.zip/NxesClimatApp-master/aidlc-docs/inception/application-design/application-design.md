# Application Design — Consolidated
# NxES Decision Core Pilot App

**Version**: 1.0  
**Date**: 2026-05-21  
**Status**: Complete

---

## 1. Architecture Overview

The NxES Decision Core Pilot App is a three-tier web application:

```
Tier 1: React SPA (TypeScript)
  - Hosted on AWS Amplify
  - Client-side routing (React Router)
  - No server-side rendering required at pilot scale
  - Communicates with backend via REST/JSON over HTTPS

Tier 2: FastAPI Backend (Python)
  - Deployed on AWS Lambda (or ECS for persistent connections)
  - Layered architecture: Router → Service → Module/Repository
  - Async background jobs for analysis processing
  - JWT-based authentication middleware

Tier 3: AWS DynamoDB
  - Three tables: Users, Projects, AnonymousSessions
  - AnonymousSessions table has 24-hour TTL
  - Single-table design per entity for simplicity at pilot scale
```

---

## 2. Component Summary

### Frontend (10 components)

| ID | Component | Screen |
|---|---|---|
| C-FE-01 | LandingPage | Screen 1 |
| C-FE-02 | InputForm | Screen 2 |
| C-FE-03 | ProcessingScreen | Screen 3 |
| C-FE-04 | OutputScreen | Screen 4 |
| C-FE-05 | SignupScreen | Screen 5 |
| C-FE-06 | LoginScreen | Screen 5 (returning users) |
| C-FE-07 | Dashboard | Screen 6 |
| C-FE-08 | ProjectsList | Screen 6 — Projects section |
| C-FE-09 | FullReportView | Screen 6 — Reports section |
| C-FE-10 | ExampleResultModal | Screen 1 (overlay) |

### Backend (13 components)

| ID | Component | Layer |
|---|---|---|
| C-BE-01 | AnalysisRouter | Router |
| C-BE-02 | AnalysisService | Service |
| C-BE-03 | MRVModule | Analysis Module |
| C-BE-04 | FinancialModule | Analysis Module |
| C-BE-05 | RiskModule | Analysis Module |
| C-BE-06 | AdditionalityModule | Analysis Module |
| C-BE-07 | AuthRouter | Router |
| C-BE-08 | AuthService | Service |
| C-BE-09 | ProjectRouter | Router |
| C-BE-10 | ProjectService | Service |
| C-BE-11 | PDFService | Utility Service |
| C-BE-12 | ProjectRepository | Data Access |
| C-BE-13 | UserRepository | Data Access |

### Infrastructure (5 components)

| ID | Component | AWS Service |
|---|---|---|
| C-INF-01 | Amplify | Frontend hosting |
| C-INF-02 | API Gateway | HTTP entry point |
| C-INF-03 | Lambda / ECS | Backend compute |
| C-INF-04 | DynamoDB | Database |
| C-INF-05 | IAM Roles | Access control |

---

## 3. Service Summary

| ID | Service | Layer | Key Responsibility |
|---|---|---|---|
| SVC-01 | AnalysisService | Backend | Orchestrate 4 modules, compute score, apply decision |
| SVC-02 | AuthService | Backend | Signup, login, JWT issuance and verification |
| SVC-03 | ProjectService | Backend | Project retrieval, full report assembly |
| SVC-04 | PDFService | Backend | Pilot and full report PDF generation |
| SVC-05 | ProjectTransferService | Frontend | Transfer anonymous session to user account on signup |
| SVC-06 | PollingService | Frontend | Poll analysis job status, drive ProcessingScreen animation |

---

## 4. Critical User Flow — Component Sequence

```
1. Alex visits /
   LandingPage renders

2. Alex clicks "Try Decision Core"
   Navigate to /try
   InputForm renders

3. Alex fills form + clicks "Run Analysis"
   InputForm.handleSubmit()
   POST /api/v1/analyze
   AnalysisRouter → AnalysisService → [4 modules] → ProjectRepository (DynamoDB, TTL 24h)
   Returns: { session_id, job_id }
   Navigate to /analyzing

4. ProcessingScreen polls GET /api/v1/analyze/{session_id}
   PollingService polls every 5s
   Animation progresses through 4 steps
   Job completes (within 2 min)
   Navigate to /result

5. OutputScreen renders
   Decision card (GO/REVISE/NO-GO), score, risk, key issues
   Alex clicks "Create account to unlock full report"
   Navigate to /signup

6. SignupScreen
   Alex submits email + password
   POST /api/v1/auth/signup (includes session_id from localStorage)
   AuthService creates user, links session, issues JWT
   ProjectTransferService clears localStorage
   Navigate to /dashboard

7. Dashboard renders
   Project status card pre-loaded
   Alex accesses full report, downloads PDF
```

---

## 5. DynamoDB Table Design

### Table: Users
```
PK: USER#{email}
Attributes: user_id, email, hashed_password, created_at
```

### Table: Projects
```
PK: USER#{user_id}
SK: PROJECT#{project_id}
Attributes: project_id, project_type, location, description, stage,
            file_reference, decision, score, risk_level, readiness,
            key_issues, module_scores, created_at
GSI: project_id-index (for direct project lookup)
```

### Table: AnonymousSessions
```
PK: SESSION#{session_id}
Attributes: session_id, analysis_result, created_at, ttl (Unix timestamp, 24h)
TTL attribute: ttl
```

---

## 6. API Contract Summary

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | /api/v1/analyze | None | Submit project for analysis |
| GET | /api/v1/analyze/{session_id} | None | Poll job status / get result |
| POST | /api/v1/auth/signup | None | Create account + transfer session |
| POST | /api/v1/auth/login | None | Login, get JWT |
| GET | /api/v1/projects | JWT | List user's projects |
| GET | /api/v1/projects/{id} | JWT | Get project detail |
| GET | /api/v1/projects/{id}/report | JWT | Get full report |
| GET | /api/v1/projects/{id}/pdf | JWT | Download full report PDF |
| GET | /api/v1/analyze/{session_id}/pdf | None | Download pilot PDF |

---

## 7. Detailed Artifacts

- Components: `aidlc-docs/inception/application-design/components.md`
- Methods: `aidlc-docs/inception/application-design/component-methods.md`
- Services: `aidlc-docs/inception/application-design/services.md`
- Dependencies: `aidlc-docs/inception/application-design/component-dependency.md`
