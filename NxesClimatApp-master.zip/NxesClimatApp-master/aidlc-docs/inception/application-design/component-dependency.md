# Component Dependencies
# NxES Decision Core Pilot App

---

## Dependency Matrix

| Component | Depends On | Communication Pattern |
|---|---|---|
| C-FE-02 InputForm | AnalysisAPI (C-BE-01) | REST POST |
| C-FE-03 ProcessingScreen | AnalysisAPI (C-BE-01), PollingService (SVC-06) | REST GET (polling) |
| C-FE-04 OutputScreen | PDFService (C-BE-11 via API) | REST GET |
| C-FE-05 SignupScreen | AuthAPI (C-BE-07), ProjectTransferService (SVC-05) | REST POST |
| C-FE-06 LoginScreen | AuthAPI (C-BE-07) | REST POST |
| C-FE-07 Dashboard | ProjectAPI (C-BE-09), JWT (localStorage) | REST GET |
| C-FE-08 ProjectsList | ProjectAPI (C-BE-09) | REST GET |
| C-FE-09 FullReportView | ProjectAPI (C-BE-09), PDFService (C-BE-11 via API) | REST GET |
| C-BE-01 AnalysisRouter | AnalysisService (C-BE-02) | Direct call |
| C-BE-02 AnalysisService | MRVModule, FinancialModule, RiskModule, AdditionalityModule, ProjectRepository | Direct call |
| C-BE-07 AuthRouter | AuthService (C-BE-08) | Direct call |
| C-BE-08 AuthService | UserRepository (C-BE-13), ProjectRepository (C-BE-12) | Direct call |
| C-BE-09 ProjectRouter | ProjectService (C-BE-10), AuthService (JWT middleware) | Direct call |
| C-BE-10 ProjectService | ProjectRepository (C-BE-12), PDFService (C-BE-11) | Direct call |
| C-BE-11 PDFService | None (standalone) | — |
| C-BE-12 ProjectRepository | DynamoDB (C-INF-04) | AWS SDK |
| C-BE-13 UserRepository | DynamoDB (C-INF-04) | AWS SDK |
| C-INF-02 API Gateway | Lambda/ECS (C-INF-03) | HTTP proxy |
| C-INF-03 Lambda/ECS | DynamoDB (C-INF-04), IAM (C-INF-05) | AWS SDK |

---

## Data Flow Diagram

```
BROWSER (React SPA)
+--------------------------------------------------+
| LandingPage                                      |
|   --> InputForm                                  |
|         --> [POST /api/v1/analyze]               |
|               --> ProcessingScreen               |
|                     --> [GET /api/v1/analyze/id] |
|                           --> OutputScreen       |
|                                 --> SignupScreen |
|                                 --> [POST /auth] |
|                                       --> Dashboard
+--------------------------------------------------+
         |                        |
         | HTTPS (API Gateway)    | JWT in Authorization header
         v                        v
AWS BACKEND (FastAPI)
+--------------------------------------------------+
| AnalysisRouter --> AnalysisService               |
|                       --> MRVModule              |
|                       --> FinancialModule        |
|                       --> RiskModule             |
|                       --> AdditionalityModule    |
|                       --> ProjectRepository      |
|                                                  |
| AuthRouter --> AuthService                       |
|                   --> UserRepository             |
|                   --> ProjectRepository          |
|                                                  |
| ProjectRouter --> ProjectService                 |
|                      --> ProjectRepository       |
|                      --> PDFService              |
+--------------------------------------------------+
         |
         v
AWS DynamoDB
+--------------------------------------------------+
| Table: Projects (PK: project_id, SK: user_id)   |
| Table: Users (PK: email)                         |
| Table: AnonymousSessions (PK: session_id, TTL)  |
+--------------------------------------------------+
```

---

## Key Coupling Points

| Coupling Point | Components Involved | Risk |
|---|---|---|
| Anonymous session ID | InputForm ↔ AuthService ↔ ProjectRepository | Medium — must be consistent across localStorage and DynamoDB |
| JWT token | All authenticated frontend components ↔ AuthService middleware | Low — standard pattern |
| AnalysisResult schema | AnalysisService ↔ OutputScreen ↔ PDFService | Medium — schema changes affect all three |
| Scoring weights | AnalysisService config ↔ environment variables | Low — configurable, no code coupling |
| DynamoDB table names | All repositories ↔ Infrastructure config | Low — environment variable driven |

---

## Frontend Routing Structure

```
/ (LandingPage)
/try (InputForm)
/analyzing (ProcessingScreen)
/result (OutputScreen)
/signup (SignupScreen)
/login (LoginScreen)
/dashboard (Dashboard — protected)
  /dashboard/projects (ProjectsList)
  /dashboard/projects/:id (FullReportView)
  /dashboard/decisions (DecisionHistory)
  /dashboard/reports (ReportsView)
```
