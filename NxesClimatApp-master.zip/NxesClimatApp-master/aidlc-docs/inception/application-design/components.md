# Components
# NxES Decision Core Pilot App

---

## FRONTEND COMPONENTS (React / TypeScript)

### C-FE-01: LandingPage
**Purpose**: Public entry point — communicates value and drives users to the pilot flow.
**Responsibilities**:
- Render hero section, value strip, navigation
- Handle "Try Decision Core" CTA → navigate to InputForm
- Handle "See example" CTA → render ExampleResultModal
- Handle "Login" link → navigate to LoginScreen

---

### C-FE-02: InputForm
**Purpose**: Collect minimum project data for analysis (no login required).
**Responsibilities**:
- Render 5-field form (Project Type, Location, Description, Stage, File Upload)
- Validate required fields (Project Type, Location, Description)
- Handle file selection → encode as base64 → store in localStorage
- Submit form data → call AnalysisAPI → navigate to ProcessingScreen
- Store anonymous session ID returned by API in localStorage

---

### C-FE-03: ProcessingScreen
**Purpose**: Display animated progress while the background analysis job runs.
**Responsibilities**:
- Render 4 animated steps (MRV, Financial, Risk, Additionality)
- Poll AnalysisAPI for job completion status
- Navigate to OutputScreen when job is complete
- Show timeout message if job exceeds 2 minutes

---

### C-FE-04: OutputScreen
**Purpose**: Deliver the "aha moment" — the GO/REVISE/NO-GO decision.
**Responsibilities**:
- Render decision card (colour-coded + text label)
- Render score, risk level, readiness indicator
- Render 3–5 key issues as bullet points
- Render next step suggestion
- Handle "Download PDF" → call PDFService
- Handle "Create account to unlock full report" CTA → navigate to SignupScreen

---

### C-FE-05: SignupScreen
**Purpose**: Convert anonymous pilot user to registered CC user.
**Responsibilities**:
- Render minimal signup form (Email + Password)
- Display "Your analysis is saved" message
- Submit signup → call AuthAPI → on success, call ProjectTransferService
- Navigate to Dashboard on successful account creation

---

### C-FE-06: LoginScreen
**Purpose**: Authenticate returning registered users.
**Responsibilities**:
- Render login form (Email + Password)
- Submit credentials → call AuthAPI → store JWT in localStorage
- Navigate to Dashboard on success
- Display error on invalid credentials

---

### C-FE-07: Dashboard
**Purpose**: Full CC platform experience for registered users.
**Responsibilities**:
- Render sidebar navigation (Overview, Projects, Data, Decisions, Reports)
- Render welcome message + project status card on first login
- Route to sub-sections: ProjectsList, DecisionHistory, ReportsView
- Guard route — redirect to LoginScreen if no valid JWT

---

### C-FE-08: ProjectsList
**Purpose**: Display all user projects with decision status.
**Responsibilities**:
- Fetch and render list of projects from ProjectAPI
- Display project name, type, location, decision, score per row
- Navigate to project detail / full report on row click
- Render empty state with CTA if no projects

---

### C-FE-09: FullReportView
**Purpose**: Display the full post-signup decision report.
**Responsibilities**:
- Fetch full report data from ReportAPI (requires JWT)
- Render module breakdowns (MRV, Financial, Risk, Additionality) with scores and recommendations
- Render benchmark comparison section
- Handle "Download Full PDF" → call PDFService

---

### C-FE-10: ExampleResultModal
**Purpose**: Show a pre-populated sample result to visitors on the landing page.
**Responsibilities**:
- Render static sample decision output (REVISE, score 58, 3 key issues)
- Dismissable overlay — no API call required

---

## BACKEND COMPONENTS (Python / FastAPI)

### C-BE-01: AnalysisRouter
**Purpose**: HTTP entry point for analysis requests.
**Responsibilities**:
- Expose `POST /api/v1/analyze` — accept project inputs, enqueue job, return session ID
- Expose `GET /api/v1/analyze/{session_id}` — return job status and result when complete
- Validate request payload (required fields, types)
- Delegate to AnalysisService

---

### C-BE-02: AnalysisService
**Purpose**: Orchestrate the 4 analysis modules and compute the composite score.
**Responsibilities**:
- Receive project inputs from AnalysisRouter
- Call MRVModule, FinancialModule, RiskModule, AdditionalityModule
- Apply weighted average: MRV×0.30 + Financial×0.25 + Risk×0.25 + Additionality×0.20
- Apply decision thresholds: >70=GO, 40–70=REVISE, <40=NO-GO
- Generate 3–5 key issues based on module scores
- Persist result to DynamoDB via ProjectRepository
- Return structured AnalysisResult

---

### C-BE-03: MRVModule
**Purpose**: Simplified MRV feasibility scoring.
**Responsibilities**:
- Accept project_type and location as inputs
- Return normalised score (0–100) and contributing issues
- Logic built from scratch (simplified rules, not full CC MRV)

---

### C-BE-04: FinancialModule
**Purpose**: Basic financial viability scoring.
**Responsibilities**:
- Accept project_type and stage as inputs
- Return normalised score (0–100) and contributing issues

---

### C-BE-05: RiskModule
**Purpose**: Risk level scoring.
**Responsibilities**:
- Accept location and stage as inputs
- Return normalised score (0–100), risk_level (Low/Medium/High), and contributing issues

---

### C-BE-06: AdditionalityModule
**Purpose**: Additionality assessment.
**Responsibilities**:
- Accept project_type as input
- Return normalised score (0–100), additionality_status (Yes/No/Uncertain), and contributing issues

---

### C-BE-07: AuthRouter
**Purpose**: HTTP entry point for authentication.
**Responsibilities**:
- Expose `POST /api/v1/auth/signup` — create user, link anonymous session, return JWT
- Expose `POST /api/v1/auth/login` — validate credentials, return JWT
- Delegate to AuthService

---

### C-BE-08: AuthService
**Purpose**: User authentication and JWT management.
**Responsibilities**:
- Hash passwords (bcrypt)
- Validate credentials on login
- Issue and verify JWT tokens
- Link anonymous session ID to new user account on signup

---

### C-BE-09: ProjectRouter
**Purpose**: HTTP entry point for project management.
**Responsibilities**:
- Expose `GET /api/v1/projects` — list user's projects (requires JWT)
- Expose `GET /api/v1/projects/{project_id}` — get project detail (requires JWT)
- Expose `GET /api/v1/projects/{project_id}/report` — get full report (requires JWT)
- Delegate to ProjectService

---

### C-BE-10: ProjectService
**Purpose**: Project and report business logic.
**Responsibilities**:
- Retrieve projects for authenticated user from DynamoDB
- Retrieve full report data (module breakdowns + benchmark data)
- Enforce access control — users can only access their own projects

---

### C-BE-11: PDFService
**Purpose**: Generate PDF reports.
**Responsibilities**:
- Generate pilot PDF summary (decision, score, risk, key issues, next step)
- Generate full report PDF (module breakdowns, benchmarks, recommendations)
- Return PDF as binary response or pre-signed S3 URL

---

### C-BE-12: ProjectRepository
**Purpose**: DynamoDB data access layer.
**Responsibilities**:
- CRUD operations for Project and AnalysisResult records
- Create anonymous session records with 24-hour TTL
- Link anonymous session to user account on signup
- Query projects by user ID

---

### C-BE-13: UserRepository
**Purpose**: DynamoDB data access layer for users.
**Responsibilities**:
- Create user records on signup
- Retrieve user by email for login
- Store hashed passwords only

---

## INFRASTRUCTURE COMPONENTS (AWS)

### C-INF-01: AWS Amplify
**Purpose**: Host and serve the React frontend.
**Responsibilities**: Static site hosting, CDN, HTTPS, CI/CD from git

### C-INF-02: API Gateway
**Purpose**: HTTP entry point for all backend API calls.
**Responsibilities**: Route requests to Lambda/ECS, HTTPS termination, CORS

### C-INF-03: Lambda / ECS
**Purpose**: Run the FastAPI backend.
**Responsibilities**: Execute API handlers, run analysis jobs asynchronously

### C-INF-04: DynamoDB
**Purpose**: Persistent data store.
**Responsibilities**: Store Users, Projects, AnalysisResults, AnonymousSessions (with TTL)

### C-INF-05: IAM Roles
**Purpose**: Least-privilege access control.
**Responsibilities**: Lambda/ECS execution role with DynamoDB read/write permissions
