# Code Generation Plan — Unit 2: Backend API + Decision Engine

**Code location**: `backend/` (workspace root)
**Language**: Python 3.12 / FastAPI
**Stories**: US-07.1, US-07.2, US-07.3 (Decision Engine) + API layer for all EP-01–EP-06 stories

## Steps

- [x] Step 1: Create backend/ project structure and requirements.txt
- [x] Step 2: Create core config, DynamoDB client, JWT utilities
- [x] Step 3: Create Pydantic models (requests.py, responses.py)
- [x] Step 4: Create scoring modules (MRV, Financial, Risk, Additionality)
- [x] Step 5: Create AnalysisService (orchestration + scoring + decision)
- [x] Step 6: Create repositories (ProjectRepository, UserRepository)
- [x] Step 7: Create AuthService
- [x] Step 8: Create ProjectService + PDFService
- [x] Step 9: Create routers (analysis, auth, projects)
- [x] Step 10: Create main.py (FastAPI app + Mangum)
- [x] Step 11: Create tests
- [x] Step 12: Write code summary
