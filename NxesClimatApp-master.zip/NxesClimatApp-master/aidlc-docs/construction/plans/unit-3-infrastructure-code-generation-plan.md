# Code Generation Plan — Unit 3: Infrastructure
# NxES Decision Core Pilot App

**Code location**: `infrastructure/` (workspace root)
**Language**: TypeScript (AWS CDK v2)
**Stories**: No user stories — infrastructure enabler unit

## Steps

- [x] Step 1: Create infrastructure/ project structure and package.json
- [x] Step 2: Create CDK app entry point (bin/app.ts)
- [x] Step 3: Create NxesDatabaseStack (DynamoDB tables)
- [x] Step 4: Create NxesComputeStack (Lambda + IAM + Secrets Manager)
- [x] Step 5: Create NxesApiStack (API Gateway HTTP API)
- [x] Step 6: Create NxesFrontendStack (Amplify)
- [x] Step 7: Create cdk.json and tsconfig.json
- [x] Step 8: Create infrastructure README
- [x] Step 9: Write code summary to aidlc-docs/construction/unit-3-infrastructure/code/
