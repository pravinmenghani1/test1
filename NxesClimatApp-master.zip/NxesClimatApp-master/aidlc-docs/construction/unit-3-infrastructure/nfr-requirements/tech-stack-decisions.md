# Tech Stack Decisions — Unit 3: Infrastructure

| Decision | Choice | Rationale |
|---|---|---|
| IaC framework | AWS CDK v2 (TypeScript) | Type-safe, composable, native AWS constructs, aligns with frontend TypeScript |
| Database | DynamoDB (PAY_PER_REQUEST) | Serverless, auto-scaling, zero ops, AWS-native, TTL support built-in |
| Backend compute | AWS Lambda (via Mangum) | Serverless, zero ops, scales to zero (cost-efficient for pilot), FastAPI compatible via Mangum |
| API layer | API Gateway HTTP API | Lower cost than REST API, sufficient for pilot, native Lambda integration |
| Frontend hosting | AWS Amplify | Zero-config React hosting, CI/CD from git, CDN, HTTPS automatic |
| Secrets management | AWS Secrets Manager | Secure JWT secret storage, IAM-controlled access, rotation support |
| Logging | CloudWatch Logs | Native Lambda/ECS integration, no additional setup |
| Backup | DynamoDB PITR | Point-in-time recovery for user and project data |

## CDK Stack Structure

| Stack | Contents |
|---|---|
| NxesDatabaseStack | DynamoDB tables (sessions, users, projects) + PITR config |
| NxesComputeStack | Lambda function + IAM execution role + Secrets Manager secret |
| NxesApiStack | API Gateway HTTP API + Lambda integration + CORS config |
| NxesFrontendStack | Amplify app + build config + environment variables |
