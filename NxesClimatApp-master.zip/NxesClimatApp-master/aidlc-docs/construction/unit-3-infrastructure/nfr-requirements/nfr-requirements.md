# NFR Requirements — Unit 3: Infrastructure

## NFR-INF-01: Availability
- DynamoDB: AWS-managed, 99.99% SLA — no additional configuration needed at pilot scale
- API Gateway: AWS-managed, 99.95% SLA
- Lambda: AWS-managed, no single point of failure
- Amplify: AWS-managed CDN, global availability
- **Target**: Standard AWS availability — no multi-region or active-active required for pilot (<50 users)

## NFR-INF-02: Performance
- DynamoDB PAY_PER_REQUEST: single-digit millisecond reads/writes — sufficient for pilot
- API Gateway latency overhead: ~5ms — acceptable
- Lambda cold start: mitigated by provisioned concurrency (optional) or acceptable for pilot scale
- **Target**: Infrastructure adds <50ms overhead to API response times

## NFR-INF-03: Security
- All data in transit: HTTPS enforced via API Gateway and Amplify (TLS 1.2+)
- All data at rest: DynamoDB encryption at rest enabled by default (AWS-managed keys)
- JWT secret: stored in AWS Secrets Manager, not in environment variables
- IAM: least-privilege execution role — DynamoDB + CloudWatch Logs + SSM only
- No public DynamoDB access — all access via Lambda/ECS execution role only

## NFR-INF-04: Scalability
- DynamoDB PAY_PER_REQUEST scales automatically — no capacity planning
- Lambda scales automatically (up to account concurrency limits)
- API Gateway scales automatically
- **Target**: Architecture supports growth from <50 to 5,000+ users without infrastructure changes

## NFR-INF-05: Cost
- PAY_PER_REQUEST DynamoDB: ~$0 at pilot scale (<50 users, minimal reads/writes)
- Lambda: free tier covers pilot scale (1M requests/month free)
- API Gateway HTTP API: ~$1/million requests
- Amplify: free tier covers pilot scale
- **Target**: Near-zero infrastructure cost during internal testing phase

## NFR-INF-06: Maintainability
- All infrastructure defined as code (AWS CDK v2 TypeScript)
- No manual console configuration — everything reproducible from CDK deploy
- Environment-specific configuration via CDK context or .env files
- Stack outputs exported for use by other stacks (table names, API URL, Amplify URL)

## NFR-INF-07: Data Retention
- AnonymousSession + AnalysisJob: 24-hour TTL (DynamoDB native TTL)
- User + Project records: indefinite retention
- DynamoDB point-in-time recovery (PITR): enabled on nxes-projects and nxes-users tables
