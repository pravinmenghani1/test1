# Logical Components — Unit 3: Infrastructure

## LC-INF-01: DynamoDB Tables (3 tables)

| Table | Purpose | Key Schema | TTL |
|---|---|---|---|
| nxes-sessions | Anonymous sessions + job tracking | PK: session_id | Yes (24h) |
| nxes-users | Registered users | PK: email | No |
| nxes-projects | User projects + analysis results | PK: user_id, SK: project_id | No |

GSI on nxes-projects: `project_id-index` (PK: project_id) for direct project lookup.

## LC-INF-02: Lambda Function

| Attribute | Value |
|---|---|
| Runtime | Python 3.12 |
| Handler | `app.main.handler` (via Mangum) |
| Memory | 512MB |
| Timeout | 5 minutes |
| Environment variables | DYNAMODB_TABLE_*, JWT_ALGORITHM, MRV_WEIGHT, FINANCIAL_WEIGHT, RISK_WEIGHT, ADDITIONALITY_WEIGHT, AWS_REGION, SECRETS_MANAGER_JWT_SECRET_ARN |

## LC-INF-03: IAM Execution Role

**Attached policies**:
```json
{
  "Effect": "Allow",
  "Action": ["dynamodb:GetItem","dynamodb:PutItem","dynamodb:UpdateItem",
             "dynamodb:DeleteItem","dynamodb:Query","dynamodb:Scan"],
  "Resource": [
    "arn:aws:dynamodb:{region}:{account}:table/nxes-sessions",
    "arn:aws:dynamodb:{region}:{account}:table/nxes-users",
    "arn:aws:dynamodb:{region}:{account}:table/nxes-projects",
    "arn:aws:dynamodb:{region}:{account}:table/nxes-projects/index/*"
  ]
},
{
  "Effect": "Allow",
  "Action": ["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],
  "Resource": "arn:aws:logs:{region}:{account}:*"
},
{
  "Effect": "Allow",
  "Action": ["secretsmanager:GetSecretValue"],
  "Resource": "arn:aws:secretsmanager:{region}:{account}:secret:nxes/jwt-secret-*"
}
```

## LC-INF-04: API Gateway HTTP API

| Attribute | Value |
|---|---|
| Type | HTTP API (not REST API) |
| Integration | Lambda proxy |
| CORS origins | Amplify app URL |
| CORS methods | GET, POST, OPTIONS |
| CORS headers | Authorization, Content-Type |
| Stage | $default (auto-deploy) |

## LC-INF-05: AWS Amplify App

| Attribute | Value |
|---|---|
| Source | Git repository (frontend/) |
| Build command | `npm run build` |
| Output directory | `dist` |
| Environment variable | `VITE_API_BASE_URL` = API Gateway URL |
| Branch | `main` (auto-deploy on push) |

## LC-INF-06: Secrets Manager Secret

| Attribute | Value |
|---|---|
| Secret name | `nxes/jwt-secret` |
| Secret value | `{ "JWT_SECRET_KEY": "<256-bit random string>" }` |
| Rotation | Manual (no auto-rotation for pilot) |
