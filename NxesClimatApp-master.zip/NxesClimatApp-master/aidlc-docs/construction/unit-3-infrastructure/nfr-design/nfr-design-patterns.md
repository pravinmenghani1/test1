# NFR Design Patterns — Unit 3: Infrastructure

## Pattern 1: Serverless-First (Scalability + Cost)
All compute is serverless (Lambda) and all storage is serverless (DynamoDB PAY_PER_REQUEST).
- No servers to manage, patch, or scale
- Cost scales linearly with usage — near-zero at pilot scale
- Automatic scaling handles growth without infrastructure changes

## Pattern 2: Least-Privilege IAM (Security)
Single execution role with minimal permissions:
- DynamoDB: only the three nxes-* tables, only required actions
- No wildcard resource ARNs (`*`) — explicit table ARNs only
- No S3, SQS, SNS, or other service access unless explicitly needed

## Pattern 3: Secrets Separation (Security)
JWT secret stored in Secrets Manager, not in Lambda environment variables:
- Environment variables are visible in Lambda console — not suitable for secrets
- Secrets Manager provides audit trail, rotation capability, and IAM-controlled access
- Lambda retrieves secret at cold start and caches in memory

## Pattern 4: TTL-Based Cleanup (Data Lifecycle)
DynamoDB native TTL handles anonymous session cleanup automatically:
- No cron jobs or cleanup Lambda functions needed
- TTL deletion is eventual (within 48 hours of expiry) — acceptable for pilot
- Reduces storage cost and keeps tables clean

## Pattern 5: Stack Outputs + Cross-Stack References (Maintainability)
CDK stacks export outputs (table names, ARNs, API URL) consumed by dependent stacks:
- NxesDatabaseStack exports table ARNs → consumed by NxesComputeStack for IAM policy
- NxesApiStack exports API URL → consumed by NxesFrontendStack for VITE_API_BASE_URL
- No hardcoded ARNs or URLs across stacks

## Pattern 6: PITR for Critical Data (Reliability)
Point-in-time recovery enabled on nxes-users and nxes-projects:
- Protects against accidental deletion or corruption
- 35-day recovery window
- Not enabled on nxes-sessions (ephemeral data, no recovery value)
