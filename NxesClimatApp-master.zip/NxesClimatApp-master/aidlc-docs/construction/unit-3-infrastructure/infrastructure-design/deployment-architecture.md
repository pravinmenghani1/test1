# Deployment Architecture — Unit 3: Infrastructure

## Architecture Diagram

```
Internet
    |
    | HTTPS
    v
+------------------+        +------------------+
| AWS Amplify      |        | API Gateway      |
| (React SPA)      |        | HTTP API         |
| CDN + HTTPS      |        | CORS enabled     |
+------------------+        +------------------+
         |                           |
         | VITE_API_BASE_URL         | Lambda proxy
         | (API Gateway URL)         v
         |                  +------------------+
         |                  | AWS Lambda       |
         |                  | Python 3.12      |
         |                  | FastAPI+Mangum   |
         |                  | 512MB / 5min     |
         |                  +------------------+
         |                    |    |    |
         |              DynamoDB  SSM  CloudWatch
         |                    |         Logs
         v                    v
+------------------+  +------------------+
| Browser          |  | DynamoDB         |
| localStorage     |  | nxes-sessions    |
| (session_id,     |  | nxes-users       |
|  base64 file,    |  | nxes-projects    |
|  JWT token)      |  +------------------+
+------------------+
                          +------------------+
                          | Secrets Manager  |
                          | nxes/jwt-secret  |
                          +------------------+
```

## Data Flow Summary

```
1. User visits Amplify URL → React SPA loads from CDN
2. React SPA calls API Gateway URL → proxied to Lambda
3. Lambda reads/writes DynamoDB via boto3 (execution role)
4. Lambda retrieves JWT secret from Secrets Manager at cold start
5. Lambda logs to CloudWatch Logs automatically
```

## CDK Deploy Command
```bash
cd infrastructure
npm install
npx cdk bootstrap aws://{account}/{region}
npx cdk deploy --all
```

## Stack Outputs (used by Unit 2 and Unit 1)
After `cdk deploy --all`, note these outputs:
- `NxesApiStack.ApiGatewayUrl` → set as `VITE_API_BASE_URL` in Amplify + local `.env` for Unit 1
- `NxesDatabaseStack.SessionsTableName` → set in Lambda env vars for Unit 2
- `NxesDatabaseStack.UsersTableName` → set in Lambda env vars for Unit 2
- `NxesDatabaseStack.ProjectsTableName` → set in Lambda env vars for Unit 2
- `NxesComputeStack.JwtSecretArn` → set as `SECRETS_MANAGER_JWT_SECRET_ARN` in Lambda env vars
