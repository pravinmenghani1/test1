# Infrastructure Design — Unit 3: Infrastructure

## AWS Services Map

| Logical Component | AWS Service | Configuration |
|---|---|---|
| Frontend hosting | AWS Amplify | React SPA, git-connected, CDN, HTTPS |
| API entry point | API Gateway HTTP API | Lambda proxy integration, CORS, HTTPS |
| Backend compute | AWS Lambda (Python 3.12) | 512MB, 5min timeout, Mangum adapter |
| Database | DynamoDB (3 tables) | PAY_PER_REQUEST, TTL on sessions, PITR on users+projects |
| Secrets | AWS Secrets Manager | JWT secret, IAM-controlled access |
| Access control | IAM Role | Least-privilege: DynamoDB + CloudWatch + Secrets Manager |
| Logging | CloudWatch Logs | Auto-created by Lambda |

## CDK Stack Definitions

### Stack 1: NxesDatabaseStack
```
Outputs:
  - sessionsTableArn
  - sessionsTableName
  - usersTableArn
  - usersTableName
  - projectsTableArn
  - projectsTableName
```

### Stack 2: NxesComputeStack
```
Inputs (from NxesDatabaseStack):
  - sessionsTableArn, usersTableArn, projectsTableArn

Outputs:
  - lambdaFunctionArn
  - executionRoleArn
  - jwtSecretArn
```

### Stack 3: NxesApiStack
```
Inputs (from NxesComputeStack):
  - lambdaFunctionArn

Outputs:
  - apiGatewayUrl
```

### Stack 4: NxesFrontendStack
```
Inputs (from NxesApiStack):
  - apiGatewayUrl

Outputs:
  - amplifyAppUrl
```

## Deployment Order
```
NxesDatabaseStack → NxesComputeStack → NxesApiStack → NxesFrontendStack
```

## Region
`us-east-1` (default — can be overridden via CDK context)

## Environment Variables injected into Lambda

```
DYNAMODB_TABLE_SESSIONS=nxes-sessions
DYNAMODB_TABLE_USERS=nxes-users
DYNAMODB_TABLE_PROJECTS=nxes-projects
DYNAMODB_PROJECTS_GSI=project_id-index
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=24
MRV_WEIGHT=0.30
FINANCIAL_WEIGHT=0.25
RISK_WEIGHT=0.25
ADDITIONALITY_WEIGHT=0.20
AWS_REGION=us-east-1
SECRETS_MANAGER_JWT_SECRET_ARN=<from NxesComputeStack output>
```
