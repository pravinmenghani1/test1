# Domain Entities — Unit 3: Infrastructure

## Overview
Unit 3 defines the data persistence layer. All entities are stored in DynamoDB.

---

## Entity: User

**Purpose**: Registered CC platform user

| Attribute | Type | Required | Notes |
|---|---|---|---|
| PK | String | Yes | `USER#{email}` |
| user_id | String (UUID) | Yes | Generated on signup |
| email | String | Yes | Unique identifier |
| hashed_password | String | Yes | bcrypt hash |
| created_at | String (ISO 8601) | Yes | Signup timestamp |

---

## Entity: AnonymousSession

**Purpose**: Temporary storage for pilot analysis results before user signup

| Attribute | Type | Required | Notes |
|---|---|---|---|
| PK | String | Yes | `SESSION#{session_id}` |
| session_id | String (UUID) | Yes | Generated on analysis submission |
| analysis_result | Map | Yes | Full AnalysisResult object |
| created_at | String (ISO 8601) | Yes | |
| ttl | Number (Unix timestamp) | Yes | created_at + 86400 seconds (24h) — DynamoDB TTL attribute |

---

## Entity: Project

**Purpose**: A climate project submitted by a registered user, with its analysis result

| Attribute | Type | Required | Notes |
|---|---|---|---|
| PK | String | Yes | `USER#{user_id}` |
| SK | String | Yes | `PROJECT#{project_id}` |
| project_id | String (UUID) | Yes | |
| project_type | String | Yes | One of 6 project types |
| location | String | Yes | Country name |
| description | String | Yes | Max 500 chars |
| stage | String | No | Idea / Pilot / Scaling |
| file_reference | String | No | base64 metadata string |
| decision | String | Yes | GO / REVISE / NO-GO |
| score | Number | Yes | 0–100 |
| risk_level | String | Yes | Low / Medium / High |
| readiness | Number | Yes | 0–100 |
| key_issues | List\<String\> | Yes | 3–5 items |
| module_scores | Map | Yes | MRV, Financial, Risk, Additionality scores |
| created_at | String (ISO 8601) | Yes | |
| user_id | String | Yes | Denormalised for GSI queries |

**GSI**: `project_id-index` — PK: `project_id` — enables direct project lookup without knowing user_id

---

## Entity: AnalysisJob

**Purpose**: Tracks async analysis job status (used for polling)

| Attribute | Type | Required | Notes |
|---|---|---|---|
| PK | String | Yes | `JOB#{session_id}` |
| session_id | String | Yes | Links to AnonymousSession |
| status | String | Yes | queued / processing / complete / failed |
| progress | List\<String\> | No | Completed steps for animation |
| created_at | String (ISO 8601) | Yes | |
| ttl | Number | Yes | created_at + 86400 seconds (24h) |

---

## DynamoDB Table Design

### Table: nxes-sessions (AnonymousSession + AnalysisJob)
```
PK: SESSION#{session_id} → AnonymousSession record
PK: JOB#{session_id}     → AnalysisJob record
TTL attribute: ttl
```

### Table: nxes-users (User)
```
PK: USER#{email}
```

### Table: nxes-projects (Project)
```
PK: USER#{user_id}
SK: PROJECT#{project_id}
GSI: project_id-index (PK: project_id)
```
