# Business Rules — Unit 3: Infrastructure

## Data Lifecycle Rules

| Rule | Description |
|---|---|
| BR-INF-01 | AnonymousSession records MUST have a TTL of exactly 24 hours from creation |
| BR-INF-02 | AnalysisJob records MUST have a TTL of exactly 24 hours from creation |
| BR-INF-03 | User records have no TTL — they persist indefinitely |
| BR-INF-04 | Project records have no TTL — they persist indefinitely |
| BR-INF-05 | On user signup, the AnonymousSession record MUST be copied to a Project record under the new user_id before the session TTL expires |

## Access Control Rules

| Rule | Description |
|---|---|
| BR-INF-06 | Lambda/ECS execution role MUST have read/write access to all three DynamoDB tables |
| BR-INF-07 | Lambda/ECS execution role MUST NOT have access to any other AWS services beyond DynamoDB and CloudWatch Logs |
| BR-INF-08 | DynamoDB tables MUST NOT be publicly accessible — access only via Lambda/ECS execution role |
| BR-INF-09 | API Gateway MUST enforce HTTPS — HTTP requests must be rejected or redirected |

## Capacity Rules

| Rule | Description |
|---|---|
| BR-INF-10 | DynamoDB tables use PAY_PER_REQUEST (on-demand) billing mode — no capacity planning needed at pilot scale (<50 users) |
| BR-INF-11 | Lambda memory: 512MB minimum for analysis function; 256MB for other functions |
| BR-INF-12 | Lambda timeout: 5 minutes for analysis function (covers 2-minute job + overhead); 30 seconds for all other functions |

## Environment Rules

| Rule | Description |
|---|---|
| BR-INF-13 | All DynamoDB table names MUST be passed to Lambda/ECS as environment variables — no hardcoded table names in application code |
| BR-INF-14 | JWT_SECRET_KEY MUST be stored in AWS Secrets Manager or SSM Parameter Store — not in environment variables directly |
| BR-INF-15 | Scoring weights (MRV_WEIGHT, etc.) MUST be configurable via environment variables |
