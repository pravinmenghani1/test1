# Business Logic Model — Unit 3: Infrastructure

## Scope
Unit 3 has no application business logic. Its "logic" is the infrastructure provisioning and configuration that enables Units 1 and 2 to function.

## Provisioning Logic

### DynamoDB Provisioning
1. Create `nxes-sessions` table: PK=`session_id` (String), TTL attribute=`ttl`, PAY_PER_REQUEST
2. Create `nxes-users` table: PK=`email` (String), PAY_PER_REQUEST
3. Create `nxes-projects` table: PK=`user_id` (String), SK=`project_id` (String), PAY_PER_REQUEST
4. Create GSI on `nxes-projects`: name=`project_id-index`, PK=`project_id` (String)

### IAM Provisioning
1. Create Lambda/ECS execution role
2. Attach policy: DynamoDB actions (GetItem, PutItem, UpdateItem, DeleteItem, Query, Scan) on all three tables
3. Attach policy: CloudWatch Logs (CreateLogGroup, CreateLogStream, PutLogEvents)
4. Attach policy: SSM GetParameter (for JWT secret retrieval)

### API Gateway Provisioning
1. Create HTTP API (not REST API — simpler, lower cost)
2. Configure CORS: allow origin=Amplify domain, methods=GET/POST/OPTIONS, headers=Authorization/Content-Type
3. Configure default route: proxy all requests to Lambda/ECS integration
4. Enable HTTPS only (default for API Gateway HTTP API)

### Amplify Provisioning
1. Connect to git repository (frontend source)
2. Configure build settings: `npm run build`, output directory `dist`
3. Set environment variable: `VITE_API_BASE_URL` = API Gateway endpoint URL
4. Enable custom domain (optional for pilot)

### Secrets Manager
1. Create secret: `nxes/jwt-secret` with value = randomly generated 256-bit key
2. Grant Lambda/ECS execution role `secretsmanager:GetSecretValue` on this secret
