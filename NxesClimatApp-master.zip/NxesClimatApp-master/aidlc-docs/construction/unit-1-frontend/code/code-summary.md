# Code Summary — Unit 1: Frontend React App

## Files Generated

| File | Purpose |
|---|---|
| `frontend/package.json` | Dependencies (React 18, Vite, Tailwind, Axios, React Router v6) |
| `frontend/tsconfig.json` | TypeScript strict config with path aliases |
| `frontend/vite.config.ts` | Vite + Vitest config |
| `frontend/tailwind.config.js` | Climate-tech colour palette (brand greens/blues, decision colours) |
| `frontend/index.html` | HTML entry point |
| `frontend/src/main.tsx` | React app entry |
| `frontend/src/App.tsx` | Router — all 6 screens + protected dashboard routes |
| `frontend/src/index.css` | Tailwind base styles |
| `frontend/src/types/index.ts` | Shared TypeScript types |
| `frontend/src/utils/storage.ts` | localStorage utility (centralised key names) |
| `frontend/src/services/api.ts` | Axios instance + JWT interceptor |
| `frontend/src/services/analysis.ts` | Analysis API calls + PDF download |
| `frontend/src/services/auth.ts` | Auth API calls |
| `frontend/src/services/projects.ts` | Projects API calls + full PDF download |
| `frontend/src/components/DecisionBadge.tsx` | Colour + text decision badge (WCAG 2.1 AA) |
| `frontend/src/components/ScoreBar.tsx` | Accessible progress bar |
| `frontend/src/components/LoadingSpinner.tsx` | Loading state |
| `frontend/src/components/ProtectedRoute.tsx` | JWT guard for dashboard routes |
| `frontend/src/pages/LandingPage/index.tsx` | Screen 1 — hero, CTAs, value strip |
| `frontend/src/pages/LandingPage/ExampleResultModal.tsx` | Sample result overlay |
| `frontend/src/pages/InputForm/index.tsx` | Screen 2 — 5-field form + explanation panel |
| `frontend/src/pages/InputForm/useInputForm.ts` | Form state, validation, file handling, submit |
| `frontend/src/pages/ProcessingScreen/index.tsx` | Screen 3 — animated steps + progress bar |
| `frontend/src/pages/ProcessingScreen/usePolling.ts` | Polling hook (5s interval, 120s timeout) |
| `frontend/src/pages/OutputScreen/index.tsx` | Screen 4 — decision card, metrics, PDF, CTA |
| `frontend/src/pages/SignupScreen/index.tsx` | Screen 5 — signup + session transfer |
| `frontend/src/pages/LoginScreen/index.tsx` | Login screen |
| `frontend/src/pages/Dashboard/index.tsx` | Dashboard shell + Outlet |
| `frontend/src/pages/Dashboard/Sidebar.tsx` | 5-item navigation sidebar |
| `frontend/src/pages/Dashboard/Overview.tsx` | First login — project status card + report links |
| `frontend/src/pages/Dashboard/ProjectsList.tsx` | All projects list |
| `frontend/src/pages/Dashboard/FullReportView.tsx` | Full report + module breakdown + PDF download |
| `frontend/src/pages/Dashboard/DecisionHistory.tsx` | Decision history sorted by date |
| Tests: LandingPage, DecisionBadge, storage | Unit tests |

## Stories Implemented
All EP-01 through EP-06 stories (22 user-facing stories).
