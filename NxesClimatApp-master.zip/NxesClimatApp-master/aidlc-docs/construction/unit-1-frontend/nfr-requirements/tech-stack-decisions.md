# Tech Stack Decisions — Unit 1: Frontend

| Decision | Choice | Rationale |
|---|---|---|
| Framework | React 18 + TypeScript | Specified in requirements; component model suits 6-screen SPA |
| Build tool | Vite | Fast HMR, optimised production builds, env var support via VITE_ prefix |
| Routing | React Router v6 | Industry standard, nested routes for dashboard |
| HTTP client | Axios | Interceptors for JWT header injection, consistent error handling |
| Styling | Tailwind CSS | Utility-first, no runtime overhead, easy climate-tech colour palette |
| PDF download | Browser fetch + Blob | Stream PDF from API, trigger download via anchor click |
| Testing | Vitest + React Testing Library | Vite-native test runner, component testing |
| State | React useState/useContext | Sufficient for pilot scale — no Redux needed |
| Icons | Lucide React | Lightweight, tree-shakeable, accessible SVG icons |
