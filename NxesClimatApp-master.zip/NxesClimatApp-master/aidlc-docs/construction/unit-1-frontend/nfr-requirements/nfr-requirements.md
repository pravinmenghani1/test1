# NFR Requirements — Unit 1: Frontend React App

## NFR-FE-01: Performance
- Landing page load < 2 seconds (Vite production build, CDN via Amplify)
- Route transitions < 200ms (client-side routing, no full page reloads)
- PDF download triggered immediately on click (streamed from API)

## NFR-FE-02: Accessibility (WCAG 2.1 AA)
- All colour-coded elements (GO/REVISE/NO-GO) must also use text labels
- All form inputs must have associated `<label>` elements
- Focus management: modal traps focus; closing modal returns focus to trigger
- Keyboard navigable: all interactive elements reachable via Tab
- Sufficient colour contrast: minimum 4.5:1 for normal text, 3:1 for large text
- ARIA roles on dynamic content (progress steps, loading states)

## NFR-FE-03: Usability
- User reaches first result within 2–3 minutes of landing
- No login required before seeing the decision result
- Progressive disclosure: show only what's needed per screen
- Single primary CTA per screen

## NFR-FE-04: Security
- JWT stored in localStorage (acceptable for pilot PoC)
- No sensitive data logged to console in production
- API base URL from environment variable — not hardcoded

## NFR-FE-05: Maintainability
- Feature-based folder structure (one folder per screen)
- Shared components in `components/` directory
- API client in `services/api.ts` — single place to update base URL or headers
- TypeScript strict mode — no `any` types

## NFR-FE-06: Testability
- All interactive elements have `data-testid` attributes
- Component logic separated from API calls (hooks pattern)
- Vitest for unit tests
