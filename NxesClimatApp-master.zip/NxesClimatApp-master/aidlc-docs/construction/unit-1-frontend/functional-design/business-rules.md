# Business Rules — Unit 1: Frontend

| Rule | Description |
|---|---|
| BR-FE-01 | No login required to access LandingPage, InputForm, ProcessingScreen, OutputScreen |
| BR-FE-02 | Dashboard and all sub-routes require a valid JWT in localStorage |
| BR-FE-03 | File upload max size: 5MB — show error if exceeded |
| BR-FE-04 | File upload accepted types: .pdf, .xlsx, .csv, .docx |
| BR-FE-05 | File stored as base64 in localStorage — NOT sent to backend |
| BR-FE-06 | session_id stored in localStorage after analysis submission |
| BR-FE-07 | JWT stored in localStorage after signup/login |
| BR-FE-08 | On signup: session_id passed to backend, then cleared from localStorage |
| BR-FE-09 | Polling interval: 5 seconds; timeout: 120 seconds |
| BR-FE-10 | Decision card must use both colour AND text label (WCAG 2.1 AA) |
| BR-FE-11 | All interactive elements must have data-testid attributes |
| BR-FE-12 | Form validation errors shown inline, not as alerts |
| BR-FE-13 | API base URL read from VITE_API_BASE_URL environment variable |
| BR-FE-14 | JWT sent as Bearer token in Authorization header on all protected requests |
