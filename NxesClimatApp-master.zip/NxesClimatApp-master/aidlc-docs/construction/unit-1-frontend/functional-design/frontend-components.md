# Frontend Components — Unit 1: Frontend React App

## Component Hierarchy

```
App (Router)
├── LandingPage
│   └── ExampleResultModal (overlay)
├── InputForm
├── ProcessingScreen
├── OutputScreen
├── SignupScreen
├── LoginScreen
└── Dashboard (protected)
    ├── Sidebar
    ├── Overview (default)
    ├── ProjectsList
    │   └── ProjectCard
    ├── FullReportView
    │   └── ModuleBreakdown
    └── DecisionHistory
```

---

## LandingPage

**Route**: `/`  
**Props**: none  
**State**: `showExample: boolean`

**User interactions**:
- Click "Try Decision Core" → navigate to `/try`
- Click "See example" → set `showExample = true` → render ExampleResultModal
- Click "Login" → navigate to `/login`

**API**: none

---

## ExampleResultModal

**Props**: `onClose: () => void`  
**State**: none (static sample data)

**Sample data** (hardcoded):
```ts
const SAMPLE = {
  decision: 'REVISE',
  score: 58,
  risk_level: 'Medium',
  key_issues: [
    'Revenue model needs clarification',
    'MRV framework requires additional documentation',
    'High dependency on external funding',
  ]
}
```

---

## InputForm

**Route**: `/try`  
**State**:
```ts
{
  project_type: string
  location: string
  description: string
  stage: string
  file: File | null
  errors: Record<string, string>
  submitting: boolean
}
```

**Validation** (client-side):
- `project_type`: required
- `location`: required
- `description`: required, max 500 chars
- `file`: optional, max 5MB, accept .pdf/.xlsx/.csv/.docx

**On submit**:
1. Validate form → show inline errors if invalid
2. If file: read as base64, store in localStorage key `nxes_file_ref`
3. POST `/api/v1/analyze` with form data
4. Store `session_id` in localStorage key `nxes_session_id`
5. Navigate to `/analyzing`

**data-testid attributes**:
- `input-form-project-type`
- `input-form-location`
- `input-form-description`
- `input-form-stage`
- `input-form-file-upload`
- `input-form-submit-button`

---

## ProcessingScreen

**Route**: `/analyzing`  
**State**:
```ts
{
  steps: string[]           // completed step names
  progress: number          // 0-100
  timedOut: boolean
}
```

**Steps** (animated sequentially):
1. "Checking MRV feasibility"
2. "Evaluating financial logic"
3. "Assessing risks"
4. "Validating additionality"

**Polling logic**:
- Read `session_id` from localStorage
- Poll `GET /api/v1/analyze/{session_id}` every 5 seconds
- Update `steps` from response `progress` array
- On `status === complete`: navigate to `/result` with result in state
- On `status === failed`: show error message
- After 120 seconds: set `timedOut = true`, show "Still working — almost there"

---

## OutputScreen

**Route**: `/result`  
**Props/State**: result from navigation state (or re-fetch from localStorage session_id)

**Decision card colours**:
- GO: `#2E7D32` (green)
- REVISE: `#F57F17` (amber)
- NO-GO: `#C62828` (red)

**Accessibility**: decision uses both colour AND text label (WCAG 2.1 AA)

**Actions**:
- "Download PDF" → GET `/api/v1/analyze/{session_id}/pdf` → trigger browser download
- "Create account to unlock full report" → navigate to `/signup`

**data-testid attributes**:
- `output-decision-card`
- `output-score`
- `output-risk-level`
- `output-key-issues-list`
- `output-download-pdf-button`
- `output-signup-cta-button`

---

## SignupScreen

**Route**: `/signup`  
**State**:
```ts
{
  email: string
  password: string
  errors: Record<string, string>
  submitting: boolean
}
```

**On submit**:
1. Validate email format + password min 8 chars
2. Read `session_id` from localStorage
3. POST `/api/v1/auth/signup` with `{ email, password, session_id }`
4. Store JWT in localStorage key `nxes_token`
5. Store `user_id` in localStorage key `nxes_user_id`
6. Clear `nxes_session_id` from localStorage
7. Navigate to `/dashboard`

**data-testid attributes**:
- `signup-form-email`
- `signup-form-password`
- `signup-form-submit-button`

---

## LoginScreen

**Route**: `/login`  
**State**: `{ email, password, error, submitting }`

**On submit**:
1. POST `/api/v1/auth/login`
2. Store JWT in localStorage
3. Navigate to `/dashboard`

**data-testid attributes**:
- `login-form-email`
- `login-form-password`
- `login-form-submit-button`

---

## Dashboard (protected route)

**Route**: `/dashboard/*`  
**Guard**: reads `nxes_token` from localStorage; redirects to `/login` if missing/expired

**Sub-routes**:
- `/dashboard` → Overview (project status card)
- `/dashboard/projects` → ProjectsList
- `/dashboard/projects/:id` → FullReportView
- `/dashboard/decisions` → DecisionHistory

---

## ProjectsList

**State**: `{ projects: Project[], loading: boolean }`  
**API**: GET `/api/v1/projects` (JWT header)

---

## FullReportView

**Route**: `/dashboard/projects/:id`  
**State**: `{ report: FullReport | null, loading: boolean }`  
**API**: GET `/api/v1/projects/:id/report` (JWT header)

**Actions**:
- "Download Full PDF" → GET `/api/v1/projects/:id/pdf`

---

## Shared Components

| Component | Purpose |
|---|---|
| `DecisionBadge` | Colour-coded GO/REVISE/NO-GO badge with text label |
| `ScoreBar` | Visual progress bar for score/readiness (0-100) |
| `LoadingSpinner` | Animated spinner for async states |
| `ErrorMessage` | Inline field error display |
| `ProtectedRoute` | HOC that checks JWT and redirects to login |
