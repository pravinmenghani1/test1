# Infrastructure Design — Unit 1: Frontend

## Deployment
React SPA built with Vite, deployed to AWS Amplify (provisioned by Unit 3 NxesFrontendStack).

## Build Output
```
frontend/dist/   ← Amplify serves this directory
```

## Environment Variables (Vite)
```
VITE_API_BASE_URL=<NxesApiStack.ApiGatewayUrl>
```
Set automatically by CDK NxesFrontendStack. For local dev, create `frontend/.env.local`:
```
VITE_API_BASE_URL=http://localhost:8000
```

## Local Development
```bash
cd frontend
npm install
npm run dev      # Vite dev server on http://localhost:5173
```

## Production Build
```bash
npm run build    # outputs to dist/
```

## Code Structure
```
frontend/
  src/
    pages/
      LandingPage/
        index.tsx
        ExampleResultModal.tsx
      InputForm/
        index.tsx
        useInputForm.ts
      ProcessingScreen/
        index.tsx
        usePolling.ts
      OutputScreen/
        index.tsx
      SignupScreen/
        index.tsx
      LoginScreen/
        index.tsx
      Dashboard/
        index.tsx
        Sidebar.tsx
        Overview.tsx
        ProjectsList.tsx
        FullReportView.tsx
        DecisionHistory.tsx
    components/
      DecisionBadge.tsx
      ScoreBar.tsx
      LoadingSpinner.tsx
      ErrorMessage.tsx
      ProtectedRoute.tsx
    services/
      api.ts           # Axios instance + interceptors
      analysis.ts      # Analysis API calls
      auth.ts          # Auth API calls
      projects.ts      # Projects API calls
    utils/
      storage.ts       # localStorage utility
      pdf.ts           # PDF download helper
    types/
      index.ts         # Shared TypeScript types
    App.tsx
    main.tsx
  public/
  index.html
  package.json
  tsconfig.json
  vite.config.ts
  tailwind.config.js
```
