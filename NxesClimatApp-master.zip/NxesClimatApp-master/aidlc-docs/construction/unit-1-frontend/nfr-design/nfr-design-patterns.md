# NFR Design Patterns — Unit 1: Frontend

## Pattern 1: Axios Interceptor for JWT
Single Axios instance with a request interceptor that reads the JWT from localStorage and injects the `Authorization: Bearer <token>` header on every request. No per-component auth logic.

## Pattern 2: ProtectedRoute Component
Wraps dashboard routes. Reads JWT from localStorage, verifies it's not expired (client-side check on `exp` claim), redirects to `/login` if invalid. Prevents unauthenticated access without a server round-trip.

## Pattern 3: usePolling Hook
Custom hook encapsulating the polling logic for ProcessingScreen. Handles interval setup, cleanup on unmount, timeout after 120 seconds, and navigation on completion. Keeps ProcessingScreen component clean.

## Pattern 4: Colour + Text for Accessibility
`DecisionBadge` component always renders both a coloured background AND a text label. Never relies on colour alone. Uses `aria-label` for screen readers.

## Pattern 5: Environment-Based API URL
`VITE_API_BASE_URL` injected at build time by Vite. Single `services/api.ts` file creates the Axios instance with this base URL. Changing the API URL requires only an environment variable change.

## Pattern 6: localStorage Utility Module
`utils/storage.ts` wraps all localStorage reads/writes. Centralises key names as constants. Makes it easy to clear all session data on logout or after session transfer.
