# NFR Requirements — Unit 2: Backend API + Decision Engine

## NFR-BE-01: Performance
- Analysis job must complete within 2 minutes (120 seconds)
- POST /analyze acknowledgement (job queued) must respond within 1 second
- GET /analyze/{id} polling response must return within 500ms
- All other API endpoints must respond within 2 seconds

## NFR-BE-02: Async Processing
- Analysis runs as a background task — never blocks the HTTP response
- FastAPI BackgroundTasks used for Lambda deployment (no external queue needed at pilot scale)
- Job status persisted in DynamoDB so polling works across Lambda invocations

## NFR-BE-03: Security
- All passwords hashed with bcrypt (cost factor 12) — never stored in plaintext
- JWT secret retrieved from Secrets Manager at cold start, cached in memory
- JWT tokens expire after 24 hours
- Protected endpoints validate JWT on every request via FastAPI dependency
- No sensitive data in logs (no passwords, no JWT tokens)
- Input validation on all endpoints via Pydantic models

## NFR-BE-04: Reliability
- Graceful error handling — all exceptions caught, user-friendly error messages returned
- DynamoDB operations wrapped in try/except — transient failures return 503 with retry hint
- If analysis job fails, job status set to "failed" with error message
- No unhandled exceptions reach the user

## NFR-BE-05: Maintainability
- Scoring weights read from environment variables — configurable without code changes
- Module logic in separate Python files — each module independently replaceable
- Pydantic models as single source of truth for request/response schemas
- Type hints throughout — no untyped functions

## NFR-BE-06: Testability
- All business logic (modules, scoring, decision) in pure functions — no side effects
- Repository layer injectable — can be mocked in tests
- pytest + httpx for API integration tests
- Each module independently unit-testable

## NFR-BE-07: Accessibility (API)
- All error responses include a human-readable `detail` field
- HTTP status codes used correctly (400 validation, 401 auth, 403 forbidden, 404 not found, 503 service unavailable)
- CORS headers set correctly for browser clients
