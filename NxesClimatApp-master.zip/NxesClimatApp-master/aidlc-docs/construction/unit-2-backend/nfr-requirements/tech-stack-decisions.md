# Tech Stack Decisions — Unit 2: Backend API + Decision Engine

| Decision | Choice | Rationale |
|---|---|---|
| Framework | FastAPI (Python 3.12) | Async-native, Pydantic built-in, auto OpenAPI docs, Mangum Lambda adapter |
| ASGI server | Uvicorn (local dev) / Mangum (Lambda) | Mangum wraps FastAPI for Lambda handler |
| Password hashing | passlib + bcrypt | Industry standard, configurable cost factor |
| JWT | python-jose | Lightweight, HS256 support, well-maintained |
| DynamoDB client | boto3 | AWS official SDK |
| PDF generation | reportlab | Pure Python, no system dependencies (Lambda-compatible) |
| Validation | Pydantic v2 | Built into FastAPI, fast, type-safe |
| Testing | pytest + httpx | httpx provides async test client for FastAPI |
| Secrets | boto3 secretsmanager | Retrieve JWT secret from Secrets Manager at cold start |
| Background tasks | FastAPI BackgroundTasks | Sufficient for pilot scale; no SQS/Celery needed |

## Python Dependencies (requirements.txt)
```
fastapi==0.110.0
uvicorn==0.27.1
mangum==0.17.0
pydantic==2.6.1
boto3==1.34.34
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
reportlab==4.1.0
httpx==0.26.0
pytest==8.0.0
pytest-asyncio==0.23.4
```
