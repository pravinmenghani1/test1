# Infrastructure Design — Unit 2: Backend API + Decision Engine

## Deployment Model
FastAPI application deployed as AWS Lambda function via Mangum adapter.
Lambda is provisioned by Unit 3 (NxesComputeStack) — Unit 2 provides the application code.

## Code Structure
```
backend/
  app/
    main.py              # FastAPI app + Mangum handler
    routers/
      analysis.py
      auth.py
      projects.py
    services/
      analysis_service.py
      auth_service.py
      project_service.py
      pdf_service.py
    modules/
      mrv_module.py
      financial_module.py
      risk_module.py
      additionality_module.py
    repositories/
      project_repository.py
      user_repository.py
    models/
      requests.py        # Pydantic request models
      responses.py       # Pydantic response models
    core/
      config.py          # Environment variable config
      dynamodb.py        # boto3 DynamoDB client singleton
      jwt_utils.py       # JWT create/verify + Secrets Manager cache
  tests/
    test_analysis.py
    test_auth.py
    test_modules.py
    test_repositories.py
  requirements.txt
  Dockerfile             # For local development with docker-compose
```

## Lambda Packaging
- CDK NxesComputeStack bundles backend/ using Docker + pip install
- All dependencies installed into Lambda deployment package
- reportlab and bcrypt are pure Python — no native binary issues

## Local Development
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Environment Variables (set by CDK NxesComputeStack)
```
DYNAMODB_TABLE_SESSIONS
DYNAMODB_TABLE_USERS
DYNAMODB_TABLE_PROJECTS
DYNAMODB_PROJECTS_GSI
JWT_ALGORITHM
JWT_EXPIRY_HOURS
MRV_WEIGHT / FINANCIAL_WEIGHT / RISK_WEIGHT / ADDITIONALITY_WEIGHT
SECRETS_MANAGER_JWT_SECRET_ARN
AWS_REGION
```

## Local .env (for development without Lambda)
```
DYNAMODB_TABLE_SESSIONS=nxes-sessions
DYNAMODB_TABLE_USERS=nxes-users
DYNAMODB_TABLE_PROJECTS=nxes-projects
DYNAMODB_PROJECTS_GSI=project_id-index
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=24
JWT_SECRET_KEY=dev-secret-key-change-in-production
MRV_WEIGHT=0.30
FINANCIAL_WEIGHT=0.25
RISK_WEIGHT=0.25
ADDITIONALITY_WEIGHT=0.20
AWS_REGION=us-east-1
USE_LOCAL_JWT_SECRET=true
```
