# Logical Components — Unit 2: Backend API + Decision Engine

## LC-BE-01: FastAPI Application (app/main.py)
Entry point. Registers routers, middleware, exception handlers. Mangum wraps it for Lambda.

## LC-BE-02: Analysis Router (app/routers/analysis.py)
- POST /api/v1/analyze — submit job
- GET /api/v1/analyze/{session_id} — poll status
- GET /api/v1/analyze/{session_id}/pdf — download pilot PDF

## LC-BE-03: Auth Router (app/routers/auth.py)
- POST /api/v1/auth/signup
- POST /api/v1/auth/login

## LC-BE-04: Project Router (app/routers/projects.py)
- GET /api/v1/projects
- GET /api/v1/projects/{project_id}
- GET /api/v1/projects/{project_id}/report
- GET /api/v1/projects/{project_id}/pdf

## LC-BE-05: Analysis Service (app/services/analysis_service.py)
Orchestrates 4 modules, computes score, applies decision, generates key issues, persists result.

## LC-BE-06: Auth Service (app/services/auth_service.py)
Signup, login, JWT issuance, JWT verification dependency.

## LC-BE-07: Project Service (app/services/project_service.py)
Project retrieval, full report assembly, ownership enforcement.

## LC-BE-08: PDF Service (app/services/pdf_service.py)
Pilot PDF and full report PDF generation using reportlab.

## LC-BE-09: MRV Module (app/modules/mrv_module.py)
Pure function: score(project_type, location) → ModuleScore

## LC-BE-10: Financial Module (app/modules/financial_module.py)
Pure function: score(project_type, stage) → ModuleScore

## LC-BE-11: Risk Module (app/modules/risk_module.py)
Pure function: score(location, stage) → ModuleScore (includes risk_level)

## LC-BE-12: Additionality Module (app/modules/additionality_module.py)
Pure function: score(project_type) → ModuleScore

## LC-BE-13: Project Repository (app/repositories/project_repository.py)
DynamoDB CRUD for sessions, jobs, projects.

## LC-BE-14: User Repository (app/repositories/user_repository.py)
DynamoDB CRUD for users.

## LC-BE-15: Config (app/core/config.py)
Reads all environment variables. Single source of truth for configuration.

## LC-BE-16: DynamoDB Client (app/core/dynamodb.py)
Singleton boto3 DynamoDB resource. Shared across repositories.

## LC-BE-17: JWT Utilities (app/core/jwt_utils.py)
create_token, verify_token, get_jwt_secret (with Secrets Manager cold-start cache).
