# NFR Design Patterns — Unit 2: Backend API + Decision Engine

## Pattern 1: FastAPI BackgroundTasks for Async Analysis
Analysis jobs run as FastAPI BackgroundTasks — the HTTP response returns immediately with session_id, and the analysis runs after the response is sent. Job status is persisted in DynamoDB so polling works correctly even across Lambda cold starts.

## Pattern 2: JWT Dependency Injection
A reusable FastAPI dependency `get_current_user` validates the JWT on every protected endpoint. Injected via `Depends(get_current_user)` — no boilerplate per endpoint.

```python
async def get_current_user(token: str = Depends(oauth2_scheme)) -> UserClaims:
    # Verify JWT, return claims or raise 401
```

## Pattern 3: Repository Pattern for DynamoDB
All DynamoDB access goes through repository classes (ProjectRepository, UserRepository). This decouples business logic from persistence and makes unit testing straightforward — repositories can be mocked.

## Pattern 4: Pure Function Modules
Each scoring module (MRV, Financial, Risk, Additionality) is a pure function — same inputs always produce same outputs, no side effects. This makes them trivially unit-testable and independently replaceable.

## Pattern 5: Secrets Manager Cold-Start Cache
JWT secret is fetched from Secrets Manager once at Lambda cold start and cached as a module-level variable. Subsequent invocations reuse the cached value — no per-request Secrets Manager calls.

```python
_jwt_secret: Optional[str] = None

def get_jwt_secret() -> str:
    global _jwt_secret
    if _jwt_secret is None:
        _jwt_secret = fetch_from_secrets_manager()
    return _jwt_secret
```

## Pattern 6: Pydantic Validation as First Line of Defence
All request bodies are Pydantic models. FastAPI automatically returns 422 Unprocessable Entity with field-level error details if validation fails — no manual validation code needed.

## Pattern 7: Graceful Error Handler
A global exception handler catches unhandled exceptions and returns a 500 with a safe error message (no stack traces to clients).

```python
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(status_code=500, content={"detail": "An unexpected error occurred"})
```
