# Code Summary — Unit 2: Backend API + Decision Engine

## Files Generated

| File | Purpose |
|---|---|
| `backend/requirements.txt` | Python dependencies |
| `backend/.env.example` | Local development environment template |
| `backend/app/main.py` | FastAPI app + Mangum Lambda handler + CORS + global error handler |
| `backend/app/core/config.py` | All environment variable config (single source of truth) |
| `backend/app/core/dynamodb.py` | boto3 DynamoDB singleton |
| `backend/app/core/jwt_utils.py` | JWT create/verify + Secrets Manager cold-start cache |
| `backend/app/models/requests.py` | Pydantic request models with validation |
| `backend/app/models/responses.py` | Pydantic response models |
| `backend/app/modules/mrv_module.py` | MRV scoring (pure function) |
| `backend/app/modules/financial_module.py` | Financial scoring (pure function) |
| `backend/app/modules/risk_module.py` | Risk scoring (pure function) |
| `backend/app/modules/additionality_module.py` | Additionality scoring (pure function) |
| `backend/app/services/analysis_service.py` | Orchestration + weighted scoring + decision logic |
| `backend/app/services/auth_service.py` | Signup, login, JWT dependency |
| `backend/app/services/project_service.py` | Project retrieval + full report assembly + benchmarks |
| `backend/app/services/pdf_service.py` | Pilot PDF + full report PDF (reportlab) |
| `backend/app/repositories/project_repository.py` | DynamoDB CRUD for sessions, jobs, projects |
| `backend/app/repositories/user_repository.py` | DynamoDB CRUD for users |
| `backend/app/routers/analysis.py` | POST /analyze, GET /analyze/{id}, GET /analyze/{id}/pdf |
| `backend/app/routers/auth.py` | POST /auth/signup, POST /auth/login |
| `backend/app/routers/projects.py` | GET /projects, GET /projects/{id}, /report, /pdf |
| `backend/tests/test_modules.py` | Unit tests for all 4 modules + scoring engine |

## Stories Implemented
- US-07.1: Weighted average composite score (AnalysisService._compute_score)
- US-07.2: Decision thresholds GO/REVISE/NO-GO (AnalysisService._apply_decision)
- US-07.3: Structured JSON response (AnalysisResult model + analysis router)
- API layer for all EP-01–EP-06 stories (auth, projects, analysis endpoints)
