# Business Rules — Unit 2: Backend API + Decision Engine

## Scoring Rules

| Rule | Description |
|---|---|
| BR-BE-01 | Composite score = (MRV × 0.30) + (Financial × 0.25) + (Risk × 0.25) + (Additionality × 0.20) |
| BR-BE-02 | All module scores must be normalised to 0–100 before weighting |
| BR-BE-03 | Composite score is rounded to nearest integer |
| BR-BE-04 | Score > 70 → decision = GO |
| BR-BE-05 | Score 40–70 (inclusive) → decision = REVISE |
| BR-BE-06 | Score < 40 → decision = NO-GO |
| BR-BE-07 | Boundary: score exactly 70 → REVISE; score exactly 40 → REVISE |
| BR-BE-08 | Scoring weights are read from environment variables at startup — not hardcoded |

## MRV Module Rules

| Rule | Description |
|---|---|
| BR-MRV-01 | Forestry/REDD+ + Africa/Asia → MRV score 60 (established frameworks exist) |
| BR-MRV-02 | Renewable Energy (any location) → MRV score 75 (well-defined measurement protocols) |
| BR-MRV-03 | Cookstoves + developing country → MRV score 55 (Gold Standard applicable) |
| BR-MRV-04 | Waste-to-Energy → MRV score 65 |
| BR-MRV-05 | Blue Carbon → MRV score 50 (emerging methodology) |
| BR-MRV-06 | Agriculture → MRV score 45 (complex, variable baselines) |
| BR-MRV-07 | Unknown/unrecognised project type → MRV score 40 |

## Financial Module Rules

| Rule | Description |
|---|---|
| BR-FIN-01 | Stage = Scaling → financial score +20 bonus (revenue model more proven) |
| BR-FIN-02 | Stage = Pilot → financial score base |
| BR-FIN-03 | Stage = Idea → financial score -15 penalty (unproven viability) |
| BR-FIN-04 | Renewable Energy → base financial score 70 |
| BR-FIN-05 | Forestry/REDD+ → base financial score 65 |
| BR-FIN-06 | Cookstoves → base financial score 60 |
| BR-FIN-07 | Waste-to-Energy → base financial score 65 |
| BR-FIN-08 | Blue Carbon → base financial score 55 |
| BR-FIN-09 | Agriculture → base financial score 50 |
| BR-FIN-10 | Final financial score capped at 100, floored at 0 |

## Risk Module Rules

| Rule | Description |
|---|---|
| BR-RISK-01 | High-risk locations (conflict zones, politically unstable): risk score 30, risk_level = High |
| BR-RISK-02 | Medium-risk locations (developing countries, moderate stability): risk score 55, risk_level = Medium |
| BR-RISK-03 | Low-risk locations (stable governance, strong institutions): risk score 80, risk_level = Low |
| BR-RISK-04 | Stage = Idea → risk score -10 (higher uncertainty) |
| BR-RISK-05 | Stage = Scaling → risk score +10 (lower uncertainty) |
| BR-RISK-06 | Risk level derived from final risk score: >70=Low, 40-70=Medium, <40=High |

## Additionality Module Rules

| Rule | Description |
|---|---|
| BR-ADD-01 | Forestry/REDD+ → additionality score 70 (well-established additionality criteria) |
| BR-ADD-02 | Renewable Energy in grid-connected region → additionality score 55 (grid baseline required) |
| BR-ADD-03 | Cookstoves → additionality score 75 (clear counterfactual: traditional cooking) |
| BR-ADD-04 | Waste-to-Energy → additionality score 65 |
| BR-ADD-05 | Blue Carbon → additionality score 60 |
| BR-ADD-06 | Agriculture → additionality score 50 (complex counterfactual) |

## Authentication Rules

| Rule | Description |
|---|---|
| BR-AUTH-01 | Passwords must be hashed with bcrypt (cost factor 12) before storage |
| BR-AUTH-02 | JWT tokens expire after 24 hours |
| BR-AUTH-03 | JWT secret retrieved from Secrets Manager at Lambda cold start, cached in memory |
| BR-AUTH-04 | Login failure must return generic error ("Invalid credentials") — no email enumeration |
| BR-AUTH-05 | Email must be validated as valid email format before signup |

## Data Transfer Rules

| Rule | Description |
|---|---|
| BR-XFER-01 | On signup with session_id: copy AnonymousSession record to Project record under new user_id |
| BR-XFER-02 | session_id in signup request is optional — signup works without it |
| BR-XFER-03 | After transfer, the AnonymousSession record is NOT deleted (TTL handles cleanup) |
| BR-XFER-04 | If session_id does not exist in DynamoDB (expired TTL), signup proceeds without transfer |

## Key Issues Generation Rules

| Rule | Description |
|---|---|
| BR-ISSUES-01 | Generate 3–5 key issues from module outputs |
| BR-ISSUES-02 | Prioritise issues from lowest-scoring modules first |
| BR-ISSUES-03 | Each issue is a plain-English sentence (no jargon) |
| BR-ISSUES-04 | For GO decisions, issues are framed as strengths ("Strong MRV framework") |
| BR-ISSUES-05 | For REVISE/NO-GO, issues are framed as gaps ("Revenue model needs clarification") |
