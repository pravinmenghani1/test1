# Domain Entities — Unit 2: Backend API + Decision Engine

## Pydantic Models (request/response)

### ProjectInput
```python
class ProjectInput(BaseModel):
    project_type: str          # One of 6 types
    location: str              # Country name
    description: str           # Max 500 chars
    stage: Optional[str]       # Idea / Pilot / Scaling
    file_reference: Optional[str]  # base64 metadata from localStorage
```

### AnalysisJobResponse (returned immediately on POST /analyze)
```python
class AnalysisJobResponse(BaseModel):
    session_id: str
    status: str  # "queued"
```

### JobStatusResponse (returned on GET /analyze/{session_id})
```python
class JobStatusResponse(BaseModel):
    session_id: str
    status: str  # queued / processing / complete / failed
    progress: Optional[List[str]]  # completed step names for animation
    result: Optional[AnalysisResult]  # populated when status == complete
```

### AnalysisResult
```python
class AnalysisResult(BaseModel):
    session_id: str
    decision: str       # GO / REVISE / NO-GO
    score: int          # 0-100
    risk_level: str     # Low / Medium / High
    readiness: int      # 0-100
    key_issues: List[str]  # 3-5 items
    module_scores: ModuleScores
```

### ModuleScores
```python
class ModuleScores(BaseModel):
    mrv: int            # 0-100
    financial: int      # 0-100
    risk: int           # 0-100
    additionality: int  # 0-100
```

### AuthRequest
```python
class SignupRequest(BaseModel):
    email: str
    password: str
    session_id: Optional[str]  # anonymous session to transfer

class LoginRequest(BaseModel):
    email: str
    password: str

class AuthResponse(BaseModel):
    token: str
    user_id: str
```

### Project (full record from DynamoDB)
```python
class Project(BaseModel):
    project_id: str
    project_type: str
    location: str
    description: str
    stage: Optional[str]
    decision: str
    score: int
    risk_level: str
    readiness: int
    key_issues: List[str]
    module_scores: ModuleScores
    created_at: str
```

### FullReport
```python
class ModuleDetail(BaseModel):
    score: int
    issues: List[str]
    recommendations: List[str]
    benchmark_score: Optional[int]  # average for similar projects

class FullReport(BaseModel):
    project_id: str
    decision: str
    score: int
    risk_level: str
    readiness: int
    key_issues: List[str]
    modules: Dict[str, ModuleDetail]  # mrv, financial, risk, additionality
    benchmark_summary: str
```
