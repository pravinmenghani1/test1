# Business Logic Model — Unit 2: Backend API + Decision Engine

## Analysis Flow

```
POST /api/v1/analyze
  1. Validate ProjectInput (required fields)
  2. Generate session_id (UUID)
  3. Create AnalysisJob record in DynamoDB (status=queued, TTL=24h)
  4. Return { session_id, status: "queued" } immediately
  5. Enqueue background task (asyncio background task or Lambda async invoke)

Background Task:
  1. Update job status → processing
  2. Update progress → ["Checking MRV feasibility"]
  3. Run MRVModule.score(project_type, location) → mrv_score
  4. Update progress → ["Checking MRV feasibility", "Evaluating financial logic"]
  5. Run FinancialModule.score(project_type, stage) → financial_score
  6. Update progress → [..., "Assessing risks"]
  7. Run RiskModule.score(location, stage) → risk_score, risk_level
  8. Update progress → [..., "Validating additionality"]
  9. Run AdditionalityModule.score(project_type) → additionality_score
  10. Compute composite = (mrv×0.30) + (financial×0.25) + (risk×0.25) + (additionality×0.20)
  11. Round to integer
  12. Apply decision thresholds → decision
  13. Generate key_issues (3-5 plain-English strings)
  14. Compute readiness (same as composite score, 0-100)
  15. Save AnalysisResult to AnonymousSession record in DynamoDB
  16. Update AnalysisJob status → complete
```

## Polling Flow

```
GET /api/v1/analyze/{session_id}
  1. Fetch AnalysisJob record from DynamoDB (PK: JOB#{session_id})
  2. If not found → 404
  3. If status == queued/processing → return { status, progress }
  4. If status == complete → fetch AnonymousSession, return { status, result }
  5. If status == failed → return { status, error_message }
```

## Auth Flow — Signup

```
POST /api/v1/auth/signup
  1. Validate email format
  2. Check email not already registered (UserRepository.get_user_by_email)
  3. Hash password (bcrypt, cost=12)
  4. Generate user_id (UUID)
  5. Save User record (UserRepository.create_user)
  6. If session_id provided:
     a. Fetch AnonymousSession from DynamoDB
     b. If found: create Project record under USER#{user_id}
     c. If not found (expired): skip transfer silently
  7. Issue JWT (user_id, email, exp=now+24h)
  8. Return { token, user_id }
```

## Auth Flow — Login

```
POST /api/v1/auth/login
  1. Fetch user by email (UserRepository.get_user_by_email)
  2. If not found → 401 "Invalid credentials" (no email enumeration)
  3. Verify password hash (bcrypt.verify)
  4. If mismatch → 401 "Invalid credentials"
  5. Issue JWT
  6. Return { token, user_id }
```

## Project Retrieval Flow

```
GET /api/v1/projects (JWT required)
  1. Extract user_id from JWT claims
  2. Query DynamoDB: PK=USER#{user_id}, SK begins_with PROJECT#
  3. Return list of Project objects

GET /api/v1/projects/{project_id}/report (JWT required)
  1. Extract user_id from JWT claims
  2. Fetch project via GSI (project_id-index)
  3. Verify project.user_id == JWT user_id (ownership check)
  4. Assemble FullReport: add module recommendations + benchmark data
  5. Return FullReport
```

## PDF Generation Flow

```
GET /api/v1/analyze/{session_id}/pdf (no auth — pilot PDF)
  1. Fetch AnonymousSession result
  2. Generate 1-page PDF: decision, score, risk, key_issues, next_step
  3. Return as application/pdf stream

GET /api/v1/projects/{project_id}/pdf (JWT required — full report PDF)
  1. Fetch FullReport (same as report endpoint)
  2. Generate multi-page PDF: cover, module breakdowns, benchmarks, recommendations
  3. Return as application/pdf stream
```
