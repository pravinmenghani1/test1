# Unit Test Execution Instructions
# NxES Decision Core Pilot App

---

## Unit 2: Backend — Python Unit Tests

### Run all unit tests

```bash
cd backend
.venv\Scripts\activate   # Windows
pytest tests/ -v
```

### Expected results

```
tests/test_modules.py::test_mrv_renewable_energy_scores_high PASSED
tests/test_modules.py::test_mrv_agriculture_scores_lower PASSED
tests/test_modules.py::test_mrv_returns_issues PASSED
tests/test_modules.py::test_mrv_high_risk_location_reduces_score PASSED
tests/test_modules.py::test_financial_scaling_stage_bonus PASSED
tests/test_modules.py::test_financial_score_capped_at_100 PASSED
tests/test_modules.py::test_financial_score_floored_at_0 PASSED
tests/test_modules.py::test_financial_none_stage_uses_pilot_default PASSED
tests/test_modules.py::test_risk_high_risk_country PASSED
tests/test_modules.py::test_risk_low_risk_country PASSED
tests/test_modules.py::test_risk_scaling_improves_score PASSED
tests/test_modules.py::test_additionality_cookstoves_highest PASSED
tests/test_modules.py::test_additionality_agriculture_lowest PASSED
tests/test_modules.py::test_additionality_returns_status PASSED
tests/test_modules.py::test_compute_score_weighted_average PASSED
tests/test_modules.py::test_decision_go PASSED
tests/test_modules.py::test_decision_revise PASSED
tests/test_modules.py::test_decision_no_go PASSED

18 passed in X.XXs
```

### Run with coverage

```bash
pip install pytest-cov
pytest tests/ --cov=app --cov-report=term-missing
```

Target coverage: >80% on `app/modules/` and `app/services/analysis_service.py`

---

## Unit 1: Frontend — Vitest Unit Tests

### Run all unit tests (single pass)

```bash
cd frontend
npm run test
```

### Expected results

```
✓ src/utils/storage.test.ts (4 tests)
✓ src/components/DecisionBadge.test.tsx (4 tests)
✓ src/pages/LandingPage/LandingPage.test.tsx (4 tests)

Test Files  3 passed (3)
Tests       12 passed (12)
```

### Run with coverage

```bash
npx vitest run --coverage
```

---

## Unit 3: Infrastructure — CDK Synth Validation

CDK synth acts as a build-time test — it validates all stack definitions without deploying:

```bash
cd infrastructure
npx cdk synth
```

Expected: All 4 stacks synthesise without errors. CloudFormation templates written to `cdk.out/`.

---

## Fixing Failing Tests

### Backend test failures

1. Check the error message — most failures are in module scoring logic
2. Review `app/modules/` files against business rules in `aidlc-docs/construction/unit-2-backend/functional-design/business-rules.md`
3. Fix the module, rerun `pytest tests/test_modules.py -v`

### Frontend test failures

1. Check the error — most failures are component rendering or navigation mocks
2. Ensure `vi.mock('react-router-dom', ...)` is correct in test files
3. Fix the component, rerun `npm run test`
