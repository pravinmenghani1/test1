# Integration Test Instructions
# NxES Decision Core Pilot App

Integration tests verify the full pilot flow across all three units working together.

## Prerequisites

- Unit 3 deployed (DynamoDB tables exist, API Gateway URL available)
- Unit 2 running locally or deployed to Lambda
- Unit 1 running locally or deployed to Amplify
- `VITE_API_BASE_URL` pointing to the backend

---

## Scenario 1: Full Pilot Flow (Anonymous → Decision)

**Tests**: US-02.1, US-03.1, US-03.2, US-04.1, US-04.2

### Steps

```bash
# 1. Submit analysis
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "project_type": "Renewable Energy",
    "location": "Kenya",
    "description": "Solar farm providing clean energy to rural communities",
    "stage": "Pilot"
  }'
# Expected: {"session_id": "<uuid>", "status": "queued"}

# 2. Poll until complete (repeat every 5s)
SESSION_ID=<uuid from step 1>
curl http://localhost:8000/api/v1/analyze/$SESSION_ID
# Expected eventually: {"status": "complete", "result": {...}}

# 3. Verify result structure
# Expected result fields: decision, score, risk_level, readiness, key_issues, module_scores
# Expected decision for Renewable Energy + Kenya + Pilot: REVISE or GO
```

### Expected result

- `decision`: GO, REVISE, or NO-GO (based on scoring rules)
- `score`: integer 0–100
- `risk_level`: Low, Medium, or High
- `key_issues`: array of 3–5 strings
- `module_scores.mrv`, `.financial`, `.risk`, `.additionality`: integers 0–100

---

## Scenario 2: Signup and Session Transfer

**Tests**: US-05.1, US-05.2

```bash
# 1. Run analysis first (get session_id from Scenario 1)
SESSION_ID=<uuid>

# 2. Sign up with session_id
curl -X POST http://localhost:8000/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d "{\"email\": \"test@example.com\", \"password\": \"testpass123\", \"session_id\": \"$SESSION_ID\"}"
# Expected: {"token": "<jwt>", "user_id": "<uuid>"}

# 3. Verify project was transferred
TOKEN=<jwt from step 2>
curl http://localhost:8000/api/v1/projects \
  -H "Authorization: Bearer $TOKEN"
# Expected: {"projects": [{"project_id": "...", "decision": "...", ...}]}
```

---

## Scenario 3: Login and Full Report

**Tests**: US-05.3, US-06.2

```bash
# 1. Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com", "password": "testpass123"}'
# Expected: {"token": "<jwt>", "user_id": "<uuid>"}

# 2. Get full report
TOKEN=<jwt>
PROJECT_ID=<project_id from Scenario 2>
curl http://localhost:8000/api/v1/projects/$PROJECT_ID/report \
  -H "Authorization: Bearer $TOKEN"
# Expected: FullReport with modules, benchmark_summary
```

---

## Scenario 4: PDF Downloads

**Tests**: US-04.3, US-06.3

```bash
# Pilot PDF (no auth)
curl http://localhost:8000/api/v1/analyze/$SESSION_ID/pdf \
  --output pilot-report.pdf
# Expected: PDF file downloaded, non-zero size

# Full report PDF (auth required)
curl http://localhost:8000/api/v1/projects/$PROJECT_ID/pdf \
  -H "Authorization: Bearer $TOKEN" \
  --output full-report.pdf
# Expected: PDF file downloaded, non-zero size
```

---

## Scenario 5: Auth Error Handling

```bash
# Invalid credentials — must not leak email existence
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "nonexistent@example.com", "password": "wrong"}'
# Expected: 401 {"detail": "Invalid credentials"}

# Duplicate signup
curl -X POST http://localhost:8000/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com", "password": "testpass123"}'
# Expected: 409 {"detail": "An account with this email already exists"}
```

---

## Scenario 6: Protected Route Enforcement

```bash
# Access projects without token
curl http://localhost:8000/api/v1/projects
# Expected: 403 or 401

# Access another user's project
# Expected: 403 {"detail": "Access denied"}
```

---

## DynamoDB Verification

After running scenarios 1–3, verify data in DynamoDB:

```bash
# Check anonymous session was created
aws dynamodb get-item \
  --table-name nxes-sessions \
  --key '{"PK": {"S": "SESSION#<session_id>"}}'

# Check job record
aws dynamodb get-item \
  --table-name nxes-sessions \
  --key '{"PK": {"S": "JOB#<session_id>"}}'

# Check user was created
aws dynamodb get-item \
  --table-name nxes-users \
  --key '{"PK": {"S": "USER#test@example.com"}}'

# Check project was transferred
aws dynamodb query \
  --table-name nxes-projects \
  --key-condition-expression "PK = :pk" \
  --expression-attribute-values '{":pk": {"S": "USER#<user_id>"}}'
```

---

## Cleanup After Integration Tests

```bash
# Delete test user (DynamoDB)
aws dynamodb delete-item \
  --table-name nxes-users \
  --key '{"PK": {"S": "USER#test@example.com"}}'

# Delete test projects
aws dynamodb delete-item \
  --table-name nxes-projects \
  --key '{"PK": {"S": "USER#<user_id>"}, "SK": {"S": "PROJECT#<project_id>"}}'
```
