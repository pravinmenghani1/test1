# Performance Test Instructions
# NxES Decision Core Pilot App

## Performance Requirements (from NFR-01)

| Metric | Target |
|---|---|
| Analysis result delivery | < 2 minutes (120 seconds) |
| POST /analyze acknowledgement | < 1 second |
| All other API endpoints | < 2 seconds |
| Landing page load | < 2 seconds |

## Scope

At pilot scale (<50 users, internal testing), formal load testing is not required. The following manual checks are sufficient to validate performance targets.

---

## Manual Performance Checks

### Check 1: Analysis Job Latency

```bash
# Time the full analysis cycle
time curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{"project_type": "Forestry/REDD+", "location": "Brazil", "description": "Test", "stage": "Pilot"}'
# Expected: response in < 1 second (job queued acknowledgement)

# Then poll until complete and measure total time
# Expected: complete status within 120 seconds
```

### Check 2: API Response Times

```bash
# Measure each endpoint
curl -w "\nTime: %{time_total}s\n" http://localhost:8000/health
# Expected: < 0.5s

curl -w "\nTime: %{time_total}s\n" \
  -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/projects
# Expected: < 2s
```

### Check 3: Frontend Load Time

Open Chrome DevTools → Network tab → Hard reload `http://localhost:5173`
- Expected: First Contentful Paint < 2 seconds on a standard connection

---

## Future Load Testing (When Scaling Beyond Pilot)

When the app moves beyond internal testing, use k6 for load testing:

```bash
# Install k6: https://k6.io/docs/getting-started/installation/

# Basic load test script (save as load-test.js)
cat > load-test.js << 'EOF'
import http from 'k6/http'
import { check, sleep } from 'k6'

export const options = {
  vus: 10,          // 10 virtual users
  duration: '30s',  // 30 second test
}

export default function () {
  const res = http.post(
    `${__ENV.API_URL}/api/v1/analyze`,
    JSON.stringify({
      project_type: 'Renewable Energy',
      location: 'Kenya',
      description: 'Load test project',
      stage: 'Pilot',
    }),
    { headers: { 'Content-Type': 'application/json' } }
  )
  check(res, {
    'status is 202': r => r.status === 202,
    'response time < 1000ms': r => r.timings.duration < 1000,
  })
  sleep(1)
}
EOF

k6 run -e API_URL=http://localhost:8000 load-test.js
```

**Expected results at pilot scale**: p95 response time < 1000ms, 0% error rate.

---

## Lambda Cold Start Mitigation

Lambda cold starts can add 1–3 seconds to the first request after a period of inactivity. For the pilot:
- This is acceptable — users see the loading animation
- If cold starts become a problem, enable Lambda Provisioned Concurrency in `NxesComputeStack`
