# Build Instructions
# NxES Decision Core Pilot App

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Node.js | 18+ | For infrastructure CDK and frontend |
| Python | 3.12 | For backend |
| Docker | Latest | For Lambda bundling during CDK deploy |
| AWS CLI | v2 | Configured with deployment credentials |
| AWS CDK CLI | 2.x | `npm install -g aws-cdk` |

---

## Unit 3: Infrastructure

```bash
cd infrastructure
npm install
```

Bootstrap CDK (first time only):
```bash
npx cdk bootstrap aws://YOUR_ACCOUNT_ID/us-east-1
```

Synthesise (validate stacks without deploying):
```bash
npx cdk synth
```

Deploy all stacks:
```bash
npx cdk deploy --all
```

**Expected output**: 4 stacks deployed successfully. Note these outputs:
- `NxesDatabaseStack.SessionsTableName` → `nxes-sessions`
- `NxesDatabaseStack.UsersTableName` → `nxes-users`
- `NxesDatabaseStack.ProjectsTableName` → `nxes-projects`
- `NxesApiStack.ApiGatewayUrl` → `https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com`
- `NxesComputeStack.JwtSecretArn` → `arn:aws:secretsmanager:...`

---

## Unit 2: Backend

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # macOS/Linux
pip install -r requirements.txt
```

Copy and configure local environment:
```bash
copy .env.example .env
# Edit .env: set USE_LOCAL_JWT_SECRET=true, JWT_SECRET_KEY=any-dev-secret
```

Run locally:
```bash
uvicorn app.main:app --reload --port 8000
```

**Expected output**: `Uvicorn running on http://127.0.0.1:8000`

Verify health endpoint:
```bash
curl http://localhost:8000/health
# Expected: {"status":"ok"}
```

---

## Unit 1: Frontend

```bash
cd frontend
npm install
```

Configure local environment:
```bash
# Create frontend/.env.local
echo VITE_API_BASE_URL=http://localhost:8000 > .env.local
```

Run locally:
```bash
npm run dev
# Vite dev server starts on http://localhost:5173
```

Production build:
```bash
npm run build
# Output in frontend/dist/
```

**Expected output**: `dist/index.html` and hashed JS/CSS bundles.

---

## Full Stack Local Development

Run all three in separate terminals:

```
Terminal 1: cd backend && uvicorn app.main:app --reload --port 8000
Terminal 2: cd frontend && npm run dev
```

Then open http://localhost:5173 in your browser.

---

## Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| CDK bootstrap fails | Missing AWS credentials | Run `aws configure` |
| Lambda bundling fails | Docker not running | Start Docker Desktop |
| `pip install` fails on bcrypt | Missing build tools | Install Visual C++ Build Tools (Windows) |
| Frontend CORS error | API URL mismatch | Check `VITE_API_BASE_URL` in `.env.local` |
| DynamoDB connection refused | Wrong region or credentials | Check `AWS_REGION` and `aws configure` |
