# Operations Phase — Placeholder
# NxES Decision Core Pilot App

**Status**: Placeholder — future expansion

The Operations phase will cover deployment execution, monitoring, and ongoing operations. For now, all deployment guidance is in the Build and Test phase.

## Deployment Readiness Checklist

Before going live, complete these steps manually:

### AWS Setup
- [ ] AWS account configured with appropriate IAM permissions
- [ ] `aws configure` completed with deployment credentials
- [ ] CDK bootstrapped: `npx cdk bootstrap aws://ACCOUNT/us-east-1`

### Infrastructure Deployment
- [ ] `cd infrastructure && npx cdk deploy --all`
- [ ] Stack outputs noted (API URL, table names, secret ARN)
- [ ] DynamoDB tables verified in AWS Console
- [ ] API Gateway endpoint accessible

### Backend Deployment
- [ ] Lambda function deployed (handled by CDK compute stack)
- [ ] Health check passing: `curl <API_URL>/health`
- [ ] JWT secret created in Secrets Manager

### Frontend Deployment
- [ ] Amplify app connected to git repository
- [ ] `VITE_API_BASE_URL` environment variable set in Amplify console
- [ ] First build triggered and successful
- [ ] App accessible at Amplify URL

### Post-Deployment Validation
- [ ] Run integration test Scenario 1 (full pilot flow) against production
- [ ] Verify PDF download works
- [ ] Verify signup and session transfer works
- [ ] Verify dashboard loads after signup

### CORS Update
- [ ] Update `allowOrigins` in `NxesApiStack` from `['*']` to the actual Amplify URL
- [ ] Redeploy: `npx cdk deploy NxesApiStack`

## Future Operations Topics
- CloudWatch dashboards and alarms
- DynamoDB backup verification
- Lambda error rate monitoring
- Amplify custom domain setup
- Incident response runbook
