# NxES Decision Core — Infrastructure

AWS CDK v2 (TypeScript) infrastructure for the NxES Decision Core Pilot App.

## Stacks

| Stack | Resources | Deploy Order |
|---|---|---|
| NxesDatabaseStack | DynamoDB: nxes-sessions, nxes-users, nxes-projects | 1st |
| NxesComputeStack | Lambda (Python 3.12), IAM Role, Secrets Manager | 2nd |
| NxesApiStack | API Gateway HTTP API | 3rd |
| NxesFrontendStack | AWS Amplify | 4th |

## Prerequisites

- Node.js 18+
- AWS CLI configured (`aws configure`)
- AWS CDK CLI: `npm install -g aws-cdk`
- Docker (for Lambda bundling)

## Setup

```bash
cd infrastructure
npm install
```

## Bootstrap (first time only)

```bash
npx cdk bootstrap aws://YOUR_ACCOUNT_ID/us-east-1
```

## Deploy

```bash
# Deploy all stacks in order
npx cdk deploy --all

# Or deploy individually
npx cdk deploy NxesDatabaseStack
npx cdk deploy NxesComputeStack
npx cdk deploy NxesApiStack
npx cdk deploy NxesFrontendStack
```

## Stack Outputs

After deployment, note these outputs for Unit 2 (backend) and Unit 1 (frontend) setup:

| Output | Used By | Purpose |
|---|---|---|
| `NxesDatabaseStack.SessionsTableName` | Unit 2 env vars | DynamoDB table name |
| `NxesDatabaseStack.UsersTableName` | Unit 2 env vars | DynamoDB table name |
| `NxesDatabaseStack.ProjectsTableName` | Unit 2 env vars | DynamoDB table name |
| `NxesComputeStack.JwtSecretArn` | Unit 2 env vars | Secrets Manager ARN |
| `NxesApiStack.ApiGatewayUrl` | Unit 1 VITE_API_BASE_URL | API base URL |
| `NxesFrontendStack.AmplifyAppUrl` | CORS config | Frontend origin |

## Destroy

```bash
# WARNING: nxes-users and nxes-projects tables have RETAIN policy
# They will NOT be deleted on stack destroy (user data protection)
npx cdk destroy --all
```

## Environment Variables (Lambda — set automatically by CDK)

```
DYNAMODB_TABLE_SESSIONS=nxes-sessions
DYNAMODB_TABLE_USERS=nxes-users
DYNAMODB_TABLE_PROJECTS=nxes-projects
DYNAMODB_PROJECTS_GSI=project_id-index
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=24
MRV_WEIGHT=0.30
FINANCIAL_WEIGHT=0.25
RISK_WEIGHT=0.25
ADDITIONALITY_WEIGHT=0.20
SECRETS_MANAGER_JWT_SECRET_ARN=<from NxesComputeStack output>
```
