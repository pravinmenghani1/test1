import * as cdk from 'aws-cdk-lib';
import * as apigatewayv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as integrations from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';

export interface NxesApiStackProps extends cdk.StackProps {
  lambdaFunction: lambda.Function;
}

/**
 * NxesApiStack
 * Provisions the API Gateway HTTP API with Lambda proxy integration and CORS.
 *
 * Uses HTTP API (not REST API) — lower cost, sufficient for pilot.
 * CORS is configured to allow the Amplify frontend origin.
 */
export class NxesApiStack extends cdk.Stack {
  public readonly apiGatewayUrl: string;

  constructor(scope: Construct, id: string, props: NxesApiStackProps) {
    super(scope, id, props);

    // ── Lambda integration ────────────────────────────────────────────────────
    const lambdaIntegration = new integrations.HttpLambdaIntegration(
      'LambdaIntegration',
      props.lambdaFunction
    );

    // ── HTTP API ──────────────────────────────────────────────────────────────
    const httpApi = new apigatewayv2.HttpApi(this, 'NxesHttpApi', {
      apiName: 'nxes-api',
      description: 'NxES Decision Core API',
      corsPreflight: {
        // Allow all origins during development; restrict to Amplify URL in production
        allowOrigins: ['*'],
        allowMethods: [
          apigatewayv2.CorsHttpMethod.GET,
          apigatewayv2.CorsHttpMethod.POST,
          apigatewayv2.CorsHttpMethod.OPTIONS,
        ],
        allowHeaders: ['Authorization', 'Content-Type'],
        maxAge: cdk.Duration.hours(1),
      },
    });

    // Catch-all route — FastAPI handles routing internally via Mangum
    httpApi.addRoutes({
      path: '/{proxy+}',
      methods: [apigatewayv2.HttpMethod.ANY],
      integration: lambdaIntegration,
    });

    // Root route
    httpApi.addRoutes({
      path: '/',
      methods: [apigatewayv2.HttpMethod.ANY],
      integration: lambdaIntegration,
    });

    this.apiGatewayUrl = httpApi.apiEndpoint;

    // ── Outputs ───────────────────────────────────────────────────────────────
    new cdk.CfnOutput(this, 'ApiGatewayUrl', {
      value: httpApi.apiEndpoint,
      description: 'API Gateway endpoint URL — set as VITE_API_BASE_URL in frontend',
    });
  }
}
