import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';

export interface NxesComputeStackProps extends cdk.StackProps {
  sessionsTableArn: string;
  sessionsTableName: string;
  usersTableArn: string;
  usersTableName: string;
  projectsTableArn: string;
  projectsTableName: string;
}

/**
 * NxesComputeStack
 * Provisions the Lambda function, IAM execution role, and Secrets Manager secret.
 *
 * Security: Least-privilege IAM — only DynamoDB (3 tables), CloudWatch Logs, Secrets Manager.
 * JWT secret stored in Secrets Manager, NOT in environment variables.
 */
export class NxesComputeStack extends cdk.Stack {
  public readonly lambdaFunction: lambda.Function;

  constructor(scope: Construct, id: string, props: NxesComputeStackProps) {
    super(scope, id, props);

    // ── JWT Secret (Secrets Manager) ──────────────────────────────────────────
    const jwtSecret = new secretsmanager.Secret(this, 'JwtSecret', {
      secretName: 'nxes/jwt-secret',
      description: 'JWT signing secret for NxES Decision Core',
      generateSecretString: {
        secretStringTemplate: JSON.stringify({}),
        generateStringKey: 'JWT_SECRET_KEY',
        excludePunctuation: false,
        passwordLength: 64,
      },
    });

    // ── IAM Execution Role ────────────────────────────────────────────────────
    const executionRole = new iam.Role(this, 'LambdaExecutionRole', {
      roleName: 'nxes-lambda-execution-role',
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'Least-privilege execution role for NxES Decision Core Lambda',
    });

    // CloudWatch Logs
    executionRole.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')
    );

    // DynamoDB — explicit table ARNs only (no wildcards)
    executionRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'dynamodb:GetItem',
        'dynamodb:PutItem',
        'dynamodb:UpdateItem',
        'dynamodb:DeleteItem',
        'dynamodb:Query',
        'dynamodb:Scan',
      ],
      resources: [
        props.sessionsTableArn,
        props.usersTableArn,
        props.projectsTableArn,
        `${props.projectsTableArn}/index/*`,
      ],
    }));

    // Secrets Manager — JWT secret only
    executionRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ['secretsmanager:GetSecretValue'],
      resources: [jwtSecret.secretArn],
    }));

    // ── Lambda Function ───────────────────────────────────────────────────────
    this.lambdaFunction = new lambda.Function(this, 'ApiFunction', {
      functionName: 'nxes-api',
      runtime: lambda.Runtime.PYTHON_3_12,
      handler: 'app.main.handler',
      // Code will be deployed from backend/ directory via asset bundling
      code: lambda.Code.fromAsset('../backend', {
        bundling: {
          image: lambda.Runtime.PYTHON_3_12.bundlingImage,
          command: [
            'bash', '-c',
            'pip install -r requirements.txt -t /asset-output && cp -r . /asset-output',
          ],
        },
      }),
      role: executionRole,
      memorySize: 512,
      timeout: cdk.Duration.minutes(5),
      environment: {
        DYNAMODB_TABLE_SESSIONS: props.sessionsTableName,
        DYNAMODB_TABLE_USERS: props.usersTableName,
        DYNAMODB_TABLE_PROJECTS: props.projectsTableName,
        DYNAMODB_PROJECTS_GSI: 'project_id-index',
        JWT_ALGORITHM: 'HS256',
        JWT_EXPIRY_HOURS: '24',
        MRV_WEIGHT: '0.30',
        FINANCIAL_WEIGHT: '0.25',
        RISK_WEIGHT: '0.25',
        ADDITIONALITY_WEIGHT: '0.20',
        SECRETS_MANAGER_JWT_SECRET_ARN: jwtSecret.secretArn,
      },
    });

    // ── Outputs ───────────────────────────────────────────────────────────────
    new cdk.CfnOutput(this, 'LambdaFunctionArn', { value: this.lambdaFunction.functionArn });
    new cdk.CfnOutput(this, 'JwtSecretArn', { value: jwtSecret.secretArn });
  }
}
