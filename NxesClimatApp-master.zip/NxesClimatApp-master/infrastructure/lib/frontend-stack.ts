import * as cdk from 'aws-cdk-lib';
import * as amplify from '@aws-cdk/aws-amplify-alpha';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';
import { Construct } from 'constructs';

export interface NxesFrontendStackProps extends cdk.StackProps {
  apiGatewayUrl: string;
}

/**
 * NxesFrontendStack
 * Provisions the AWS Amplify app for the React frontend.
 *
 * NOTE: Amplify CDK construct requires a GitHub/CodeCommit connection.
 * For initial setup, the Amplify app can also be connected manually via the
 * AWS Console after the stack is deployed (connect to your git repository).
 *
 * The VITE_API_BASE_URL environment variable is injected automatically
 * from the API Gateway stack output.
 */
export class NxesFrontendStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: NxesFrontendStackProps) {
    super(scope, id, props);

    // ── Amplify App ───────────────────────────────────────────────────────────
    const amplifyApp = new amplify.App(this, 'NxesAmplifyApp', {
      appName: 'nxes-decision-core',
      description: 'NxES Decision Core Pilot App — React frontend',
      // Build spec for Vite + React
      buildSpec: codebuild.BuildSpec.fromObjectToYaml({
        version: '1.0',
        frontend: {
          phases: {
            preBuild: {
              commands: ['cd frontend', 'npm ci'],
            },
            build: {
              commands: ['npm run build'],
            },
          },
          artifacts: {
            baseDirectory: 'frontend/dist',
            files: ['**/*'],
          },
          cache: {
            paths: ['frontend/node_modules/**/*'],
          },
        },
      }),
      environmentVariables: {
        VITE_API_BASE_URL: props.apiGatewayUrl,
      },
    });

    // Main branch — auto-deploy on push
    const mainBranch = amplifyApp.addBranch('main', {
      autoBuild: true,
      branchName: 'main',
    });

    // ── Outputs ───────────────────────────────────────────────────────────────
    new cdk.CfnOutput(this, 'AmplifyAppId', {
      value: amplifyApp.appId,
      description: 'Amplify App ID',
    });
    new cdk.CfnOutput(this, 'AmplifyAppUrl', {
      value: `https://${mainBranch.branchName}.${amplifyApp.defaultDomain}`,
      description: 'Amplify frontend URL',
    });
  }
}
