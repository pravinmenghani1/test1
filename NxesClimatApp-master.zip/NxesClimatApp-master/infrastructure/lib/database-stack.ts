import * as cdk from 'aws-cdk-lib';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';

/**
 * NxesDatabaseStack
 * Provisions all DynamoDB tables for the NxES Decision Core platform.
 *
 * Tables:
 *   - nxes-sessions: Anonymous pilot sessions + analysis job tracking (TTL 24h)
 *   - nxes-users:    Registered user accounts
 *   - nxes-projects: User projects with analysis results (GSI on project_id)
 */
export class NxesDatabaseStack extends cdk.Stack {
  // Exported for use by NxesComputeStack (IAM policies)
  public readonly sessionsTableArn: string;
  public readonly sessionsTableName: string;
  public readonly usersTableArn: string;
  public readonly usersTableName: string;
  public readonly projectsTableArn: string;
  public readonly projectsTableName: string;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // ── Sessions table (AnonymousSession + AnalysisJob) ──────────────────────
    const sessionsTable = new dynamodb.Table(this, 'SessionsTable', {
      tableName: 'nxes-sessions',
      partitionKey: { name: 'PK', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      timeToLiveAttribute: 'ttl',
      removalPolicy: cdk.RemovalPolicy.DESTROY, // pilot — safe to destroy
    });

    // ── Users table ───────────────────────────────────────────────────────────
    const usersTable = new dynamodb.Table(this, 'UsersTable', {
      tableName: 'nxes-users',
      partitionKey: { name: 'PK', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      pointInTimeRecovery: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN, // user data — retain on stack destroy
    });

    // ── Projects table ────────────────────────────────────────────────────────
    const projectsTable = new dynamodb.Table(this, 'ProjectsTable', {
      tableName: 'nxes-projects',
      partitionKey: { name: 'PK', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'SK', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      pointInTimeRecovery: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN, // project data — retain on stack destroy
    });

    // GSI: direct project lookup by project_id (without knowing user_id)
    projectsTable.addGlobalSecondaryIndex({
      indexName: 'project_id-index',
      partitionKey: { name: 'project_id', type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });

    // ── Expose outputs ────────────────────────────────────────────────────────
    this.sessionsTableArn = sessionsTable.tableArn;
    this.sessionsTableName = sessionsTable.tableName;
    this.usersTableArn = usersTable.tableArn;
    this.usersTableName = usersTable.tableName;
    this.projectsTableArn = projectsTable.tableArn;
    this.projectsTableName = projectsTable.tableName;

    new cdk.CfnOutput(this, 'SessionsTableName', { value: sessionsTable.tableName });
    new cdk.CfnOutput(this, 'UsersTableName', { value: usersTable.tableName });
    new cdk.CfnOutput(this, 'ProjectsTableName', { value: projectsTable.tableName });
  }
}
